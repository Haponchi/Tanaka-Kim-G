<?php 
require 'adminCONX.php';

// Retrieve user ID from the POST request
$barberID = $_POST['barberID'];

$sql = "SELECT * FROM barbers WHERE barberID = :barberID";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':barberID', $barberID);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barber Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Lux theme CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/png">
    <style>
          body {
          background: url("Images/flat.jpg");
          background-position: center;
          background-size: cover;
          padding-top: 50px;
        }
           
        .profile-card {
            max-width: 500px;
            margin: auto;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: auto;
        }
        .form-control {
            background-color: #f8f9fa;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .form-group label {
            font-weight: bold;
        }
        .text-center.mt-4 {
            margin-top: 1.5rem !important;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="profile-card">
            <div class="text-center">
                <img id="preview" class="profile-image" src="Images/<?php echo htmlspecialchars($row['Picture']); ?>" alt="Profile Picture">
                <h4 class="mt-3"><?php echo htmlspecialchars($row['Name'] . ' ' . $row['Lname']); ?></h4>
            </div>
            <form action="update.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="barberID" value="<?php echo htmlspecialchars($barberID); ?>">
                <div class="form-group mt-4">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" value="<?php echo htmlspecialchars($row['Email']); ?>">
                </div>
                
                <div class="form-group mt-4">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="cp" name="cellphonenumber" required pattern="09\d{9}" value="<?php echo htmlspecialchars($row['CpNO']); ?>" title="follow this format 09XXXXXXXXX">
                </div>

                <div class="form-group text-center mt-4">
                    <input type="file" name="image" class="form-control-file">
                </div>
                
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="registeredbarber.php" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
} else {
    echo "No barber found with the given ID: " . htmlspecialchars($barberID);
}

$conn = null;
?>
