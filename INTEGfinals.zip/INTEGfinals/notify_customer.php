<?php
require 'customerCONX.php';
require 'PHPMailer/vendor/autoload.php'; // Include Composer's autoload file for PHPMailer
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingID = isset($_POST['booking_id']) ? $_POST['booking_id'] : '';

    if ($bookingID) {
        // Fetch the booking details and customer contact information
        $sql = "SELECT b.BookingID, b.Date, b.Time, u.Email, u.Fname AS firstname
                FROM booking b
                LEFT JOIN services s ON b.ServiceID = s.ServiceID
                LEFT JOIN user u ON s.UserID = u.UserID
                WHERE b.BookingID = :bookingID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':bookingID', $bookingID);
        $stmt->execute();
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($booking) {
            $bookingDateTime = $booking['Date'] . ' ' . $booking['Time'];
            $notificationTime = date('Y-m-d H:i:s', strtotime($bookingDateTime . ' -1 hour'));
            $currentTime = date('Y-m-d H:i:s');

            if ($currentTime >= $notificationTime) {
                $email = $booking['Email'];
                $firstname = $booking['firstname'];
                $subject = 'Booking Reminder';
                $message = 'This is a reminder for your upcoming booking scheduled at ' . $bookingDateTime;

                // Send email notification
                $mail = new PHPMailer(true);

                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com'; // Set the SMTP server
                    $mail->SMTPAuth = true;
                    $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
                    $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
                    $mail->addAddress($email);

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = $subject;
                    $mail->Body    = "Hi $firstname,<br><br>$message<br><br>Thank you,<br>Brilliante Barbershop";

                    $mail->send();
                    echo 'Reminder email has been sent.';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "It is not time to send the notification yet.";
            }
        } else {
            echo "Booking not found.";
        }
    } else {
        echo "Booking ID is missing.";
    }
}
?>
