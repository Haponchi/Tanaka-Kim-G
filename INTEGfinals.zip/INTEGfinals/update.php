<?php 
require 'adminCONX.php';
session_start();

$userID = $_SESSION['c'];

// Check if a file is uploaded
if (!empty($_FILES['image']['name'])) {
    if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        $folder = 'Images/'.$file_name;

        // Move uploaded file to the specified folder
        if (move_uploaded_file($tempname, $folder)) {
            // Update the 'Picture' column in the user table
            $query = "UPDATE user SET Picture = :file_name WHERE userID = :userID";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':file_name', $file_name);
            $stmt->bindParam(':userID', $userID);
            if ($stmt->execute()) {
                // Log the audit trail for updating the picture
                $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:userID, 'Update Picture')";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bindParam(':userID', $userID);
                if (!$stmt->execute()) {
                    echo "Error logging audit trail: " . $stmt->errorInfo()[2];
                    exit();
                }
            } else {
                echo "Error updating picture: " . $stmt->errorInfo()[2];
                exit();
            }
        } else {
            echo "Error uploading file.";
            exit();
        }
    } else {
        echo "Error uploading file: " . $_FILES['image']['error'];
        exit();
    }
    echo "<script>alert('Successfully updated profile picture.'); window.location.href = 'profile.php';</script>";
    exit();
} else {

}

// Check if email or cell phone number already exist in the database
if (!empty($_POST['cellphonenumber']) || !empty($_POST['email']) || !empty($_POST['username'])) {
    $username = $_POST['Username'] ?? null; // Get username from form
    $cellphonenumber = $_POST['cellphonenumber'] ?? null;
    $email = $_POST['email'] ?? null;

    // Fetch current user's data
    $currentUserQuery = "SELECT Email, CpNO, Username FROM user WHERE userID = :userID";
    $stmt = $conn->prepare($currentUserQuery);
    $stmt->bindParam(':userID', $userID);
    $stmt->execute();
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the provided email and cell phone number are the same as the current ones
    if ($email === $currentUser['Email'] && $cellphonenumber === $currentUser['CpNO'] && $username === $currentUser['Username']) {
        echo "<script>alert('The email, Username and cell phone number provided are already associated with your account.'); window.location.href = 'profile.php';</script>";
        exit();
    }

    // Check if the provided email or cell phone number already exist in another account
    $checkQuery = "SELECT * FROM user WHERE (Email = :email OR CpNO = :cellphonenumber OR Username = :username) AND userID != :userID";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':cellphonenumber', $cellphonenumber);
    $stmt->bindParam(':userID', $userID);
    $stmt->execute();
    $checkResult = $stmt->fetchAll();

    if (count($checkResult) > 0) {
        echo "<script>alert('Email, Username or cell phone number already exists.'); window.location.href = 'profile.php';</script>";
        exit();
    } else {
        // Build the query to update user's cell phone number and/or email
        $queryParts = [];
        $updateActions = [];
        if (!empty($cellphonenumber) && $cellphonenumber !== $currentUser['CpNO']) {
            $queryParts[] = "CpNO = :cellphonenumber";
            $updateActions[] = "Cell Phone Number";
        }
        if (!empty($email) && $email !== $currentUser['Email']) {
            $queryParts[] = "Email = :email";
            $updateActions[] = "Email";
        }
        if (!empty($username) && $username !== $currentUser['Username']) {
            $queryParts[] = "Username = :username";
            $updateActions[] = "Username";
        }

        $query = "UPDATE user SET " . implode(", ", $queryParts) . " WHERE userID = :userID";


        // Execute the query to update user's cell phone number and/or email
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':userID', $userID);
        if (!empty($cellphonenumber) && $cellphonenumber !== $currentUser['CpNO']) {
            $stmt->bindParam(':cellphonenumber', $cellphonenumber);
        }

        if (!empty($email) && $email !== $currentUser['Email']) {
            $stmt->bindParam(':email', $email);
        }

        if (!empty($username) && $username !== $currentUser['Username']) {
            $stmt->bindParam(':username', $username);
        }

        
        if ($stmt->execute()) {
            // Log the audit trail for updating the credentials
            foreach ($updateActions as $action) {
                $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:userID, :action)";
                $stmt_log = $conn->prepare($insert_sql);
                $stmt_log->bindParam(':userID', $userID);
                $actionMessage = "Update " . $action;
                $stmt_log->bindParam(':action', $actionMessage);
                if (!$stmt_log->execute()) {
                    echo "Error logging audit trail for $action: " . $stmt_log->errorInfo()[2];
                    exit();
                }
            }
            $updateMessages = implode(" and ", $updateActions);
            echo "<script>alert('Successfully updated: $updateMessages.'); window.location.href = 'profile.php';</script>";
            exit();
        } else {
            echo "Error updating record: " . $stmt->errorInfo()[2];
            exit();
        }
    }
} else {
    echo "No email or cell phone number provided.";
    exit();
}

// Close the database connection
$conn = null;
?>
