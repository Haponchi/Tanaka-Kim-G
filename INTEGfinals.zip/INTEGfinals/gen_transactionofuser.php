<?php
session_start();
$id = $_SESSION['c'];
$selectedDate = $_SESSION['selectedDate'];

require_once('tcpdf/tcpdf.php');
require('adminCONX.php');

try {
    $sql = "SELECT
            b.BookingID AS booking_id,
            b.ServiceID AS service_id,
            b.Status AS booking_status,
            s.Type AS service_type,
            b.Creation AS booking_creation_date,
            b.Date AS booking_date,
            b.barberID AS barberID,
            b.Time AS booking_time
        FROM
            booking b
        LEFT JOIN
            services s ON b.ServiceID = s.ServiceID AND DATE(b.Creation) = :selectedDate
        LIMIT :limit OFFSET :offset";


    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':selectedDate', $selectedDate);
    $stmt->bindValue(':limit', 30, PDO::PARAM_INT);
    $stmt->bindValue(':offset', 0, PDO::PARAM_INT);
    $stmt->execute();


    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Initialize TCPDF
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Brilliante');
    $pdf->SetTitle('Booking Record - Brilliante');
    $pdf->SetSubject('Booking Record');
    $pdf->SetKeywords('TCPDF, PDF, report');

    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 10);

    // Header
    $pdf->writeHTML('<h1 class="text-center mb-4">Booking Report - Brilliante Barbershop</h1>', true, false, true, false, '');
    $pdf->writeHTML('<p class="text-center">Report generated on ' . date('Y-m-d') . '</p>', true, false, true, false, '');

    // Initialize variable to track current month
    $currentMonth = '';

    // Initialize an array to store unique booking IDs
    $uniqueBookingIds = array();

    // Table
    $html = '<table border="1" cellspacing="0" cellpadding="5">';
    $html .= '<thead>';
    $html .= '<tr><th>Booking ID</th><th>Service ID</th><th>Barber ID</th><th>Date</th><th>Time</th><th>Status</th><th>Type</th></tr>';
    $html .= '</thead>';
    $html .= '<tbody>';

    // Loop through the results
    foreach ($result as $row) {
        $bookingId = $row['booking_id'];
        
        // Check if this booking ID is unique
        if (!in_array($bookingId, $uniqueBookingIds)) {
            $uniqueBookingIds[] = $bookingId; // Add booking ID to the list of unique IDs
            
            // Extract month and year from the booking creation date
            $month = date('F Y', strtotime($row['booking_creation_date']));

            // Check if a new month is encountered
            if ($currentMonth != $month) {
                // Add a new row for the month label
                $html .= '<tr><td colspan="10"><strong>' . $month . '</strong></td></tr>';
                $currentMonth = $month;
            }

            // Add data for each record
            $html .= '<tr>';
            $html .= '<td>' . $row['booking_id'] . '</td>';
            $html .= '<td>' . $row['service_id'] . '</td>';
            $html .= '<td>' . $row['barberID'] . '</td>';
            $html .= '<td>' . $row['booking_date'] . '</td>';
            $html .= '<td>' . $row['booking_time'] . '</td>';
            $html .= '<td>' . $row['booking_status'] . '</td>';
            $html .= '<td>' . $row['service_type'] . '</td>';
            $html .= '</tr>';
        }
    }

    $html .= '</tbody>';
    $html .= '</table>';

    // Output the HTML content
    $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    $pdf->Output('Booking_Record.pdf', 'D');

} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
