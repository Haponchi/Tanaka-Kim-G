<?php
session_start();
require 'customerCONX.php';

// Get the booking ID from the session parameter
$bookingID = $_SESSION['BookingID'];

// SQL to update the booking status to 'cancelled' where booking_id matches $bookingID
$sql = "UPDATE booking SET status = 'Cancelled' WHERE BookingID = :booking_id";

// Assuming you are using PDO for database operations
$stmt = $conn->prepare($sql);
$stmt->bindParam(':booking_id', $bookingID);

try {
    $stmt->execute();

    // Display message confirming the cancellation
    echo "<script>alert('Your booking is cancelled.'); window.location.href = 'bookingcustomer.php';</script>";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
