<?php
session_start(); 
require('customerCONX.php'); 
$id = $_SESSION['c'];

// Initialize selected date with the GET parameter 'date' or default to today's date
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Pagination
$limit = 30; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

// Calculate offset for pagination
$offset = ($page - 1) * $limit;

// Query to retrieve data from the "payment" table with pagination
$sql = "SELECT * FROM payment WHERE DATE(Created_At) = ? LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('sii', $selectedDate, $limit, $offset); // Pass three variables to bind_param
$stmt->execute();
$result = $stmt->get_result();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">    <style>
        th{
            background-color: white;
            text-align: center;
        }
        .Paid{
            padding: 13px 30px;
            background-color: red;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 0 auto;
                display: block; /* Ensures the button takes up the entire width */


        }
        .notyet{
            padding: 13px 30px;
            background-color: green;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .thead-dark{
            text-align: le;
        }
        .pay{
            text-align: center;
        }
        .but{
            padding-left: 70px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mt-5 mb-4">Payment History </h1>
    <p class="date">Report generated on <?php echo date('Y-m-d'); ?></p>
    <div class="form-group">
        <label for="datepicker">Select Date:</label>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
    </div>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr><th>Payment ID</th><th>Booking ID</th><th>Method</th><th>Date Paid</th><th>Amount</th><th>Status</th><th>Paid</th></tr>
        </thead>
    <tbody>
    <?php
    // Pagination
   
    // Initialize variables
    $currentMonth = '';

    // Fetch data
  while ($row = $result->fetch_assoc()) {
    $regDate = date('F Y', strtotime($row['Created_At']));
        if ($currentMonth != $regDate) {
            $currentMonth = $regDate;
            echo '<tr><td colspan="7"><strong>' . $currentMonth . '</strong></td></tr>';
        }
        // Add data for each record
        echo '<tr>';
        echo '<td class="pay">' . $row['PaymentID'] . '</td>';
        echo '<td class="pay">' . $row['BookingID'].'</td>';
        echo '<td class="pay">' . $row['Method'] . '</td>';
        echo '<td class="pay">' . $row['DatePaid'] . '</td>';
        echo '<td class="pay">' . $row['Amount'] . '</td>';
        echo '<td class="pay">' . $row['Status'] . '</td>';
        echo '<td>';
        // Check if the status is "Paid"
        if ($row['Status'] === 'Paid') {
            echo '<div class="but"><button type="button" class="Paid" disabled>Yes</button></div>';
        } else {
            echo '<form action="paymentstatus.php" method="post">';
            echo '<input type="hidden" name="PaymentID" value="' . $row['PaymentID'] . '">';
            echo '<div class="but"><button type="submit" class="notyet">Yes</button></div>';
            echo '</form>';
        }
        echo '</td>';
        echo '</tr>';
    }

    ?>

    </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
           <li>
              <a class="page-link" href="adminHOME.php">Back</a>
           </li>
           <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
              <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
           </li>
           <li class="page-item">
              <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
           </li>
        </ul>
    </nav>

    <!-- Add buttons for PDF conversion -->
    <div class="mt-3">
       <a href="gen_pdf.php" target="_blank" class="btn btn-primary">Download PDF</a>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });
    });
</script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
