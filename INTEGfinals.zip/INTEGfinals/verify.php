<?php
session_start();

require 'customerCONX.php';

// Check if the user ID and verification code are set in the session
if (isset($_SESSION['c'])) {
    // Retrieve the user ID and verification code from the session
    $userID = $_SESSION['c'];

    // Use the user ID and verification code as needed
    // echo "User ID: " . $userID . "<br>";
    // echo "Verification Code: " . $verificationCode;
} else {
    // Handle the case where either the user ID or verification code is not set in the session
}
?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Glassmorphism Login Form | CodingNepal</title>
  <link rel="stylesheet" href="style6.css">
  <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
          .btn-custom {
            background-color: green;
        margin-right: 10px;
     }
      .btn-custom:hover {
            background-color: #03C04A;     }
    .btn-custom:last-child {
        margin-right: 0;
    }
  </style>
}
</head>
<body>
  <div class="wrapper">
    <form action="verifyHandler.php" method="post">
      <h2 >Verification</h2>
        <div class="input-field">
        <input type="password" name="code" required >
        <label style=" color:   white ;">Enter the code</label>
      </div>
                       <button type="submit" class=" btn-custom"><i class="fas fa-check"></i> Submit</button>

           <a href="index.php" class="btn btn-danger btn-custom" style = "background-color: red;"><i class="fas fa-times"></i> Cancel</a>
           <a href="resendVerification.php" class="btn btn-warning btn-custom" style = "background-color: transparent;"><i class="fas fa-sync"></i> Resend</a>

    </form>
  </div>
</body>
</html>