<?php 
session_start();

require 'userloginCONX.php';

// Retrieve user ID from session
$id = $_SESSION['c'];

$sql = "SELECT * FROM user WHERE userID = '$id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile</title>
    <link rel="stylesheet" href="style2.css">
    <style>
        .box-link {
            display: inline-block;
            padding: 10px 20px;
            background-color: blue;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .Update {
            display: inline-block;
            padding: 10px 20px;
            background-color: green;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back {
            display: inline-block;
            padding: 10px 20px;
            background-color: blue;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .settings {
            padding-top: 5px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Calibri;
        }

        body {
            width: 80%;
            margin: 0 auto;
        }

        h1 {
            font-weight: 600;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin: 10px 0px;
        }

        .form-group label {
            font-size: 1.2em;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .form-group input {
            padding: 7px;
            font-size: 1em;
            padding-left: 15px;
            border-width: 1px;
            border-radius: 5px;
            margin: 5px;
        }

        .input-label {
            font-weight: 200;
        }

        .button {
            padding: 7px 10px;
            background-color: rgb(5, 96, 255);
            color: #fff;
            font-size: 1em;
            border: none;
            border-radius: 5px;
        }

        .footer-label a {
            text-decoration: none;
            color: rgb(41, 119, 255);
        }

        .errormessage {
            padding: 15px;
            padding-left: 20px;
            font-size: 1em;
            border-radius: 5px;
            background-color: rgb(255, 220, 220);
            margin-top: 5px;
        }

        .group {
            padding-top: 60px;
        }
        .error{
            padding-top: 20px;
        }
    </style>
</head>
<body style="background-image: url('Images/shavee.jpg'); background-size: cover;">
    <form action="changepassverify.php" method="post" enctype="multipart/form-data">
        <div class="group">
            <div class="form-group">
                <label style="color: white;" for="oldpass">Old Password</label>
                <input type="password" id="oldpass" name="oldpass" required>
            </div>
            <div class="form-group">
                <label style="color: white;" for="newpass">New Password</label>
                <input  type="password" id="newpass" name="newpass" required>
            </div>
            <div class="form-group">
                <label style="color: white;" for="confirmpass">Confirm Password</label>
                <input type="password" id="confirmpass" name="confirmpass" required>
            </div>
            <div class="settings">
                <input type="submit" value="Update" class="Update">
                <a href="adminHOME.php" class="back">Back</a>
            </div>

            <div class="error">
                <h2>Credentials is not correct</h2>
            </div>
        </div>
    </form>
</body>
</html>

<?php 
} else {
    echo "User not found.";
}
$conn->close();
?>
