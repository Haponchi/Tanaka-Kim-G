<?php
require 'customerCONX.php';
session_start();

$sql = "SELECT s.ServiceID, s.Type FROM Services s";
$stmt = $conn->prepare($sql);
$stmt->execute();
$serviceRow = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if serviceRow is not empty (i.e., a service is found)
if ($serviceRow) {
    // Store the service ID in the session
    $_SESSION['serviceID'] = $serviceRow['ServiceID'];
} else {
    // Handle the case where no service is found
    $_SESSION['serviceID'] = null;
}

// Get the service ID from the session
$serviceID = $_SESSION['serviceID'];

$limit = 30; // Number of records per page
$selectedDate = isset($_GET['date']) ? $_GET['date'] : '';
$searchBookingID = isset($_GET['searchBookingID']) ? $_GET['searchBookingID'] : '';

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate offset for pagination

// Ensure $limit and $offset are integers
$limit = (int)$limit;
$offset = (int)$offset;

// Check if the selected date is present in the URL
if (isset($_GET['date'])) {
    // If it is, store it in a session variable
    $_SESSION['selectedDate'] = $_GET['date'];
} else {
    // If not, use the default current date
    $_SESSION['selectedDate'] = date('Y-m-d');
}

// Retrieve the selected date from the session
$selectedDate = $_SESSION['selectedDate'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Report</title>
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <style>
        body{
            font-family: 'Poppins';
        }
        .container {
            max-width: 1400px; Increase max-width to desired value */
        }
        th, td {
            text-align: center;
        }
        .filterAllButton{
            padding-top: 30px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-group">
        <h5 for="datepicker">Select Date:</h5>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
    </div>
    <div class="form-group d-flex justify-content-between">
        <form action="" method="get" class="mb-3 flex-grow-1 mr-2">
            <div class="input-group">
                <input type="text" name="searchBookingID" class="form-control" placeholder="Search Booking ID" value="<?php echo $searchBookingID; ?>">
                <div class="input-group-append">
                    <button class="btn btn-secondary" type="submit">Search</button>
                </div>
            </div>
        </form> 
        <div>    
        <button class="btn btn-secondary" id="filterAllButton" type="button">Show All</button>
        </div>  
    </div>

    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Name</th>
                <th>Booking ID</th>
                <!-- <th>Service ID</th> -->
                <th>BarberID</th>
                <th>Type</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <!-- <th>Type</th> -->
                <th>Action</th> <!-- New column for action buttons -->
                <!-- <th>Notify</th> -->
            </tr>
        </thead>
        <tbody>
        <?php
        if ($serviceID) {
            // Query to retrieve bookings associated with the service ID
            $sql = "SELECT
                b.BookingID AS booking_id,
                b.ServiceID AS service_id,
                b.Status AS booking_status,
                s.Type AS service_type,
                b.Creation AS booking_creation_date,
                b.Date AS booking_date,
                b.barberID AS barberID,
                b.Time AS booking_time
            FROM
                booking b
            LEFT JOIN
                services s ON b.ServiceID = s.ServiceID";
            
            $conditions = [];
            if (!empty($selectedDate)) {
                $conditions[] = "DATE(b.Creation) = :selectedDate";
            }
            if (!empty($searchBookingID)) {
                $conditions[] = "b.BookingID = :searchBookingID";
            }
            if ($conditions) {
                $sql .= " WHERE " . implode(" AND ", $conditions);
            }
            
            $sql .= " LIMIT :limit OFFSET :offset";

            $stmt = $conn->prepare($sql);
            if (!empty($selectedDate)) {
                $stmt->bindParam(':selectedDate', $selectedDate);
            }
            if (!empty($searchBookingID)) {
                $stmt->bindParam(':searchBookingID', $searchBookingID);
            }
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();  
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Initialize an array to store unique booking IDs
            $uniqueBookingIDs = [];

            // Fetch data
            foreach ($result as $row) {
                // Check if the booking ID is already displayed
                if (!in_array($row['booking_id'], $uniqueBookingIDs)) {
                    // Add the booking ID to the array of unique booking IDs
                    $uniqueBookingIDs[] = $row['booking_id'];

                    // Add data for each record
                    echo '<tr>';
                    echo '<td>' . $row['Name'] . '</td>';

                    echo '<td>' . $row['booking_id'] . '</td>';
                    // echo '<td>' . $row['service_id'] . '</td>';
                    echo '<td>' . $row['barberID'] . '</td>';
                    echo '<td>' . $row['service_type'] . '</td>';

                    echo '<td>' . $row['booking_date'] . '</td>';
                    echo '<td>' . $row['booking_time'] . '</td>';
                    echo '<td>' . $row['booking_status'] . '</td>';
                    // echo '<td>' . $row['service_type'] . '</td>';
                    // Add action buttons based on booking status
                    echo '<td>'; // Open a new cell for the form and button
                    if ($row['booking_status'] == 'Cancelled') {
                        echo '<button type="button" class="btn btn-danger" disabled>Mark as Done</button>';
                    } else if ($row['booking_status'] == 'Done') {
                        echo '<form action="booking_done.php" method="post">';
                        echo '<input type="hidden" name="booking_id" value="' . $row['booking_id'] . '">';
                        echo '<button type="submit" class="btn btn-primary" disabled>Mark as Done</button>';
                        echo '</form>';
                    } else {
                        echo '<form action="markasdone.php" method="post">';
                        echo '<input type="hidden" name="booking_id" value="' . $row['booking_id'] . '">';
                        echo '<button type="submit" class="btn btn-primary">Mark as Done</button>';
                        echo '</form>';       
                    }
                    echo '</td>'; // Close the cell
                    // if ($row['booking_status'] == 'Cancelled' || $row['booking_status'] == 'Done') {
                    //     echo '<button type="button" class="btn btn-warning" disabled>Notify</button>';
                    // // } else {
                    // //     // echo '<form action="notify_customer.php" method="post">';
                    // //     // echo '<input type="hidden" name="booking_id" value="' . $row['booking_id'] . '">';
                    // //     // echo '<button type="submit" class="btn btn-warning">Notify</button>';
                    // //     // echo '</form>';
                    // // }
                    // echo '</td>';
                    // echo '</tr>';
                }
            }
        } else {
            echo '<tr><td colspan="11">No bookings found for this service.</td></tr>';
        }
        ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="adminHOMEE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
    <a class="btn btn-primary mt-4" href="gen_transactionofuser.php" target="_blank">Download PDF</a>

</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });

        $('#filterAllButton').click(function(){
            window.location.href = '?';
        });
    });
</script>
</body>
</html>
