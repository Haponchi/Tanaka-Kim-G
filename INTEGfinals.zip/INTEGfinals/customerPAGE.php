<?php
session_start();
require 'customerCONX.php';

// Check if the logout link is clicked
if (isset($_GET['logout'])) {
    // Capture the user ID before the session is destroyed
    if (isset($_SESSION['c'])) {
        $userID = $_SESSION['c'];

        try {
            // Insert audit log for the logout
            $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->execute([$userID, "Logout"]);

            if ($stmt->rowCount() > 0) {
                echo "<script>console.log('Audit log inserted successfully');</script>";
            } else {
                echo "<script>console.log('Failed to insert audit log');</script>";
            }
        } catch (PDOException $e) {
            echo "<script>console.log('Error: " . $e->getMessage() . "');</script>";
        }
    } else {
        echo "<script>console.log('User ID not found in session');</script>";
    }

    // Destroy all session data
    session_destroy();

    // Redirect the user to the login page or any other desired location
    echo "<script>alert('Logout Successfully.'); window.location.href = 'index.php';</script>";
    exit;
}


$id = $_SESSION['c'];

// Update MFA status if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['mfa_status_on'])) {
        $mfaStatus = 1; // MFA enabled
        $message = "Multi Factor Authentication is ONW.";
    } elseif (isset($_POST['mfa_status_off'])) {
        $mfaStatus = 0; // MFA disabled
        $message = "Multi Factor Authentication is OFF.";

    }

    $update_mfa_sql = "UPDATE user SET MFAEnabled = :mfaStatus WHERE UserID = :id";
    $stmt_update_mfa = $conn->prepare($update_mfa_sql);
    $stmt_update_mfa->bindParam(':mfaStatus', $mfaStatus);
    $stmt_update_mfa->bindParam(':id', $id);
    $stmt_update_mfa->execute();
}


$sql = "SELECT * FROM user WHERE UserID = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "No user found with the given ID: " . $id;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Brilliante Barbershop</title>
  <link rel="stylesheet" href="customerPAGE.css">
  <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
  <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">

</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="customerPAGE.php" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
        <a href="aboutt.php">About Us</a>
        <a href="policyy.php">Policy</a>
        <a href="bookingcustomer.php">Transaction Record</a>
        <a href="reservedslots.php">Reserved Slot</a>

    <select id="services-select" class="services">
        <option value="">Book Services</option>
        <option value="haircut">Haircut</option>
        <option value="shave">Shave</option>
        <option value="cut_and_shave">Cut and Shave</option>
    </select>

    <script>
        document.getElementById('services-select').addEventListener('change', function() {
            var selectedValue = this.value;
            if (selectedValue) {
                var urls = {
                    haircut: 'insertHAIRCUT.php',
                    shave: 'insertSHAVE.php',
                    cut_and_shave: 'insertBOTH.php'
                };
                window.location.href = urls[selectedValue];
            }
        });
    </script>
    <select id="account-select" class="account">
        <option value="">Account</option>
        <option value="profile">Profile</option>
        <!-- <option value="pass">Change Password</option> -->
        <!-- <option value="mfa">MFA</option> -->
        <option value="logout">Logout</option>
        <option value="pass">Change Password</option>

    </select>

    
        <script>
            document.getElementById('account-select').addEventListener('change', function() {
                var selectedValue = this.value;
                if (selectedValue) {
                    var urls = {
                        profile: 'profile.php',
                        pass: 'changepasscustomer.php',
                        // mfa: 'mfa.html',
                        logout: 'customerPAGE.php?logout=true'
                    };
                    window.location.href = urls[selectedValue];
                }
            });
        </script>

      </div>
  </nav>

  <main>
    <div class="slideshow-container">
      <div class="mySlides fade">
        <img src="images/pic4.jpg" style="width:100%; height:5%;">
      </div>
      <div class="mySlides fade">
        <img src="images/pic3.jpg" style="width:100%">
      </div>
      <div class="mySlides fade">
        <img src="images/brill.jpg" style="width:100%">
      </div>
    <div class="container">
      <!-- <h1 style="text-align: left; padding-left:57px; ">Book Services</h1> -->
      <div class="pic-wrapper">
        <a href="customerPAGE.php" class="pic-container">
          <img src="Images/haircut.jpg" alt="Placeholder 1">
          <p><b>Haircut</b><br>P200.00</p>
        </a>
        <a href="customerPAGE.php" class="pic-container">
          <img src="Images/shave.jpg" alt="Placeholder 2">
          <p><b>Shave</b><br>P100.00</p>
        </a>
        <a href="customerPAGE.php" class="pic-container">
          <img src="Images/cutnshave.jpg" alt="Placeholder 3">
          <p><b>Shave & Cut</b><br>P300.00</p>
        </a>
      </div>
    </div>
  </main>
  <footer class="footer">
    <div class="footer-content">
      <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
      <div class="footer-title">
        <h2>Brilliante Barbershop</h2>
        <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
      </div>
      <div class="footer-links">
        <h3>Links</h3>
        <a href="customerPAGE.php">Home  |</a>
        <a href="aboutt.php">About Us  |</a>
        <a href="policyy.php">Policy</a>
        <div class="social-icons">
          <br>
          <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
          <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
        </div>
        <div class = "contact">
          <br><br><h2>Contact Us</h2>
          For inquiries and appointments, please contact us at:<br>
          Phone: 0917 560 0119</p>
          </div>
      </div>   
    </div>   
    <br>
    <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
