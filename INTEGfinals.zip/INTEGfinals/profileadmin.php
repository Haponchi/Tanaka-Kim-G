<?php 
session_start();

require 'customerCONX.php';

// Retrieve user ID from session
$id = $_SESSION['c'];

$sql = "SELECT * FROM user WHERE userID = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Lux theme CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <style>
        body{
            font-family: 'Poppins';
               background: url("Images/comb.jpg");
          background-position: center;
          background-size: cover;
          font-size: 20px;
        }
      
        .profile-card {
            max-width: 500px;
            margin: auto;
            padding: 56px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: auto;
        }
        .form-control {
            background-color: #f8f9fa;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .form-group label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="profile-card">
            <!-- <div class="text-center mb-4">
                <h2>User Profile</h2>
            </div> -->
            <div class="text-center">
                <img id="preview" class="profile-image" src="Images/<?php echo $result['Picture']; ?>" alt="Profile Picture">
                <h4 class="mt-3"><?php echo $result['Fname'] . ' ' . $result['Lname']; ?></h4>
            </div>
            <form action="update.php" method="post" enctype="multipart/form-data">
                <div class="form-group mt-4">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="Username" required pattern="^[a-zA-Z0-9]+$" title="Username cannot contain spaces" value="<?php echo $result['Username']; ?>">
                </div>

                <div class="form-group mt-4">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" value="<?php echo $result['Email']; ?>">
                </div>
                
                <div class="form-group mt-4">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="cp" name="cellphonenumber" required pattern="09\d{9}" value="<?php echo $result['CpNO']; ?>" title="follow this format 09XXXXXXXXX">
                </div>

                <div class="form-group text-center mt-4">
                    <input type="file" name="image" class="form-control-file">
                </div>
                
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="adminHOMEE.php" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

<?php
} // Closing brace for if ($result)
$stmt->closeCursor();
$conn = null;
?>
