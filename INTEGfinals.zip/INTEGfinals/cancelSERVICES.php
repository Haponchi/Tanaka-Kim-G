<?php 
session_start();
require 'customerCONX.php';

$id = $_SESSION['c'];
$serviceID = $_SESSION['serviceID'];

$serviceType = $_SESSION['serviceType'];
$barbername = $_SESSION['barberName'];

$insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, ?)";
$stmt = $conn->prepare($insert_sql);
$stmt->execute([$id, "Cancelled $serviceType"]);

// $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, ?)";
// $stmt = $conn->prepare($insert_sql);
// $stmt->execute([$id, "Cancelled Barber $barbername"]);

// Prepare the SQL statement with a placeholder for the serviceID
$sql = "DELETE FROM services WHERE ServiceID = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind the serviceID parameter
$stmt->bindParam(1, $serviceID, PDO::PARAM_INT);

// Execute the statement
if ($stmt->execute()) {
    // Unset the session variable
    unset($_SESSION['serviceID']);
    // Redirect to a confirmation page or another page
    header("Location: customerPAGE.php");
} else {
    // Redirect to an error page if deletion fails
    header("Location: error.php");
}

// Close the prepared statement
$stmt->close();

// Close the database connection
$conn = null;
?>
