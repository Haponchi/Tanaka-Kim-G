<?php
session_start();

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];
$price = $_SESSION['price'];
$paymentID	= $_SESSION['paymentID'];

echo "<script>alert('Payment Succesfull! Thank you for choosing Brilliante. Your booking has been confirmed.'); window.location.href = 'gcash_generate_receipt.php';</script>";
?>
