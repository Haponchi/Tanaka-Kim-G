<?php
// Start session
session_start();

// Retrieve form data
$username = $_POST['username'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$cpnumber = $_POST['cpnumber'];
$email = $_POST['email'];
$password = $_POST['password'];

// Store form data in session variables
$_SESSION['username'] = $username;
$_SESSION['firstname'] = $firstname;
$_SESSION['lastname'] = $lastname;
$_SESSION['cpnumber'] = $cpnumber;
$_SESSION['email'] = $email;
// Note: Avoid storing passwords in session for security reasons.

// Redirect to another page or perform further actions

// For example, to display the submitted data:
echo "Username: " . $username . "<br>";
echo "First name: " . $firstname . "<br>";
echo "Last name: " . $lastname . "<br>";
echo "Cellphone Number: " . $cpnumber . "<br>";
echo "Email: " . $email . "<br>";
// Note: Do not display or echo the password for security reasons.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Questions Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 50px;
        }
        .form-container {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        .form-title {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="form-container">
                    <h2 class="form-title">Security Questions Form</h2>
                    <form action="registerHANDLER.php" method="POST">
                        <div class="form-group">
                            <label for="mother_maiden_name">Mother's Maiden Name:</label>
                            <input type="text" class="form-control" id="mother_maiden_name" name="mother_maiden_name" required>
                        </div>
                        <div class="form-group">
                            <label for="first_school_attended">First School Attended:</label>
                            <input type="text" class="form-control" id="first_school_attended" name="first_school_attended" required>
                        </div>
                        <div class="form-group">
                            <label for="favorite_vacation_destination">Favorite Vacation Destination:</label>
                            <input type="text" class="form-control" id="favorite_vacation_destination" name="favorite_vacation_destination" required>
                        </div>
                        <div class="form-group">
                            <label for="favorite_food">Favorite Food:</label>
                            <input type="text" class="form-control" id="favorite_food" name="favorite_food" required>
                        </div>
                        <div class="form-group">
                            <label for="city_of_birth">City of Birth:</label>
                            <input type="text" class="form-control" id="city_of_birth" name="city_of_birth" required>
                        </div>
                        <div class="form-group">
                            <label for="first_job">First Job:</label>
                            <input type="text" class="form-control" id="first_job" name="first_job" required>
                        </div>
                        <div class="form-group">
                            <label for="favorite_movie">Favorite Movie:</label>
                            <input type="text" class="form-control" id="favorite_movie" name="favorite_movie" required>
                        </div>
                        <div class="form-group">
                            <label for="first_pet_name">First Pet Name:</label>
                            <input type="text" class="form-control" id="first_pet_name" name="first_pet_name" required>
                        </div>
                        <div class="form-group">
                            <label for="favorite_book">Favorite Book:</label>
                            <input type="text" class="form-control" id="favorite_book" name="favorite_book" required>
                        </div>
                        <div class="form-group">
                            <label for="childhood_nickname">Childhood Nickname:</label>
                            <input type="text" class="form-control" id="childhood_nickname" name="childhood_nickname" required>
                        </div>
                        <!-- You can include a hidden input field to pass the UserID if needed -->
                        <!-- <input type="hidden" name="userid" value="<?php echo $userid; ?>"> -->
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
