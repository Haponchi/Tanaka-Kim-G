<?php 
require 'adminCONX.php';
session_start();

$userID = $_SESSION['userID'];

// Check if a file is uploaded
if (!empty($_FILES['image']['name'])) {
    if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        $folder = 'Images/'.$file_name;

        // Move uploaded file to the specified folder
        if(move_uploaded_file($tempname, $folder)){
            // Update the 'Picture' column in the user table
            $query = "UPDATE user SET Picture = :file_name WHERE userID = :userID";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':file_name', $file_name);
            $stmt->bindParam(':userID', $userID);

            // Execute the query to update the picture
            if (!$stmt->execute()) {
                echo "Error updating picture: " . $stmt->errorInfo()[2];
                exit();
            }

            // Log the audit trail for updating the picture
            $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:userID, 'Update Picture')";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bindParam(':userID', $userID);
            if (!$stmt->execute()) {
                echo "Error logging audit trail: " . $stmt->errorInfo()[2];
                exit();
            }
        } else {
            echo "Error uploading file.";
            exit();
        }
    } else {
        echo "Error uploading file: " . $_FILES['image']['error'];
        exit();
    }
}

// Now update cell phone number and email if provided
if (!empty($_POST['cellphonenumber']) || !empty($_POST['email'])) {
    $cellphonenumber = $_POST['cellphonenumber'];
    $email = $_POST['email'];

    // Check if email or cell phone number already exist
    $checkQuery = "SELECT * FROM user WHERE (CpNO = :cellphonenumber OR Email = :email) AND userID != :userID";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bindParam(':cellphonenumber', $cellphonenumber);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':userID', $userID);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<script>alert('Email or phone number already exists.'); window.location.href = 'userRegistered.php';</script>";
        exit();
    }

    // Build the query to update user's cell phone number and email
    $query = "UPDATE user SET ";
    if (!empty($_POST['cellphonenumber'])) {
        $query .= "CpNO = :cellphonenumber ";
    }
    if (!empty($_POST['email'])) {
        $query .= (!empty($_POST['cellphonenumber']) ? ", " : "") . "Email = :email";
    }
    $query .= " WHERE userID = :userID";

    // Execute the query to update user's cell phone number and email
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':userID', $userID);
    if (!empty($_POST['cellphonenumber'])) {
        $stmt->bindParam(':cellphonenumber', $cellphonenumber);
    }
    if (!empty($_POST['email'])) {
        $stmt->bindParam(':email', $email);
    }
    if ($stmt->execute()) {
        echo "<script>alert('Update Successfully..'); window.location.href = 'userRegistered.php';</script>";
        exit();
    } else {
        echo "Error updating record: " . $stmt->errorInfo()[2];
        exit();
    }
} else {
    echo "No email or cell phone number provided.";
    exit();
}

// Close the database connection
$conn = null;
?>
