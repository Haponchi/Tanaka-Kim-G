<?php 
session_start();

require 'adminCONX.php';

$barberID = $_GET['barberID'];
$sql = "UPDATE barbers SET Availability = 'Available' WHERE barberID = :barberID";
    
$stmt = $conn->prepare($sql);
$stmt->bindParam(':barberID', $barberID);

if ($stmt->execute()) {
    echo "<script>alert('Update Successfully.'); window.location.href = 'registeredbarber.php';</script>";
} else {
    echo "Error updating availability: " . $stmt->errorInfo()[2];
}

// Close the database connection
$conn = null;
?>
