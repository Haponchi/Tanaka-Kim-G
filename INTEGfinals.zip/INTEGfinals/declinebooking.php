<?php
session_start();
require 'adminCONX.php';

// Get the BookingID from the session
$bookingID = $_SESSION['BookingID'];

// SQL update statement
$sql = "UPDATE booking SET Status = 'Cancelled' WHERE BookingID = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters
$stmt->bind_param("s", $bookingID);

// Execute the statement
if ($stmt->execute()) {
	header("Location: bookingadmin.php");
} else {
    echo "Error updating booking status: " . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
