<?php   
session_start();
require 'customerCONX.php';

$barberID = $_SESSION['barberID'];

$userID = $_SESSION['c']; // Assuming 'c' is the correct session key for user ID

$serviceID = $_SESSION['serviceID'];

$sql = "SELECT * FROM barbers WHERE barberID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$barberID]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $barberRow = $result;
} else {
    // Handle case when no barber is found
}

$insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Cancelled Barber {$barberRow['Name']} {$barberRow['Lname']}')";
$insertStmt = $conn->prepare($insert_sql);
$insertStmt->execute([$userID]);

header("Location: choosebarber.php");
?>
