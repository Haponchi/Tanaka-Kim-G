<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup | Brilliante</title>
    <link rel="stylesheet" href="form2.css">
    <link rel="icon" href="images/logo.png" type="image/png"> <!-- Change type to image/png -->
    <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="index.php" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
      <a href="about.html">About Us</a>
      <a href="pagepolicy.html">Policy</a>
      <a href="#"><b>Book Now</b></a>
    </div>
  </nav>
  <div class="about">
    <img src="Images/about.jpg">
    <div class="regis-container">
    <div class="regis-form">   
    <form action="registerHANDLER.php" method="POST" enctype="multipart/form-data">
            <h1 style = "margin-left:-120px; margin-top:55px">Register</h1><br>
            <div class="form-columns">
                <!-- First Column -->
                <div class="column" style = "margin-left:-200px">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" placeholder = "Username" required pattern="^[a-zA-Z]+$">
                    </div>
                    <div class="form-group">
                        <label for="firstname">First Name</label>
                        <input type="text" name="firstname" placeholder = "First name" required pattern="^[a-zA-Z\s.]+$">
                    </div>
                    <div class="form-group">
                        <label for="lastname">Last Name</label>
                        <input type="text" name="lastname" placeholder = "Last name" required pattern="^[a-zA-Z\s.]+$">
                    </div>
                </div>
                <!-- Second Column -->
                <div class="column" style = "margin-left:10px; margin-right:-10px" >
                    <div class="form-group">
                        <label for="phone">Cellphone Number</label>
                        <input type="text" name="cpnumber" placeholder = "Cellphone no." required pattern="09\d{9}" title="follow this format 09XXXXXXXXX">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" placeholder = "Email" name="email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" placeholder = "Password" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$" title="Password should contain at least 8 characters with 1 uppercase and 1 special character.">
                    </div>
                </div>
            </div>
            <br>
            <div class="form-group" style = "margin-left: -110px">
                <button type="submit">Register</button>
            </div>
            <div class="form-group" style = "width: 400px; margin-left: -90px">
                <p>Already have an account? <a href="form2.php">Login</a></p>
            </div>
        </form>
    </div>
</div>


</div>

</div>
        <footer class="footer" style = "margin-top: -50px">
            <div class="footer-content">
              <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
              <div class="footer-title">
                <h2>Brilliante Barbershop</h2>
                <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
              </div>
              <div class="footer-links">
                <h3>Links</h3>
                <a href="index.php">Home  |</a>
                <a href="about.html">About Us  |</a>
                <a href="pagepolicy.html">Policy</a>
                <div class="social-icons">
                  <br>
                  <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
                  <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
                </div>
                <div class = "contact">
                  <br><br><h2>Contact Us</h2>
                  For inquiries and appointments, please contact us at:<br>
                  Phone: 0917 560 0119</p>
                  </div>
              </div>   
            </div>   
            <br>
            <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
          </footer>
</body>
</html>
