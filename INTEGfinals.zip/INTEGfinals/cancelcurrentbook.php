<?php 
session_start();

require 'adminCONX.php';

$bookingID = $_POST['BookingID'];

 ?>