<?php
session_start();
$userID = $_SESSION['c'];

// Include database connection and other required files
require 'customerCONX.php';

// Check if the verification code is submitted via POST
if (isset($_POST['code'])) {
    // Retrieve the verification code submitted via POST
    $submittedCode = $_POST['code'];

    // Retrieve the verification code and user type stored in the database for the user
    $getVerificationCodeQuery = "SELECT Code, Type FROM user WHERE UserID = ?";
    $stmt = $conn->prepare($getVerificationCodeQuery);
    $stmt->execute([$userID]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($userData) {
        $verificationCode = $userData['Code'];
        $userType = $userData['Type'];

        // Check if the submitted code matches the stored verification code
        if ($submittedCode === $verificationCode) {
            // Verification successful

            if ($userType === 'customer') {
                // User is a customer
                // Insert successful verification action in the audit log
                $insertAuditLogSql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Login')";
                $stmtInsertAuditLog = $conn->prepare($insertAuditLogSql);
                $stmtInsertAuditLog->execute([$userID]);

                echo "<script>alert('Verification successful! You may now proceed to the home page.'); window.location.href = 'customerPAGE.php';</script>";
            } else {
                // User is an admin
                echo "<script>alert('Verification successful! You may now proceed to the admin dashboard.'); window.location.href = 'adminHOMEE.php';</script>";
            }
            exit();
        } else {
            // Verification failed
            // Insert failed verification action in the audit log
            $insertAuditLogSql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Failed Verification')";
            $stmtInsertAuditLog = $conn->prepare($insertAuditLogSql);
            $stmtInsertAuditLog->execute([$userID]);

            echo "<script>alert('Verification failed. Please enter the correct verification code.'); window.location.href = 'verify.php';</script>";
            exit();
        }
    } else {
        // User not found in the database
        echo "<script>alert('User not found.'); window.location.href = 'login.php';</script>";
        exit();
    }
} else {
    // Handle the case where the verification code is not submitted via POST
    echo "<script>alert('Verification code not found.'); window.location.href = 'verify.php';</script>";
    exit();
}
?>
