<?php
session_start();

require 'customerCONX.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/vendor/autoload.php'; // Include Composer's autoload file for PHPMailer

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM user WHERE Email = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$email]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $id = $result['UserID'];

    // Fetch failed login data from the failedlogin table
    $failedlogin_sql = "SELECT * FROM failedlogin WHERE UserID = ?";
    $stmt_failedlogin = $conn->prepare($failedlogin_sql);
    $stmt_failedlogin->execute([$id]);
    $failedlogin_data = $stmt_failedlogin->fetch(PDO::FETCH_ASSOC);

    if (!$failedlogin_data) {
        // No entry exists, create one
        $insert_failedlogin_sql = "INSERT INTO failedlogin (UserID, Counter, Cooldown) VALUES (?, 0, NULL)";
        $stmt_insert_failedlogin = $conn->prepare($insert_failedlogin_sql);
        $stmt_insert_failedlogin->execute([$id]);

        // Fetch the failed login data again    
        $stmt_failedlogin->execute([$id]);
        $failedlogin_data = $stmt_failedlogin->fetch(PDO::FETCH_ASSOC);
    }

    $failed_attempts = $failedlogin_data['Counter'];
    $cooldown = $failedlogin_data['Cooldown'];

    if ($failed_attempts >= 3 && time() < strtotime($cooldown)) {
        // User is under cooldown
        echo "<script>alert('You have reached the maximum number of login attempts. Please try again later at $cooldown.'); window.location.href = 'index.php';</script>";
        exit();
    }

    if (password_verify($password, $result['Password'])) {
        $_SESSION['c'] = $result['UserID'];
        $_SESSION['alertShown'] = false; // Reset alertShown for displaying the booking count alert

        // Check if MFA is enabled for the user
        if ($result['MFAEnabled'] == 1) {
            $verificationCode = bin2hex(random_bytes(6)); // Generates a 6-character hexadecimal code

            // Fetch user's first name from the database
            $firstname = $result['Fname']; // Replace 'Firstname' with the actual column name

            // Send verification email with the user's first name and verification code
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Set the SMTP server
                $mail->SMTPAuth = true;
                $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
                $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Email Verification';
                $mail->Body    = "Hi $firstname,<br><br>Your verification code is: <strong>$verificationCode</strong><br><br>Please enter this code on the login page to activate your account.";

                $mail->send();
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                exit();
            }

            // Store the verification code in the user's record
            $update_code_sql = "UPDATE user SET Code = :code WHERE UserID = :userID";
            $stmt_update_code = $conn->prepare($update_code_sql);
            $stmt_update_code->bindParam(':code', $verificationCode);
            $stmt_update_code->bindParam(':userID', $id);
            $stmt_update_code->execute();

            // Reset the failed login counter on successful login
            $reset_counter_sql = "UPDATE failedlogin SET Counter = 0, Cooldown = NULL WHERE UserID = ?";
            $stmt_reset_counter = $conn->prepare($reset_counter_sql);
            $stmt_reset_counter->execute([$id]);

            echo "<script>alert('Verify your account. Verification code sent.'); window.location.href = 'verify.php';</script>";
            exit();
        } else {
            // Reset the failed login counter on successful login
            $reset_counter_sql = "UPDATE failedlogin SET Counter = 0, Cooldown = NULL WHERE UserID = ?";
            $stmt_reset_counter = $conn->prepare($reset_counter_sql);
            $stmt_reset_counter->execute([$id]);

            // Redirect based on user type
            if ($result['Type'] === 'customer') {
                echo "<script>alert('Login successful.'); window.location.href = 'customerPAGE.php';</script>";

                $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Login')";
                $stmt_insert = $conn->prepare($insert_sql);
                $stmt_insert->execute([$id]);
            } else if ($result['Type'] === 'admin') {
                echo "<script>alert('Login successful.'); window.location.href = 'adminHOMEE.php';</script>";
            }
            exit();
        }
    } else {
        // Increment failed attempts counter
        $counter = 3 - ($failed_attempts + 1);

        // Insert into audit table for customer type users only
        if ($result['Type'] === 'customer') {
            $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Failed Login')";
            $stmt_insert = $conn->prepare($insert_sql);
            $stmt_insert->execute([$id]);
        }

        $update_sql = "UPDATE failedlogin SET Counter = Counter + 1 WHERE UserID = ?";
        $stmt_update = $conn->prepare($update_sql);
        $stmt_update->execute([$id]);

        // Refresh the failed_attempts count after the update
        $stmt_failedlogin->execute([$id]);
        $failedlogin_data = $stmt_failedlogin->fetch(PDO::FETCH_ASSOC);
        $failed_attempts = $failedlogin_data['Counter'];

        if ($failed_attempts >= 3) {
            // Set cooldown time (30 minutes)
            $cooldownTime = date('Y-m-d H:i:s', strtotime('+30 minutes'));
            $update_cooldown_sql = "UPDATE failedlogin SET Cooldown = ? WHERE UserID = ?";
            $stmt_update_cooldown = $conn->prepare($update_cooldown_sql);
            $stmt_update_cooldown->execute([$cooldownTime, $id]);
        }

        echo "<script>alert('Incorrect password. Remaining attempts: $counter.'); window.location.href = 'index.php';</script>";
        exit();
    }
} else {
    // Email not found
    echo "<script>alert('Email not found. Please check your email and try again.'); window.location.href = 'index.php';</script>";
}

// Close connection
$stmt->closeCursor();
$conn = null;
?>
