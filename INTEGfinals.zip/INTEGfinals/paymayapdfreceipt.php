<?php
// Include TCPDF library
require_once('tcpdf/tcpdf.php');

session_start();

require 'customerCONX.php';

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];
$price = $_SESSION['price'];
$referenceNumber = $_SESSION['referenceNumber'];

$sql = "SELECT * FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id]);

if ($stmt->rowCount() > 0) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "User details not found.";
    exit();
}

$sql = "SELECT * FROM user WHERE Type = 'admin'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "Admin details not found.";
    exit();
}

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Brilliante Receipt');
$pdf->SetTitle('Brilliante Receipt');
$pdf->SetSubject('Brilliante Receipt');
$pdf->SetKeywords('TCPDF, PDF, receipt');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Add Brilliante logo
$logoUrl = 'Images/logo.jpg'; // Adjusted logo path
$pdf->Image($logoUrl, 10, 10, 30, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
$pdf->Ln(15);

// Header
$pdf->SetFont('helvetica', 'B', 20);
$pdf->Cell(0, 15, 'Brilliante Receipt', 0, 1, 'C');
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(0, 10, 'Receipt generated on ' . date('Y-m-d'), 0, 1, 'C');

// Line break
$pdf->Ln(10);

// Receipt details in a styled box
$html = '
<style>
    .container {
        background-color: #ffffff;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        width: 80%;
        margin: auto;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .header {
        background-color: #333;
        color: #fff;
        padding: 10px;
        border-bottom: 1px solid #333;
        text-align: center;
        font-weight: bold;
    }
    .body {
        padding: 20px;
    }
    .footer {
        background-color: #333;
        color: #fff;
        padding: 10px;
        border-top: 1px solid #333;
        text-align: center;
    }
    .input-box {
        margin-bottom: 10px;
    }
    .details {
        display: inline-block;
        width: 150px;
        font-weight: bold;
    }
    .text {
        display: inline-block;
        width: calc(100% - 160px);
    }
</style>

<div class="container">
    <div class="header">Brilliante Barbershop</div>
    <div class="body">
        <div class="input-box">
            <span class="details">Booking ID:</span>
            <span class="text">' . $bookingID . '</span>
        </div>
        <div class="input-box">
            <span class="details">Cost of Service:</span>
            <span class="text">' . number_format($price, 2) . '</span>
        </div>
        <div class="input-box">
            <span class="details">Receiver Name:</span>
            <span class="text">' . $admin['Fname'] . ' ' . $admin['Lname'] . '</span>
        </div>
        <div class="input-box">
            <span class="details">Sender Name:</span>
            <span class="text">' . $user['Fname'] . ' ' . $user['Lname'] . '</span>
        </div>
        <div class="input-box">
            <span class="details">Receiver Number:</span>
            <span class="text">' . $admin['CpNO'] . '</span>
        </div>
        <div class="input-box">
            <span class="details">Sender Number:</span>
            <span class="text">' . $user['CpNO'] . '</span>
        </div>
        <div class="input-box">
            <span class="details">Reference Number:</span>
            <span class="text">' . $referenceNumber . '</span>
        </div>
        <div class="input-box">
            <span class="details">Amount Paid:</span>
            <span class="text">' . number_format($price, 2) . '</span> <!-- Adjusted variable name -->
        </div>
    </div>
    <div class="footer">Thank you for your payment!</div>
</div>
';

$pdf->writeHTML($html, true, false, true, false, '');

// Close and output PDF document
$pdf->Output('Brilliante_Receipt.pdf', 'D');

// Close the database connection
$conn = null;
?>
