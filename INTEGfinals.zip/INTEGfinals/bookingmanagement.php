<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Date Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Luxon Date Picker CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .form-control, .btn {
            border-radius: 25px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center">Manage Booking Dates</h2>
    <form id="disableDateForm">
        <div class="form-group">
            <label for="month">Select Month</label>
            <select class="form-control" id="month" name="month">
                <option value="01">January</option>
                <option value="02">February</option>
                <option value="03">March</option>
                <option value="04">April</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">August</option>
                <option value="09">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>
        </div>
        <div class="form-group">
            <label for="date">Select Date</label>
            <input type="text" class="form-control" id="date" name="date" placeholder="Choose a date">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Disable Date</button>
    </form>
    <form id="enableDateForm" class="mt-4">
        <div class="form-group">
            <label for="disabledDates">Select Disabled Date to Enable</label>
            <select class="form-control" id="disabledDates" name="disabledDate">
                <!-- Options will be populated dynamically -->
            </select>
        </div>
        <button type="submit" class="btn btn-danger btn-block">Enable Date</button>
    </form>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Luxon Date Picker JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script>
$(document).ready(function() {
    // Initialize date picker
    $('#date').datepicker({
        format: 'yyyy-mm-dd'
    });

    // Fetch and populate disabled dates
    function fetchDisabledDates() {
        $.get('getDisabledDates.php', function(response) {
            const disabledDates = JSON.parse(response);
            $('#disabledDates').empty();
            disabledDates.forEach(function(date) {
                $('#disabledDates').append(`<option value="${date.date}">${date.date}</option>`);
            });
        });
    }

    fetchDisabledDates();

    // Handle form submission to disable a date
    $('#disableDateForm').submit(function(event) {
        event.preventDefault();
        $.post('disableDate.php', $(this).serialize(), function(response) {
            alert(response);
            fetchDisabledDates();
        });
    });

    // Handle form submission to enable a date
    $('#enableDateForm').submit(function(event) {
        event.preventDefault();
        $.post('enableDate.php', $(this).serialize(), function(response) {
            alert(response);
            fetchDisabledDates();
        });
    });
});
</script>
</body>
</html>
