<?php 
require 'customerCONX.php';
session_start(); 
$id = $_SESSION['c'];

// Retrieve service ID based on the customer ID
$sql = "SELECT s.ServiceID, s.Type FROM Services s WHERE s.UserID = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();
$serviceRow = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if serviceRow is not empty (i.e., a service is found)
if ($serviceRow) {
    // Store the service ID in the session
    $_SESSION['serviceID'] = $serviceRow['ServiceID'];
} else {
    // Handle the case where no service is found
    $_SESSION['serviceID'] = null;
}

// Get the service ID from the session
$serviceID = $_SESSION['serviceID'];

$limit = 30; // Number of records per page
$selectedDate = isset($_GET['date']) ? $_GET['date'] : ''; // Get the selected date or set to empty
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all'; // Get filter parameter or default to 'all'

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate offset for pagination

// Ensure $limit and $offset are integers
$limit = (int)$limit;
$offset = (int)$offset;

// Initialize an empty array to store unique booking IDs
$uniqueBookingIDs = array();

// Check if a specific date is selected and store it in the session
if (isset($_GET['date'])) {
    $_SESSION['selectedDate'] = $_GET['date'];
} else {
    // If no date is selected, unset the session variable
    unset($_SESSION['selectedDate']);
}

// Retrieve the selected date from the session
$selectedDate = isset($_SESSION['selectedDate']) ? $_SESSION['selectedDate'] : '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Report</title>
    <link rel="icon" href="images/logo.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body{
            font-family: Poppins;
            font-size: 17px;
        }
        .cancellation-note {
            color: red;
            font-weight: bold;
            text-align: left;
            margin-bottom: 20px;
        }
        .cooldown-note {
            color: red;
            text-align: left;
            margin-bottom: 20px;
        }
        th, td{
            text-align: center;
        }
        .container {
            max-width: 1500px; /* Increase max-width to desired value */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Transaction Record</h1>
    <div class="form-group">
        <h5 for="datepicker">Select Date:</h5>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
    </div>
    <form method="get" action="">
        <button type="submit" class="btn btn-primary mb-4">Show All Payments</button>
    </form>
    <p>
        Please note that cancellations of bookings cannot be refunded. Additionally, bookings cannot be canceled within one day before the scheduled date. We encourage our customers to consider their bookings carefully, as refunds cannot be issued once a cancellation is made. Thank you for your understanding.
    </p>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Payment ID</th>
                <th>Barber ID</th>
                <th>Service</th>
                <th>Schedule</th>
                <th>Method</th>
                <th>Date Paid</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if ($serviceID) {
            if ($selectedDate) {
                // Query to retrieve bookings associated with the service ID and selected date
                $sql = "SELECT
                            b.BookingID AS booking_id,
                            b.barberID,
                            b.ServiceID AS service_id,
                            b.Status AS booking_status,
                            b.Location AS booking_location,
                            b.Creation AS booking_creation,
                            s.UserID AS user_id,
                            s.Type AS service_type,
                            s.Price AS service_price,
                            p.PaymentID AS payment_id,
                            p.Method AS payment_method,
                            p.DatePaid AS payment_datepaid,
                            p.Amount AS payment_amount,
                            p.Status AS payment_status,
                            b.Date AS booking_date,
                            b.Time AS booking_time
                        FROM
                            booking b
                        LEFT JOIN
                            services s ON b.ServiceID = s.ServiceID
                        LEFT JOIN
                            payment p ON b.BookingID = p.BookingID
                        WHERE
                            s.UserID = :id AND DATE(b.Creation) = :selectedDate LIMIT :limit OFFSET :offset";
            } else {
                // Query to retrieve all bookings associated with the service ID
                $sql = "SELECT
                            b.BookingID AS booking_id,
                            b.barberID,
                            b.ServiceID AS service_id,
                            b.Status AS booking_status,
                            b.Location AS booking_location,
                            b.Creation AS booking_creation,
                            s.UserID AS user_id,
                            s.Type AS service_type,
                            s.Price AS service_price,
                            p.PaymentID AS payment_id,
                            p.Method AS payment_method,
                            p.DatePaid AS payment_datepaid,
                            p.Amount AS payment_amount,
                            p.Status AS payment_status,
                            b.Date AS booking_date,
                            b.Time AS booking_time
                        FROM
                            booking b
                        LEFT JOIN
                            services s ON b.ServiceID = s.ServiceID
                        LEFT JOIN
                            payment p ON b.BookingID = p.BookingID
                        WHERE
                            s.UserID = :id LIMIT :limit OFFSET :offset";
            }

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':id', $id);
            if ($selectedDate) {
                $stmt->bindParam(':selectedDate', $selectedDate);
            }
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();  

            // Fetch data
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Initialize variables
            $currentMonth = '';

            foreach ($result as $row) {
                $regDate = date('F Y', strtotime($row['booking_creation']));
                // Check if the booking ID is already in the array
                if (!isset($uniqueBookingIDs[$row['booking_id']])) {
                    $uniqueBookingIDs[$row['booking_id']] = true; // Add booking ID to the array
                    // Check if a new month is encountered
                    if ($currentMonth != $regDate) {
                        $currentMonth = $regDate;
                        echo '<tr><td colspan="11" style="text-align: left"><strong>' . $currentMonth . '</strong></td></tr>';
                    }
                    // Add data for each record
                    echo '<tr>';
                    echo '<td>' . $row['payment_id'] . '</td>';
                    echo '<td>' . $row['barberID'] . '</td>';
                    echo '<td>' . $row['service_type'] . '</td>';
                    echo '<td>' . (isset($row['booking_date']) ? $row['booking_date'] : '') . ' ' . (isset($row['booking_time']) ? $row['booking_time'] : '') . '</td>';
                    echo '<td>' . $row['payment_method'] . '</td>';
                    echo '<td>' . $row['payment_datepaid'] . '</td>';
                    echo '<td>' . $row['payment_amount'] . '</td>';
                    echo '<td>' . $row['payment_status'] . '</td>';
                    echo '<td>';
                    // Check if booking status is not "Cancelled" to enable the cancel button
                    if ($row['booking_status'] != 'Cancelled' && $row['booking_status'] != 'Done') {
                        echo '<form method="post" action="cancelTRANSACTION.php">';
                        echo '<input type="hidden" name="booking_id" value="' . $row['booking_id'] . '">';
                        echo '<button class="btn btn-danger btn-sm">Cancel</button>';
                        echo '</form>';
                    } else {
                        // Booking already cancelled, disable the button
                        echo '<button class="btn btn-danger btn-sm" style="color: black;" disabled>Cancelled</button>';
                    }
                    echo '</td>';
                    echo '</tr>';
                }
            }
        }
        ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="customerPAGE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });
    });
</script>
</body>
</html>
