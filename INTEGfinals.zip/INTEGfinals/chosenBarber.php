<?php
session_start();

require 'customerCONX.php';

// Check if 'barberID' is set in $_POST
if (isset($_POST['barberID'])) {
    // If 'barberID' is set in $_POST, assign it to $barberID and update session variable
    $barberID = $_POST['barberID'];
    $_SESSION['barberID'] = $barberID;
} else {
    // If 'barberID' is not set in $_POST, assign the session barber ID to $barberID
    $barberID = $_SESSION['barberID'];
}

$userID = $_SESSION['c']; // Assuming 'c' is the correct session key for user ID

$serviceID = $_SESSION['serviceID'];

$sql = "SELECT * FROM barbers WHERE barberID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$barberID]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $barberName = $result['Name'] . " " . $result['Lname'];
    $_SESSION['barberName'] = $barberName;
} else {
    // Handle case when no barber is found
}

// $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, ?)";
// $stmt = $conn->prepare($insert_sql);
// $stmt->execute([$userID, "Chosen Barber " . $result['Name'] . " " . $result['Lname']]);

header("Location: book.php");
?>
