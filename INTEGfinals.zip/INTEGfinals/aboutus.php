<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Brilliante</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="images/logo.png" type="image/png"> <!-- Change type to image/png -->
    <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="customerPAGE.php" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
            <a href="customerPAGE.php">Home   |</a>
      <a href="aboutus.php"><b>About Us</b></a>
      <a href="policy.php">Policy</a>
    </div>
  </nav>
    <div class = "about">
        <img src = "Images/about.jpg">
        <h1>About Brilliante</h1>
        <p>Welcome to the Brilliante Barber Reservation System!<br>

            Our system is designed to make booking barber appointments convenient and hassle-free. Located in Baliwag, Bulacan, our barber shop offers high-quality grooming services for men.
            
            With our online reservation system, you can easily schedule your haircut appointments. Simply choose your preferred date, time, and barber, and we'll take care of the rest!
            
            Our team is committed to providing exceptional customer service and ensuring that you have a pleasant experience during your visit. Whether you're looking for a classic haircut, beard grooming, or a relaxing shave, our skilled barbers are here to help you look and feel your best.
            
            <br>Thank you for choosing our Barber Reservation System. We look forward to serving you!</p>
        </div>
        <footer class="footer">
            <div class="footer-content">
              <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
              <div class="footer-title">
                <h2>Brilliante Barbershop</h2>
                <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
              </div>
              <div class="footer-links">
                <h3>Links</h3>
                <a href="customerPAGE.php">Home  |</a>
                <a href="aboutus.php">About Us  |</a>
                <a href="policy.html">php</a>
                <div class="social-icons">
                  <br>
                  <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
                  <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
                </div>
                <div class = "contact">
                  <br><br><h2>Contact Us</h2>
                  For inquiries and appointments, please contact us at:<br>
                  Phone: 0917 560 0119</p>
                  </div>
              </div>   
            </div>   
            <br>
            <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
          </footer>
</body>
</html>

