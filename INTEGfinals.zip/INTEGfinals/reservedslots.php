<?php
require('customerCONX.php');
session_start();

$id = $_SESSION['c'];

$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Pagination
$limit = 30; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

// Calculate offset for pagination
$offset = ($page - 1) * $limit;

// Mapping of time slot to start time
$timeSlots = [
    "10am - 11am" => "10:00:00",
    "11am - 12pm" => "11:00:00",
    "12pm - 1pm" => "12:00:00",
    "1pm - 2pm" => "13:00:00",
    "3pm - 4pm" => "15:00:00",
    "5pm - 6pm" => "17:00:00",
    "6pm - 7pm" => "18:00:00"
];

// Fetch all barbers
$sqlBarbers = "SELECT barberID, CONCAT(Name, ' ', Lname) AS barber_name FROM barbers";
$stmtBarbers = $conn->prepare($sqlBarbers);
$stmtBarbers->execute();
$barbers = $stmtBarbers->fetchAll(PDO::FETCH_ASSOC);

// Fetch all bookings to pass to the JavaScript
$allBookings = [];
$sql = "SELECT b.Date AS Date, b.Time AS Time, b.barberID, b.Status AS booking_status
        FROM booking b
        INNER JOIN services s ON b.ServiceID = s.ServiceID
        WHERE s.UserID != ? AND b.Status = 'Reserved'
        ORDER BY b.Date, b.Time";
$stmt = $conn->prepare($sql);
$stmt->bindValue(1, $id, PDO::PARAM_INT);
$stmt->execute();
$allBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Close the database connection
$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png" type="image/png">
    <title>All Reserved Slots</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <!-- FullCalendar CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">

    <style>
        body {
            font-family: "Poppins";
        }
        .time-slot {
            padding: 10px;
            margin: 5px;
            cursor: pointer;
            display: inline-block;
            border-radius: 5px;
            font-weight: bold;
        }
        .time-slot.available {
            background-color: #d4edda;
            border: 2px solid #155724;
        }
        .time-slot.unavailable {
            background-color: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        .legend {
            margin-top: 20px;
        }
        .legend .legend-item {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }
        .legend .color-box {
            width: 20px;
            height: 20px;
            display: inline-block;
            margin-right: 10px;
        }
        .available-color {
            background-color: #d4edda;
            border: 2px solid #155724;
        }
        .unavailable-color {
            background-color: #f8d7da;
            border: 2px solid #f5c6cb;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h1 class="mb-4">Reserved Slots</h1>
    
    <div class="form-group">
        <label for="barberSelect">Choose Barber:</label>
        <select class="form-control" id="barberSelect">
            <option value="all">All Barbers</option>
            <?php foreach ($barbers as $barber): ?>
                <option value="<?php echo $barber['barberID']; ?>"><?php echo $barber['barber_name']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div id="calendar"></div>
    <div class="legend">
        <div class="legend-item">
            <div class="color-box available-color"></div> Available
        </div>
        <div class="legend-item">
            <div class="color-box unavailable-color"></div> Reserved
        </div>
    </div>
    
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="customerPAGE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>

    <div id="time-slots" class="mt-4"></div>
</div>

<!-- Modal -->
<div class="modal fade" id="timeSlotModal" tabindex="-1" aria-labelledby="timeSlotModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="timeSlotModalLabel">Time Slots for <span id="selected-date"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-time-slots">
                <!-- Time slots will be appended here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- FullCalendar JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>
<!-- Initialize FullCalendar -->
<script>
$(document).ready(function() {
    var allBookings = <?php echo json_encode($allBookings); ?>;
    var timeSlots = <?php echo json_encode($timeSlots); ?>;

    function updateCalendar(barberID) {
        $('#calendar').fullCalendar('removeEvents');
        var events = allBookings.map(function(booking) {
            var eventTime = timeSlots[booking.Time] ? timeSlots[booking.Time] : booking.Time;
            var startDateTime = booking.Date + 'T' + eventTime;
            return {
                // title: 'Reserved',
                // start: startDateTime,
                // barberID: booking.barberID
            };
        });
        if (barberID !== 'all') {
            events = events.filter(function(event) {
                return event.barberID == barberID;
            });
        }
        $('#calendar').fullCalendar('addEventSource', events);
    }

    $('#calendar').fullCalendar({
        header: {
            left: 'title',
            center: '',
            right: 'prev,next today'
        },
        defaultDate: '<?php echo $selectedDate; ?>',
        navLinks: true, // can click day/week names to navigate views
        editable: false,
        eventLimit: true, // allow "more" link when too many events
        validRange: {
            start: moment().format('YYYY-MM-DD') // Disable past dates
        },
        events: [],
        dayClick: function(date, jsEvent, view) {
            var selectedDate = date.format('YYYY-MM-DD');
            $('#selected-date').text(selectedDate);
            $('#modal-time-slots').html('<h4>Time Slots for ' + selectedDate + ':</h4>');

            var selectedBarber = $('#barberSelect').val(); // Get selected barber ID

            var bookedSlots = {};
            allBookings.forEach(function(booking) {
                if (booking.Date === selectedDate && (selectedBarber === 'all' || booking.barberID == selectedBarber)) {
                    bookedSlots[timeSlots[booking.Time]] = true;
                }
            });

            $.each(timeSlots, function(key, value) {
                var slotClass = bookedSlots[value] ? 'unavailable' : 'available';
                $('#modal-time-slots').append('<div class="time-slot ' + slotClass + '">' + key + '</div>');
            });

            $('#timeSlotModal').modal('show');
        }
    });

    $('#barberSelect').on('change', function() {
        var selectedBarber = $(this).val();
        updateCalendar(selectedBarber);
    });

    // Initial calendar load
    // updateCalendar('all'); // Show all barbers' bookings initially
});
</script>

</body>
</html>
