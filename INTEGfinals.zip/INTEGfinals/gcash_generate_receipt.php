<?php
session_start();

// Function to generate reference number
function generateReferenceNumber() {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $referenceNumber = '';
    $length = 10;

    for ($i = 0; $i < $length; $i++) {
        $referenceNumber .= $characters[mt_rand(0, strlen($characters) - 1)];
    }

    $_SESSION['referenceNumber'] = $referenceNumber;
    return $referenceNumber;
}

require 'customerCONX.php';

$currentTimestamp = date("Y-m-d H:i:s"); // Get current timestamp in Y-m-d H:i:s format


$paymentID  = $_SESSION['paymentID'];
$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];
$price = $_SESSION['price'];

// Generate reference number
$referenceNumber = generateReferenceNumber();

$sql = "SELECT * FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id]);

if ($stmt->rowCount() > 0) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "User details not found.";
    exit();
}

$sql = "SELECT * FROM user WHERE Type = 'admin'";
$stmt = $conn->prepare($sql);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "Admin details not found.";
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Method | Brilliante</title>
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
            padding-top: 1px;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .gcash-logo {
            width: 100px;
            height: auto;
            margin-left: 10px;
        }
        .btn-custom {
            width: 100%;
/*            margin: 5px 0;*/
        }
        .input-box {
            margin-bottom: 1rem;
        }
        .input-box label {
            font-weight: bold;
        }
        .details {
            margin-bottom: 1rem;
        }
        .alert {
            margin-top: 1rem;
        }
        .btn-custom {
            color: #ffd700;
            border: none;
        }
        .btn-done {
            background-color: #2a6d2a; /* Dark green */
        }
        .btn-done:hover {
            background-color: #204f20; /* Darker green on hover */
        }
        .btn-download {
            background-color: #003366; /* Dark blue */
        }
        .btn-download:hover {
            background-color: #002244; /* Darker blue on hover */
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="card-title">GCASH RECEIPT</h3>
                <img src="Images/gcash.jpeg" class="gcash-logo" alt="GCash Logo">
            </div>
            <form action="customerPAGE.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="cost" value="<?php echo $Price; ?>">
                <div class="form-group">
                    <label for="bookingID">Payment ID:</label>
                    <input type="text" id="bookingID" name="bookingID" value="<?php echo $paymentID ; ?>" class="form-control" required disabled>
                </div>
                 <div class="form-group">
                    <label for="bookingID">Amount Due:</label>
                    <input type="text" id="bookingID" name="bookingID" value="<?php echo $price ; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="receivername">Total Amount Paid:</label>
                    <input type="text" id="receivername" name="receivername" value="<?php echo $price; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="sendername">Paid At:</label>
                    <input type="text" id="sendername" name="sendername" value="<?php echo $currentTimestamp; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="referenceNumber">Reference Number</label>
                    <input type="text" id="referenceNumber" name="referenceNumber" value="<?php echo $referenceNumber; ?>" class="form-control" required disabled>
                </div>
                <b>Thank you for your payment!</b>
                <div class="form-group d-flex justify-content-between">
                    <a href="gcashpdfreceipt.php" class="btn btn-download btn-custom"><i class="fas fa-file-download"></i> Download PDF</a>
                    <button type="submit" class="btn btn-done btn-custom"><i class="fas fa-check"></i> Done</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>

<?php 
$conn = null;
?>
