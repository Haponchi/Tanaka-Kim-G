<?php
session_start();
require('adminCONX.php');

$userID = $_SESSION['c']; // Assuming 'c' is the correct session key for user ID

// Fetch the top barber based on total earnings
$topBarberQuery = "
    SELECT 
        bar.Name, 
        bar.Lname,
        bar.Email,
        bar.CpNO,
        bar.Availability,
        bar.Picture,
        bar.barberID,
        SUM(p.Amount) as TotalEarnings
    FROM 
        payment p
    JOIN 
        booking b ON p.BookingID = b.BookingID
    JOIN 
        barbers bar ON b.barberID = bar.barberID
    GROUP BY 
        bar.barberID
    ORDER BY 
        TotalEarnings DESC
    LIMIT 1
";

$topBarberStmt = $conn->prepare($topBarberQuery);
$topBarberStmt->execute();
$topBarber = $topBarberStmt->fetch(PDO::FETCH_ASSOC);

// Fetch all earnings for each barber
$earningsQuery = "
    SELECT 
        b.barberID,
        CONCAT(b.Name, ' ', b.Lname) AS BarberName,
        SUM(p.Amount) AS TotalEarnings
    FROM 
        barbers b
    LEFT JOIN 
        booking bk ON b.barberID = bk.barberID
    LEFT JOIN 
        payment p ON bk.BookingID = p.BookingID
    WHERE
        p.Status = 'Paid'  -- Only consider paid bookings
    GROUP BY 
        b.barberID, BarberName;
";

$earningsStmt = $conn->prepare($earningsQuery);
$earningsStmt->execute();
$earnings = $earningsStmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Barber and Credential Report</title>
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <!-- Bootstrap Lux Theme CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <style>
        body {
            font-family: 'Poppins';
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 10px;
            max-width: 1500px;
            overflow-x: hidden; /* Add this line to hide horizontal scrollbar */
        }
        .table {
            margin-top: 20px;
        }
        .pagination {
            margin-top: 20px;
        }
        .btn-group {
            margin-right: 5px;
        }
        .btn-container {
            display: flex;
            gap: 10px;
        }
        .profile-pic {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }
        .top-barber-info {
            display: flex;
            align-items: center;
        }
        .top-barber-info img {
            margin-right: 20px;
        }
        .top-barber-details {
            display: flex;
            flex-wrap: wrap;
        }
        .top-barber-details div {
            margin-right: 20px;
        }
        .card, .table-container {
            width: 100%;
        }
        .form-inline {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        .form-inline .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .form-inline .form-group label {
            margin-right: 5px;
        }
        .form-inline .form-control {
            margin-right: 10px;
        }
        .table-container {
            overflow-x: auto;
        }
        .card-title {
            padding-left: 30px;
        }
        th, td {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container">
<h1>Barber Record</h1><br>
<div class="input-group-append">
    <?php if ($topBarber): ?>
    <div style="width: 450px;" class="card mb-4">
        <div class="card-header bg-primary text-white">
            Top Barber
        </div>
        <div class="card-body">
            <div class="top-barber-info">
                <div class="top-barber-details">
                    <div>
                        <h5 class="card-title"><?php echo $topBarber['Name'] . ' ' . $topBarber['Lname']; ?></h5>
                    </div>
                    <div>
                        <p class="card-text">Total Earnings: <?php echo $topBarber['TotalEarnings']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <div style="padding-left: 864px; padding-bottom: 20px;" >
        <a href="gen_barberrecord.php" class="btn btn-dark mt-3">Download PDF</a>
    </div>
</div>
    <?php endif; ?>

    <form action="" method="get" class="mb-3">
        <div class="input-group">
            <input type="text" class="form-control" id="searchInput" placeholder="Search by ID..." aria-label="Search" aria-describedby="button-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="button" id="button-addon2">Search</button>
            </div>
        </div>
    </form>

    <div class="table-container">
        <table id="barberTable" class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Number</th>
                    <th>Available</th>
                    <th>Service</th>
                    <th>Earnings</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // Pagination
            $limit = 4; // Number of records per page
            $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

            // Calculate offset for pagination
            $offset = ($page - 1) * $limit;

            // Query to retrieve data from the "barbers" table with pagination and service count
            $sql = "
                SELECT 
                    bar.*, 
                    COUNT(b.BookingID) as ServiceCount
                FROM 
                    barbers bar
                LEFT JOIN 
                    booking b ON bar.barberID = b.barberID
                WHERE 
                    bar.Status = 1
                GROUP BY 
                    bar.barberID
                LIMIT :limit OFFSET :offset
            ";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch data
            foreach ($result as $row) {
                echo '<tr>';
                echo '<td>' . $row['barberID'] . '</td>';
                echo '<td>' . $row['Name'] . ' ' . $row['Lname'] . '</td>';
                echo '<td>' . $row['Email'] . '</td>';
                echo '<td>' . $row['CpNO'] . '</td>';
                echo '<td>' . $row['Availability'] . '</td>';
                echo '<td>' . $row['ServiceCount'] . '</td>';
                
                // Display earnings for each barber
                $barberEarnings = 0;
                foreach ($earnings as $earning) {
                    if ($earning['barberID'] === $row['barberID']) {
                        $barberEarnings = $earning['TotalEarnings'];
                        break;
                    }
                }
                echo '<td>' . $barberEarnings . '</td>';

                echo '<td>';
                echo '<div class="btn-group" role="group">';

                // Button for setting barber as unavailable
                echo '<a href="updateunavailablebarber.php?barberID=' . $row['barberID'] . '" class="btn btn-danger btn-sm">No</a>';
                echo "&nbsp;&nbsp;"; // Adding two non-breaking spaces for spacing
                // Button for setting barber as available
                echo '<a href="updateavailablebarber.php?barberID=' . $row['barberID'] . '" class="btn btn-success btn-sm">Yes</a>';
                echo "&nbsp;&nbsp;"; // Adding two non-breaking spaces for spacing

                // Button for updating barber information
                echo '<form action="updatebarber.php" method="post">';
                echo '<input type="hidden" name="barberID" value="' . $row['barberID'] . '">';
                echo '<button type="submit" class="btn btn-warning btn-sm">Update</button></form>';
                echo "&nbsp;&nbsp;"; // Adding two non-breaking spaces for spacing

                // Button for viewing barber profile
                echo '<form action="viewbarberprof.php" method="post">';
                echo '<input type="hidden" name="barberID" value="' . $row['barberID'] . '">';
                echo '<button type="submit" class="btn btn-info btn-sm">View</button>';
                echo '</form>';
                echo "&nbsp;&nbsp;"; // Adding two non-breaking spaces for spacing

                // Button for deleting barber (soft delete)
                echo '<form action="softdeletebarber.php" method="post">';
                echo '<input type="hidden" name="barberID" value="' . $row['barberID'] . '">';
                echo '<button type="submit" class="btn btn-danger btn-sm">Delete</button>';
                echo '</form>';

                echo '</div>'; // End of button group
                echo '</td>';
                echo '</tr>';
            }
            ?>
            </tbody>
        </table>
    </div>

    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="adminHOMEE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>

    <!-- Add buttons for PDF conversion and status updates -->
    <div class="mt-3 btn-container">
        <form action="addbarber.php" method="post" class="mt-3">
            <button type="submit" class="btn btn-success">Add Barbers</button>
        </form>
        <form action="updateAllBarbersToAvailable.php" method="post" class="mt-3">
            <button type="submit" class="btn btn-success">Set All Barbers to Available</button>
        </form>
        <form action="updateAllBarbersToUnavailable.php" method="post" class="mt-3">
            <button type="submit" class="btn btn-danger">Set All Barbers to Unavailable</button>
        </form>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const barberTable = document.getElementById('barberTable');

    searchInput.addEventListener('input', function() {
        const searchTerm = searchInput.value.toLowerCase();
        const rows = barberTable.getElementsByTagName('tr');

        for (let i = 0; i < rows.length; i++) {
            const cells = rows[i].getElementsByTagName('td');
            let found = false;
            if (cells.length > 0) {
                const idCellText = cells[0].textContent || cells[0].innerText;
                if (idCellText.toLowerCase().indexOf(searchTerm) > -1) {
                    found = true;
                }
            }
            rows[i].style.display = found ? '' : 'none';
        }
    });
});
</script>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
