<?php 
require('adminCONX.php'); 

// Constants for pagination
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

// Calculate offset for pagination
$offset = ($page - 1) * $limit;

// Check if a date is selected
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Prepare the SQL query
$sql = "SELECT * FROM services 
        WHERE DATE(Created_At) = ?
        ORDER BY Created_At
        LIMIT ? OFFSET ?";

// Prepare and execute the SQL query
$stmt = $conn->prepare($sql);
$stmt->bind_param('sii', $selectedDate, $limit, $offset); // 'sii' indicates string, integer, integer
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active User and Credential Report</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <style>
        th, td{
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mt-5 mb-4">Services Record</h1>
    <p>Report generated on <?php echo date('Y-m-d'); ?></p>
    <div class="form-group">
        <label for="datepicker">Select Date:</label>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
        <input type="hidden" id="selectedDate" name="date">

    </div>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr><th>Service ID</th><th>User ID</th><th>Service Type</th><th>Service Price</th><th>Registration Date</th></tr>
        </thead>
    <tbody>
    <?php
    // Fetch data
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['ServiceID'] . '</td>';
        echo '<td>' . $row['UserID'] . '</td>';
        echo '<td>' . $row['Type'] . '</td>';
        echo '<td>' . $row['Price'] . '</td>';
        echo '<td>' . $row['Created_At'] . '</td>';
        echo '</tr>';
    }
    ?>
    </tbody>
    </table>
    <!-- Pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li>
              <a class="page-link" href="adminHOME.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });
    });
</script>

</body>
</html>
