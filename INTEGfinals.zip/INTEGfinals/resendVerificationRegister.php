<?php
require 'customerCONX.php'; // Assuming this file contains your database connection settings

session_start();

// Check if userData is set in the session
if (!isset($_SESSION['userData'])) {
    echo "User data not found in session.";
    exit();
}

$userData = $_SESSION['userData'];

$email = $userData['email'];
$firstname = $userData['firstname']; // Assuming you retrieve firstname from userData

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/vendor/autoload.php"; // Include Composer's autoload file for PHPMailer

$mail = new PHPMailer(true);

try {
	    $verificationCode = bin2hex(random_bytes(6)); // Generates a 6-character hexadecimal code

    // SMTP configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Set the SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
    $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

        // Recipients
    $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
    $mail->addAddress($email);

        // Content
    $mail->isHTML(true);
    $mail->Subject = 'Email Verification';
    $mail->Body    = "Hi $firstname,<br><br>Your verification code is: <strong>$verificationCode</strong><br><br>Please enter this code on the registration page to activate your account.";

    $mail->send();

    // Send email

    // Store verification code in session
    $_SESSION['verificationCode'] = $verificationCode;

    // Redirect to verification page
    echo "<script>alert('Verification Sent!'); window.location.href = 'verifyRegister.php';</script>";
    exit();
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    exit();
}

// Function to generate a verification code (you can adjust this as per your requirements)

?>
