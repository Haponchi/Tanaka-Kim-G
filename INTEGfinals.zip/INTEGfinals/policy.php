


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Policy | Brilliante Barbershop</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="images/logo.png" type="image/png"> <!-- Change type to image/png -->
    <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="home.html" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
      <a href="customerPAGE.php">Home  |</a>
      <a href="aboutus.php">About Us</a>
      <a href="policy.php"><b>Policy</b></a>
    </div>
  </nav>
    <div class = "policy">
        <h1>Policy</h1>
        <p>Welcome to the Brilliante Barber Reservation System! To ensure a smooth experience for all our customers, we have the following policies in place:
            <div class = "ppolicy">
            <h3>No Cash Payments</h3>We only accept online payments such as gcash and paymaya for your convenience and safety.
            <br>
            <h3>Cancellation Policy</h3> If you need to cancel your transaction, please do so at least 24 hours in advance. Cancellation can't be done within one day before a booking.
            <br>
            <h3>Booking Restrictions</h3> You cannot book another appointment if you have an ongoing transaction to avoid double bookings and ensure fair scheduling.
            <br>
            <h3>No Refunds</h3> We value the time of our barbers. Therefore, we do not offer refunds. Instead, we ensure that our barbers are fairly compensated for their time.
            </div>
            
        </div>
        <footer class="footer">
            <div class="footer-content">
              <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
              <div class="footer-title">
                <h2>Brilliante Barbershop</h2>
                <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
              </div>
              <div class="footer-links">
                <h3>Links</h3>
                <a href="aboutus.php">About Us  |</a>
                <a href="policy.php">Policy</a>
                <div class="social-icons">
                  <br>
                  <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
                  <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
                </div>
                <div class = "contact">
                  <br><br><h2>Contact Us</h2>
                  For inquiries and appointments, please contact us at:<br>
                  Phone: 0917 560 0119</p>
                  </div>
              </div>   
            </div>   
            <br>
            <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
          </footer>
</body>
</html>

