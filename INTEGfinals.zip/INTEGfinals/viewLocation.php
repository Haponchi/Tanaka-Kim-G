<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Location Image</title>
    <style>
        body {
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa; /* Lux theme background color */
            position: relative; /* Ensure relative positioning for absolute elements */
        }

        img {
            max-width: 100%; /* Ensure image doesn't exceed container width */
            height: auto; /* Maintain aspect ratio */
            display: block; /* Remove default inline behavior */
            margin: 0 auto; /* Center the image horizontally */
            z-index: 1; /* Ensure the image is above the background */
        }

        .div {
            width: 700px;
            z-index: 1; /* Ensure the container is above the background */
        }

        .background-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("images/home.jpg") center/cover no-repeat;
            filter: blur(5px); /* Adjust the blur value as needed */
            z-index: -1;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #343a40; /* Lux theme primary color */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            z-index: 2; /* Ensure the button is above the background */
        }

        .back-button:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }
    </style>
</head>
<body>

    <div class="div">
        <img src="Images/loca.jpg" alt="Location Image">
    </div>
    <form action="book.php">
    	<input type="submit" value="Back" class="back-button">
    </form>
</body>
</html>
