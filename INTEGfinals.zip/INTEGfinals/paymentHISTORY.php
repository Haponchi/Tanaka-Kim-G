<?php   
session_start(); 
require('customerCONX.php'); 
$id = $_SESSION['c'];

// Initialize selectedDate with a default value
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Pagination
$limit = 30; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate offset for pagination

// Query to retrieve data from the "sam" table with pagination
$sql = "SELECT
    b.BookingID AS booking_id,
    b.barberID,
    b.ServiceID AS service_id,
    b.timeslotID AS timeslot_id,
    b.Date AS booking_date,
    b.Time AS booking_time,
    b.Status AS booking_status,
    b.Location AS booking_location,
    s.UserID AS user_id,
    s.Type AS service_type,
    s.Price AS service_price,
    p.PaymentID AS payment_id,
    p.Method AS payment_method,
    p.DatePaid AS payment_datepaid,
    p.Amount AS payment_amount,
    p.Status AS payment_status,
    p.Receipt AS payment_receipt,
    p.Created_At AS payment_created
FROM
    booking b
LEFT JOIN
    services s ON b.ServiceID = s.ServiceID
LEFT JOIN
    payment p ON b.BookingID = p.BookingID
WHERE
    s.UserID = ? AND DATE(p.Created_At) = ? LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param('ssii', $id, $selectedDate, $limit, $offset);

// Uncomment the next line for debugging, if needed
// echo "Query: $sql with UserID: $id and Date: $selectedDate Limit: $limit Offset: $offset<br>";

$stmt->execute();

// Get the result set
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <style>
        th {
            background-color: white;
            text-align: center;
        }
        .book{
            text-align: center;
        }
        body{
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="mt-5 mb-4">Payment History</h1>
    <p>Report generated on <?php echo date('Y-m-d'); ?></p>
    <div class="form-group">
        <label for="datepicker">Select Date:</label>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
    </div>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
        <tr>
            <th>Payment ID</th>
            <th>Booking ID</th>
            <th>Method</th>
            <th>Date Paid</th>
            <th>Amount</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Initialize variables
            $currentMonth = '';

            // Fetch data
            while ($row = $result->fetch_assoc()) {
                $regDate = date('F Y', strtotime($row['payment_created']));
                // Check if a new month is encountered
                if ($currentMonth != $regDate) {
                    $currentMonth = $regDate;
                    echo '<tr><td colspan="7"><strong>' . $currentMonth . '</strong></td></tr>';
                }
                // Add data for each record
                echo '<tr>';
                echo '<td class="book">' . $row['payment_id'] . '</td>';
                echo '<td class="book">' . $row['booking_id'] . '</td>';
                echo '<td class="book">' . $row['payment_method'] . '</td>';
                echo '<td class="book">' . $row['payment_datepaid'] . '</td>';
                echo '<td class="book">' . $row['payment_amount'] . '</td>';
                echo '<td class="book">' . $row['payment_status'] . '</td>';
                echo '</tr>';
            }
        } else {
            echo "<tr><td colspan='6'>No records found</td></tr>";
        }
        ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li>
                <a class="page-link" href="customerPAGE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>&date=<?php echo $selectedDate; ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>&date=<?php echo $selectedDate; ?>">Next</a>
            </li>
        </ul>
    </nav>

    <!-- Add buttons for PDF conversion -->
    <div class="mt-3">
        <a href="gen_pdf.php" target="_blank" class="btn btn-primary">Download PDF</a>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<!-- Initialize Datepicker -->
<script>
    $(document).ready(function () {
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',     // Set the date format
            autoclose: true,           // Close the datepicker when a date is selected
            todayHighlight: true      // Highlight today's date
        }).on('changeDate', function (e) {
            // When the date is changed, update the URL with the selected date
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });
    });
</script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
