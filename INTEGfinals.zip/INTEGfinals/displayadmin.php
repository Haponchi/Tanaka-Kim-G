<?php 
session_start();

require 'customerCONX.php';

// Retrieve user ID from session
$id = $_SESSION['c'];

$sql = "SELECT * FROM user WHERE userID = '$id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap');

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Rubik;
        }

        body {
            box-sizing: border-box;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 100px;
        }


        .maindiv > * {
            text-align: center;
            
        }

        .profilediv {
            background-color: white;
            padding: 20px 200px;
            width: 100%;
            border: 1px solid #e8e8e8;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .profilediv p {
            color: #727272;
        }

        .imgdiv {
            margin: 0 auto;
            width: 200px;
            height: 200px;
            border-radius: 100%;
            padding: 5px;
            background-image: url(images/<?php echo $row['Picture']; ?>);
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }

        h2 {
            margin-top: 10px;
        }
        

        #email {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        .profile_logout {
            background-color: #e8e8e8;
            padding: 20px 200px;
            width: 100%;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        a {
            padding: 10px 15px;
            color: white;
            background-color: #d33242;
            border-radius: 5px;
            border: none;
            font-size: 15px;
            text-decoration: none;
        }

        #gb {
            background-color: #017aff;
        }

        input[type="submit"], #gb {
            cursor: pointer;
        }



    </style>
</head>
<body style="background-image: url('Images/shavee.jpg'); background-size: cover;">
     <div class="maindiv">
        <div class="profilediv">
            <div class="imgdiv">
            </div>
            <h2>
                <?php echo $row['Fname'] . " " . $row['Lname'];?>
            </h2>
            <p id="email">
                <?php echo $row['Email'];?>
            </p>
        </div>
        <div class="profile_logout">
            <a id="gb" href="profileadmin.php">Go Back</a>
        </div>

    </div>
</body>
</html>
<?php
} 
// Closing brace for if ($result->num_rows > 0)
$conn->close();
?>
