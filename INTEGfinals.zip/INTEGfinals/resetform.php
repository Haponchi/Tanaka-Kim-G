<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Brilliante</title>
    <link rel="stylesheet" href="resetform.css">
    <link rel="icon" href="images/logo.png" type="image/png"> <!-- Change type to image/png -->
    <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="home.html" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
      <a href="about.html">About Us</a>
      <a href="policypage.html">Policy</a>
      <a href="#"><b>Book Now</b></a>
    </div>
  </nav>
  <div class="about">
    <img src="Images/about.jpg">
    <div class="verif-container">
    <div class="verif-form">   
    <h1>Verification</h1>
    <p>Enter your email to verify your account</p>
    <form action="resetpasswordverify.php" method="post">
        <input type="email" class="form-control" id="email"  name="email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" required>
        <br>
        <br>
        <button type="submit" style="margin-top:10px; margin-left: 15px; ">Submit</button>
        <br>
        <a href="form2.php" style="margin-left: 30px" >Cancel</a>
    </form>
</div>
</div>


</div>

</div>
        <footer class="footer" style = "margin-top: -50px">
            <div class="footer-content">
              <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
              <div class="footer-title">
                <h2>Brilliante Barbershop</h2>
                <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
              </div>
              <div class="footer-links">
                <h3>Links</h3>
                <a href="home.html">Home  |</a>
                <a href="about.html">About Us  |</a>
                <a href="policypage.html">Policy</a>
                <div class="social-icons">
                  <br>
                  <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
                  <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
                </div>
                <div class = "contact">
                  <br><br><h2>Contact Us</h2>
                  For inquiries and appointments, please contact us at:<br>
                  Phone: 0917 560 0119</p>
                  </div>
              </div>   
            </div>   
            <br>
            <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
          </footer>
</body>
</html>

