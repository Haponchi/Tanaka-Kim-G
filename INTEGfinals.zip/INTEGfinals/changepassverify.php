<?php 
session_start();
require 'customerCONX.php';

$oldpass = $_POST['oldpass'];
$newpass = $_POST['newpass'];
$confirmpass = $_POST['confirmpass'];

$id = $_SESSION['c'];

$sql = "SELECT password FROM user WHERE userID = '$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $current_password = $row['password'];

    // Verify old password
    if (password_verify($oldpass, $current_password)) {
        // Check if new password and confirm password match
        if ($newpass === $confirmpass) {
            // Update the password in the database
            $hashed_new_password = password_hash($newpass, PASSWORD_BCRYPT);
            $sql_update = "UPDATE user SET Password = '$hashed_new_password' WHERE userID = '$id'";
            if ($conn->query($sql_update) === TRUE) {

                $_SESSION['password_changed'] = true;

                // Password updated successfully, redirect to success page or profile page
                header("Location: changepass.php");
                exit();
            } else {
                // Error occurred while updating password
                header("Location: errorchangepass.php?error=update_failed");
                exit();
            }
        } else {
            // New passwords do not match
            header("Location: errorchangepass.php?error=password_mismatch");
            exit();
        }
    } else {
        // Old password is incorrect
        header("Location: errorchangepass.php?error=incorrect_old_password");
        exit();
    }
} else {
    // User not found
    header("Location: errorchangepass.php?error=user_not_found");
    exit();
}

$conn->close();

?>
