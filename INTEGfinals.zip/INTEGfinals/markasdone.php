<?php
session_start();

require 'adminCONX.php';

// Check if the booking ID is provided in the request
if(isset($_POST['booking_id'])) {
    // Sanitize the input
    $booking_id = $_POST['booking_id'];

    // Update the booking status to "done"
    $sql = "UPDATE booking SET Status = 'Done' WHERE BookingID = :booking_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':booking_id', $booking_id, PDO::PARAM_INT);
    
    // Execute the update query
    if($stmt->execute()) {
        echo "<script>alert('Booking status updated to done'); window.location.href = 'bookingadmin.php';</script>";
        // Booking status updated successfully
        // echo "Booking status updated to 'Done' for Booking ID: " . $booking_id;
    } else {
        // Error occurred while updating the booking status
        echo "Error updating booking status.";
    }
} else {
    // Booking ID not provided in the request
    echo "Booking ID not provided.";
}
?>
