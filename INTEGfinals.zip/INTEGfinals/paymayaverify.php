<?php
session_start();

require 'customerCONX.php';

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$price = $_SESSION['price'];

// Assuming that 'cost' is the price of the service, it should be retrieved from $_SESSION, not from $_POST
$cost = $price; // Fixed typo: changed $Price to $price

// Retrieve the amount entered by the user from POST data
$amount = $_POST['amount']; 

$sender = $_POST['sendername'];
$receiver = $_POST['receivername'];

$_SESSION['sender'] = $sender;
$_SESSION['receiver'] = $receiver;

// Generate current timestamp for DatePaid
$datePaid = date("Y-m-d H:i:s");

// Set session variable for date paid
$_SESSION['datepaid'] = $datePaid;

// Check if the entered amount matches the cost of the service

    try {
        $conn->beginTransaction();

        // Insert into audit table
        $insertSql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Paymaya Paid')";
        $stmt = $conn->prepare($insertSql);
        $stmt->execute([$id]);

        // Insert into payment table
        $insertSql = "INSERT INTO payment (BookingID, Method, DatePaid, Amount, Status) VALUES (?, 'Paymaya', ?, ?, 'Paid')";
        $stmt = $conn->prepare($insertSql);
        $stmt->execute([$bookingID, $datePaid, $price]);

        // Retrieve the payment ID of the last inserted record
        $paymentID = $conn->lastInsertId();

        // Store the payment ID in the session
        $_SESSION['paymentID'] = $paymentID;

        // Commit transaction if successful
        $conn->commit();

        // Redirect to the receipt generation page
        header("Location: paymayareport.php");
        exit(); // Ensure script execution stops after redirection
    } catch (PDOException $e) {
        // Rollback transaction if there's an error
        $conn->rollBack();
        echo "Error: " . $e->getMessage();
    }


// Close the database connection
$conn = null;
?>













