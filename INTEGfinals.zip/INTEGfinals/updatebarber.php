<?php 
session_start();
require 'adminCONX.php';

$userID = $_SESSION['c']; 

$barberID = $_POST['barberID'];

$_SESSION['barberID'] = $barberID;

// Prepare and execute the SQL query
$sql = "SELECT * FROM barbers WHERE barberID = :barberID";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':barberID', $barberID);
$stmt->execute();

$barberData = $stmt->fetch(PDO::FETCH_ASSOC);

$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barber Registration | Brilliante</title>
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .btn-custom {
            margin: 5px 0;
            width: 270px;

        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="mb-4">Update Profile</h2>
    <form action="updatebarberverify.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="firstname">First Name</label>
            <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $barberData['Name']; ?>" disabled>
        </div>
        <div class="form-group">
            <label for="lastname">Last Name</label>
            <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $barberData['Lname']; ?>" disabled>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $barberData['Email']; ?>" placeholder="Enter your email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$">
        </div>
        <div class="form-group">
            <label for="phonenumber">Phone Number</label>
            <input type="text" class="form-control" id="phonenumber" name="phonenumber" placeholder="Enter your number" value="<?php echo $barberData['CpNO']; ?>" required pattern="09\d{9}">
        </div>
        <div class="form-group">
            <label for="image">Profile Picture</label>
            <input type="file" class="form-control-file" id="image" name="image" >
        </div>
        <div class="d-flex justify-content-between">
            <a href="registeredbarber.php" class="btn btn-danger btn-custom"><i class="fas fa-times"></i> Cancel</a>
            <button type="submit" class="btn btn-success btn-custom"><i class="fas fa-check"></i> Update</button>
        </div>
    </form>
</div>
</body>
</html>
