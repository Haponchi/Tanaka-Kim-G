<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <link rel="stylesheet" href="style2.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script2.js" defer></script>
    <style></style>
</head>
<body style="background-image: url('Images/shavee.jpg'); background-size: cover; height: 100vh; width: 100vw;">

<nav class="sidebar locked">
    <div class="logo_items flex">
        <span class="nav_image">
            <img src="images/logo.jpg" alt="logo_img" />
        </span>
        <span class="logo_name">Brilliante Barbershop</span>
        <i class="bx bx-lock-alt" id="lock-icon" title="Unlock Sidebar"></i>
        <i class="bx bx-x" id="sidebar-close"></i>
    </div>
    <div class="menu_container">
        <div class="menu_items">
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span style="width: 50px; font-size: 24px;" class="title">Dashboard</span>
                    <span class="line"></span>
                </div>
                <li class="item">
                    <a href="profileadmin.php" class="link flex">
                        <i><img src="Images/profile.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Profile</span>
                    </a>
                    <a href="addbarber.php" class="link flex">
                        <i><img src="Images/add.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Barber</span>
                    </a>
                </li>
            </ul>

            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title">Reports</span>
                    <span class="line"></span>
                </div>
                <li class="item">
                    <a href="bookingcustomer.php" class="link flex">
                        <i><img src="Images/transaction.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Transactions</span>
                    </a>
                </li>
            </ul>
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title">Reports</span>
                    <span class="line"></span>
                </div>
                <li class="item">
                    <a href="salesreport.php" class="link flex">
                        <i><img src="Images/audit.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Sales</span>
                    </a>
                    <a href="auditREPORT.php" class="link flex">
                        <i><img src="Images/auditing.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Audit Trail</span>
                    </a>
                </li>
                <li class="item">
                    <a href="userREGISTERED.php" class="link flex">
                        <i><img src="Images/registered.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Registered User</span>
                    </a>
                </li>
                <li class="item">
                    <a href="registeredbarber.php" class="link flex">
                        <i><img src="Images/barber.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Registered Barber</span>
                    </a>
                </li>
                <li class="item">
                    <a href="bookingadmin.php" class="link flex">
                        <i><img src="Images/folder.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Transactions</span>
                    </a>
                </li>
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title">Setting</span>
                    <span class="line"></span>
                </div>
                <li class="item">
                    <a href="?logout=true" class="link flex">
                        <i><img src="Images/leave.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Logout</span>
                    </a>
                </li>
                <li class="item">
                    <a href="changepassadmin.php" class="link flex">
                        <i><img src="Images/reset.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Change Password</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="sidebar_profile flex">
            <span class="nav_image">
                <img src="Images/user.png" alt="user_img" />
            </span>
            <div class="data_text">
                <span class="name"><?php echo htmlspecialchars($row['Username']; ?></span>
                <span class="email"><?php echo htmlspecialchars($row['Email']); ?></span>
            </div>
        </div>
    </div>
</nav>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
