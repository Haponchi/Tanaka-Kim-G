<?php
session_start();
require 'customerCONX.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $barberID = $_POST['barberID'];
    $bookingDate = $_POST['bookingDate'];

    // Query to fetch booked time slots directly from the booking table
    $sql = "SELECT Time FROM booking WHERE Date = ? AND barberID = ? AND Status <> 'Cancelled'";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$bookingDate, $barberID]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $bookedSlots = [];
    foreach ($result as $row) {
        $bookedSlots[] = $row['Time'];
    }

    echo json_encode($bookedSlots);
    exit();
}
?>
