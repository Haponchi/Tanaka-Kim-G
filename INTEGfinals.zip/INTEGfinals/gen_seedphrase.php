<?php
session_start();
require 'customerCONX.php';

// Retrieve first name, last name, and seed phrase from session
$firstname = isset($_SESSION['firstname']) ? $_SESSION['firstname'] : 'First name not found';
$lastname = isset($_SESSION['lastname']) ? $_SESSION['lastname'] : 'Last name not found';
$seedPhrase = isset($_SESSION['seedPhrase']) ? $_SESSION['seedPhrase'] : 'Seed phrase not found';

// Include TCPDF library
require_once('tcpdf/tcpdf.php');

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Seed Phrase PDF');
$pdf->SetSubject('Seed Phrase');
$pdf->SetKeywords('TCPDF, PDF, seed phrase');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Add seed phrase and user information
$html = '<h1>Your Seed Phrase</h1>';
$html .= '<p><strong>Hi, First Name:</strong> ' . $firstname . ' ' . $lastname . '</p>';
$html .= '<p><strong>Your Seed Phrase is :</strong></p>';
$html .= '<p>' . $seedPhrase . '</p>';
$html .= '<p>Please save your seed phrase in a secure place. Do not share it with anyone.</p>';

// Output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Close and output PDF document
$pdf->Output('Seed_Phrase.pdf', 'D');

// Close the database connection
$conn = null;
?>
