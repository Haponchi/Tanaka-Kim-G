<?php
session_start();
require 'adminCONX.php';

$id = $_SESSION['c'];

// Query to get total sales by service type and time intervals
$salesQuery = "
    SELECT 
        services.Type,
        payment.Created_At,
        SUM(CASE WHEN DATE(payment.Created_At) = CURRENT_DATE THEN payment.Amount ELSE 0 END) AS Daily_Sales,
        SUM(CASE WHEN WEEK(payment.Created_At) = WEEK(CURRENT_DATE) AND YEAR(payment.Created_At) = YEAR(CURRENT_DATE) THEN payment.Amount ELSE 0 END) AS Weekly_Sales,
        SUM(CASE WHEN MONTH(payment.Created_At) = MONTH(CURRENT_DATE) AND YEAR(payment.Created_At) = YEAR(CURRENT_DATE) THEN payment.Amount ELSE 0 END) AS Monthly_Sales,
        SUM(CASE WHEN YEAR(payment.Created_At) = YEAR(CURRENT_DATE) THEN payment.Amount ELSE 0 END) AS Yearly_Sales
    FROM 
        booking
    JOIN 
        services ON booking.ServiceID = services.ServiceID
    JOIN 
        payment ON booking.BookingID = payment.BookingID
    GROUP BY 
        services.Type, payment.Created_At
    ORDER BY 
        services.Type, payment.Created_At";

$salesStmt = $conn->prepare($salesQuery);
$salesStmt->execute();
$salesData = $salesStmt->fetchAll(PDO::FETCH_ASSOC);

// Close database connection
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Service Types Overview</title>
  <!-- Include Bootstrap Lux Theme -->
  <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
  <!-- Include Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
  <style>
    body {
      font-family: 'Poppins';
      background-color: #f8f9fa;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    h1, p {
      color: #343a40;
      text-align: center;
    }
    .chart {
      text-align: center;
      margin: 20px;
    }
    .button-container {
      text-align: center;
      margin-top: 40px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Service Types Overview</h1>
    <p>Total Sales by Type</p>
    <div class="chart">
      <canvas id="serviceTypesChart" width="800" height="400"></canvas>
    </div>
    <div class="button-container">
      <a href="adminHOMEE.php" class="btn btn-primary">Back</a>
    </div>
  </div>

  <script>
    // Data from PHP
    let salesData = <?php echo json_encode($salesData); ?>;

    // Extract data for chart
    let labels = [...new Set(salesData.map(data => data.Type))];
    let dailySales = [];
    let weeklySales = [];
    let monthlySales = [];
    let yearlySales = [];

    labels.forEach(label => {
      let dailySum = 0, weeklySum = 0, monthlySum = 0, yearlySum = 0;
      salesData.forEach(data => {
        if (data.Type === label) {
          dailySum += parseFloat(data.Daily_Sales);
          weeklySum += parseFloat(data.Weekly_Sales);
          monthlySum += parseFloat(data.Monthly_Sales);
          yearlySum += parseFloat(data.Yearly_Sales);
        }
      });
      dailySales.push(dailySum);
      weeklySales.push(weeklySum);
      monthlySales.push(monthlySum);
      yearlySales.push(yearlySum);
    });

    let serviceTypesConfig = {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Daily Sales',
            data: dailySales,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
          },
          {
            label: 'Weekly Sales',
            data: weeklySales,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
          },
          {
            label: 'Monthly Sales',
            data: monthlySales,
            backgroundColor: 'rgba(255, 206, 86, 0.2)',
            borderColor: 'rgba(255, 206, 86, 1)',
            borderWidth: 1
          },
          {
            label: 'Yearly Sales',
            data: yearlySales,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
          }
        ]
      },
      options: {
        scales: {
          x: {
            stacked: true,
            title: {
              display: true,
              text: 'Service Type'
            }
          },
          y: {
            stacked: true,
            beginAtZero: true,
            title: {
              display: true,
              text: 'Total Sales'
            }
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: function(tooltipItem) {
                return `${tooltipItem.dataset.label}: ${tooltipItem.raw}`;
              }
            }
          }
        }
      }
    };

    let serviceTypesCtx = document.getElementById('serviceTypesChart').getContext('2d');
    let serviceTypesChart = new Chart(serviceTypesCtx, serviceTypesConfig);
  </script>

</body>
</html>
