<?php 
session_start();

require 'customerCONX.php';


$email = $_SESSION['email'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Brilliante</title>
    <link rel="stylesheet" href="resetdata.css">
    <link rel="icon" href="images/logo.png" type="image/png"> <!-- Change type to image/png -->
    <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="Images/logo.png" alt="logo" class="nav-logo">
    <a href="home.html" class="nav-label" style = "text-decoration: none; color: black" >Brilliante Barbershop</a>
    <div class="nav-links">
      <a href="about.html">About Us</a>
      <a href="policypage.html">Policy</a>
      <a href="#"><b>Book Now</b></a>
    </div>
  </nav>
  <div class="about">
    <img src="Images/about.jpg">
    <div class="forgot-container">
    <div class="forgot-form">   
        <h1 style = "margin-bottom:0px">Reset Password</h1>
        <form action="resetdataverify.php" method="post">
            <label for="new-password" style = "text-align:left">New Password:</label>
            <input type="password" class="form-control" id="newpass"  name="newpass" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"  required>

            <label for="confirm-password" style = "text-align:left">Confirm New Password:</label>
            <input type="password" class="form-control" id="confirmpass"  name="confirmpass" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"  required>

            <label for="verification-code" style = "text-align:left">Verification Code:</label>
            <input type="password" class="form-control" id="vericode" name="vericode" required>

            <button type="submit"style = "margin-top:10px;margin-left:10px;margin-bottom:0px">Submit</button>
            <div class="crc" style = "width: 400px; margin-left: -40px">
        <p><a href="form2.php" style = "margin-left:-75px">Cancel</a>
        <a href="resendVerificationForgotpassword.php" style = "margin-left:120px">Resend Code</a></p>
            </div>  
        </form>
        
    </div>
</div>


</div>

</div>
        <footer class="footer" style = "margin-top: -50px">
            <div class="footer-content">
              <img src="Images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
              <div class="footer-title">
                <h2>Brilliante Barbershop</h2>
                <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
              </div>
              <div class="footer-links">
                <h3>Links</h3>
                <a href="home.html">Home  |</a>
                <a href="about.html">About Us  |</a>
                <a href="policypage.html">Policy</a>
                <div class="social-icons">
                  <br>
                  <a href="https://www.facebook.com/brilliantebarbershop"><img src="Images/fblogo.png" alt="Facebook Page"></a>
                  <a href="https://www.instagram.com/brilliantebarbershop/"><img src="Images/iglogo.png" alt="Instagram Page"></a>
                </div>
                <div class = "contact">
                  <br><br><h2>Contact Us</h2>
                  For inquiries and appointments, please contact us at:<br>
                  Phone: 0917 560 0119</p>
                  </div>
              </div>   
            </div>   
            <br>
            <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
          </footer>
</body>
</html>





