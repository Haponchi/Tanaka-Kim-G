<?php
session_start();
require 'customerCONX.php';

// Ensure these variables are defined and initialized properly
$id = $_SESSION['c'];
$serviceID = $_SESSION['serviceID'];
$bookingDATE = $_POST['bookingDate'];
$_SESSION['bookingDate'] = $bookingDATE;

$price = $_SESSION['price'];

$bookingTIME = $_POST['bookingTIME'];
$barberID = $_SESSION['barberID'];

$location = $_POST['location'];

// Extract start time from the booking time string
$times = explode(" - ", $bookingTIME);
$startTime = $times[0]; // Use only the start time for availability check

// Fetch the service type
$serviceTypeSql = "SELECT Type FROM services WHERE ServiceID = ?";
$stmt = $conn->prepare($serviceTypeSql);
$stmt->execute([$serviceID]);
$serviceTypeResult = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$serviceTypeResult) {
    // Handle case where service type is not found
    exit("Service type not found");
}

$serviceType = $serviceTypeResult['Type'];
$_SESSION['serviceType'] = $serviceType;

// Check if the booking slot is already taken
$checkExistingSql = "SELECT BookingID 
                     FROM booking 
                     WHERE Date = ? 
                       AND Time = ? 
                       AND barberID = ?";
$stmt = $conn->prepare($checkExistingSql);
$stmt->execute([$bookingDATE, $startTime, $barberID]); // Use startTime for availability check
$existingResult = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existingResult) {
    $conn->rollBack();
    exit();
} else {
    $conn->beginTransaction();

    // Insert the booking into the booking table with the full time range
    $sql = "INSERT INTO booking (barberID, ServiceID, Status, Date, Time, Location) 
            VALUES (?, ?, 'Reserved', ?, ?, ?)";
    $insertBookingStmt = $conn->prepare($sql);
    $insertBookingStmt->execute([$barberID, $serviceID, $bookingDATE, $bookingTIME, $location]); // Use full booking time
    $bookingID = $conn->lastInsertId();
    $_SESSION['BookingID'] = $bookingID;

    // Record the action in the audit table
    $auditActions = [
        "Chosen Date and Time of Booking",
        "Created a Booking",
        "Choosing Payment"
    ];

    foreach ($auditActions as $action) {
        $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, ?)";
        $insertStmt = $conn->prepare($insert_sql);
        $insertStmt->execute([$id, $action]);
    }

    echo "<script>alert('Your booking details have been successfully submitted. You will now be redirected to the payment page.'); window.location.href = 'payment.php';</script>";

    $conn->commit();
    exit();
}

// Close the database connection
$conn = null;
?>
