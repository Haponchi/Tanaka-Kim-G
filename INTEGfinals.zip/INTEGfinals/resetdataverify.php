<?php
session_start();

$email = $_SESSION['email'];

require 'customerCONX.php';

// Check if the email and verification code are set in the session
if (!isset($_SESSION['email'])) {
    // Redirect the user to the resetform.php page or handle the error accordingly
    echo "<script>alert('Email not found in session!'); window.location.href = 'resetdata.php';</script>";
    exit();
}

$verificationCode = $_POST['vericode'];

// Verify the verification code for the user
$stmt = $conn->prepare("SELECT * FROM user WHERE Email = :email AND Code = :verificationCode");
$stmt->bindParam(':email', $email);
$stmt->bindParam(':verificationCode', $verificationCode);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // If verification code doesn't match, redirect back to reset form
    echo "<script>alert('Invalid verification code!'); window.location.href = 'resetdata.php';</script>";
    exit();
}

// If verification code matches, proceed with updating the password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['newpass'];
    $confirmPassword = $_POST['confirmpass'];

    if ($newPassword !== $confirmPassword) {
        // Passwords do not match, redirect back to reset form
        echo "<script>alert('Passwords do not match!'); window.location.href = 'resetdata.php';</script>";
        exit();
    }

    // Hash the new password using bcrypt
    $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

    // Update the user's password in the database
    $stmt = $conn->prepare("UPDATE user SET Password = :hashedPassword WHERE Email = :email");
    $stmt->bindParam(':hashedPassword', $hashedPassword); // Fix here
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    // Redirect the user to a success page or login page
    echo "<script>alert('Password updated successfully!'); window.location.href = 'index.php';</script>";
    
    session_destroy();
    exit();
}
?>
