<?php
session_start();
require 'adminCONX.php';

// Retrieve the barber ID from the session
$barberID = $_SESSION['barberID'];

// Retrieve the data to be updated from the POST variables
$email = $_POST['email'];
$phoneNumber = $_POST['phonenumber'];

// Check if the email or phone number already exists for another barber
$checkQuery = "SELECT * FROM barbers WHERE (Email = :email OR CpNO = :phoneNumber) AND barberID != :barberID";
$stmt = $conn->prepare($checkQuery);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':phoneNumber', $phoneNumber);
$stmt->bindParam(':barberID', $barberID);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    echo "<script>alert('Email or phone number already exists.'); window.location.href = 'registeredbarber.php';</script>";
    exit();
}

if (!empty($_FILES['image']['name'])) {
    if ($_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        $folder = 'Images/'.$file_name;

        // Move uploaded file to the desired location
        if (move_uploaded_file($tempname, $folder)) {
            // Prepare the update SQL statement
            $sql = "UPDATE barbers 
                    SET Picture = :file_name, Email = :email, CpNO = :phoneNumber
                    WHERE barberID = :barberID";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':file_name', $file_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':phoneNumber', $phoneNumber);
            $stmt->bindParam(':barberID', $barberID);

            // Execute the SQL statement
            if ($stmt->execute()) {
                echo "<script>alert('Update Successfully.'); window.location.href = 'registeredbarber.php';</script>";
                exit(); // Ensure script execution stops after redirection
            } else {
                echo "Error updating record: " . $conn->error;
            }
        } else {
            echo "Error moving uploaded file to destination folder.";
        }
    } else {
        echo "Error uploading file: " . $_FILES['image']['error'];
    }
} else {
    // If no image is uploaded, update only email and phone number
    $sql = "UPDATE barbers 
            SET Email = :email, CpNO = :phoneNumber
            WHERE barberID = :barberID";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phoneNumber', $phoneNumber);
    $stmt->bindParam(':barberID', $barberID);

    // Execute the SQL statement
    if ($stmt->execute()) {
        echo "<script>alert('Update Successfully.'); window.location.href = 'registeredbarber.php';</script>";
        exit(); // Ensure script execution stops after redirection
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Close the database connection
$conn = null;
?>
