<?php 
session_start();
require 'customerCONX.php';

// Ensure the script only processes POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve form data
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $confirmpass = $_POST['confirmpass'];
    $id = $_SESSION['c'];

    // Prepare SQL to fetch password and seedphrase
    $sql = "SELECT password FROM user WHERE userID = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if user exists
    if ($row) {
        $current_password = $row['password'];

        // Verify old password
        if (password_verify($oldpass, $current_password)) {
            // Verify seed phrase
            // if (password_verify($seedphrase, $stored_seedphrase)) {
                // Check if new password and confirm password match
                if ($newpass === $confirmpass) {
                    // Update the password in the database
                    $hashed_new_password = password_hash($newpass, PASSWORD_BCRYPT);
                    $sql_update = "UPDATE user SET password = :newpass WHERE userID = :id";
                    $stmt_update = $conn->prepare($sql_update);
                    $stmt_update->bindParam(':newpass', $hashed_new_password);
                    $stmt_update->bindParam(':id', $id);
                    if ($stmt_update->execute()) {
                        // Log the successful password change
                        $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Changed Password')";
                        $stmt_insert = $conn->prepare($insert_sql);
                        $stmt_insert->bindParam(':id', $id);
                        $stmt_insert->execute();


                        // Redirect to success page or profile page
                        echo "<script>alert('Password changed successfully.'); window.location.href = 'changepasscustomer.php';</script>";
                        exit();
                    } else {
                        // Log the failed password change attempt
                        $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Failed password change')";
                        $stmt_insert = $conn->prepare($insert_sql);
                        $stmt_insert->bindParam(':id', $id);
                        $stmt_insert->execute();

                        // Display error message
                        echo "<script>alert('An error occurred while updating the password.'); window.location.href = 'changepasscustomer.php';</script>";
                        exit();
                    }
                } else {
                    // Log the failed password change attempt due to mismatch
                    $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Failed password change due to mismatch')";
                    $stmt_insert = $conn->prepare($insert_sql);
                    $stmt_insert->bindParam(':id', $id);
                    $stmt_insert->execute();

                    // Display error message
                    echo "<script>alert('New password does not match.'); window.location.href = 'changepasscustomer.php';</script>";
                    exit();
                }
            // } else {
            //     // Log the failed password change attempt due to incorrect seed phrase
            //     $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Failed password change due to incorrect seed phrase')";
            //     $stmt_insert = $conn->prepare($insert_sql);
            //     $stmt_insert->bindParam(':id', $id);
            //     $stmt_insert->execute();

            //     // Display error message
            //     echo "<script>alert('Seed phrase is incorrect.'); window.location.href = 'changepasscustomer.php';</script>";
            //     exit();
            // }
        } else {
            // Log the failed password change attempt due to incorrect old password
            $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Failed password change due to incorrect old password')";
            $stmt_insert = $conn->prepare($insert_sql);
            $stmt_insert->bindParam(':id', $id);
            $stmt_insert->execute();

            // Display error message
            echo "<script>alert('Old password is incorrect.'); window.location.href = 'changepasscustomer.php';</script>";
            exit();
        }
    } else {
        // Log the failed password change attempt due to user not found
        $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:id, 'Failed password change due to user not found')";
        $stmt_insert = $conn->prepare($insert_sql);
        $stmt_insert->bindParam(':id', $id);
        $stmt_insert->execute();

        // Display error message
        echo "<script>alert('No user found.'); window.location.href = 'changepasscustomer.php';</script>";
        exit();
    }

    // Close the database connection
    $conn = null;
} else {
    // If the request method is not POST, redirect to the change password page
    header("Location: changepasscustomer.php");
    exit();
}
?>
