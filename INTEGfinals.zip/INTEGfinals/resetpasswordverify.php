<?php
session_start();
require 'customerCONX.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/vendor/autoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Fetch the user's first name from the database
    $stmt = $conn->prepare("SELECT UserID, Fname FROM user WHERE Email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        echo "<script>alert('Email address not found!'); window.location.href = 'resetform.php';</script>";
        exit();
    }

    $userID = $result['UserID'];
    $firstname = $result['Fname'];

    // Generate a 6-character hexadecimal code
    $verificationCode = bin2hex(random_bytes(3));

    // Update the user's Cod column with the verification code
    $stmt = $conn->prepare("UPDATE user SET Code = :verificationCode WHERE UserID = :userID");
    $stmt->bindParam(':verificationCode', $verificationCode);
    $stmt->bindParam(':userID', $userID);
    $stmt->execute();



    // Send verification email
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
        $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body = "Hi $firstname,<br><br>Your verification code is: <strong>$verificationCode</strong><br><br>Please enter this code on the verification page to reset your password.";

        $mail->send();

        // Store the email in session variable for verification later
        $_SESSION['email'] = $email;

        echo "<script>alert('Verification email sent! Please check your inbox.'); window.location.href = 'resetdata.php';</script>";
        exit();
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}'); window.location.href = 'resetform.php';</script>";
        exit();
    }
}
?>
