<?php
// Include TCPDF library
require_once('tcpdf/tcpdf.php');
require('adminCONX.php');

$sql = "SELECT * FROM barbers WHERE Status = 1";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('ACTIVE BARBER AND CREDENTIAL REPORT');
$pdf->SetTitle('ACTIVE BARBER AND CREDENTIAL REPORT');
$pdf->SetSubject('ACTIVE BARBER AND CREDENTIAL REPORT');
$pdf->SetKeywords('TCPDF, PDF, report');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 10);

// Header
$pdf->writeHTML('<h1 class="text-center mb-4">Active Barbers Report</h1>', true, false, true, false, '');
$pdf->writeHTML('<p class="text-center">Report generated on ' . date('Y-m-d') . '</p>', true, false, true, false, '');

// Initialize variable to track current month
$currentMonth = '';

// Table
$html = '<table border="1" cellspacing="0" cellpadding="5">';
$html .= '<thead>';
$html .= '<tr><th>Barber ID</th><th>Name </th><th>Email</th><th>Phone Number</th><th>Registration Date</th></tr>';
$html .= '</thead>';
$html .= '<tbody>';

// Loop through the results
foreach ($result as $row) {
    // Extract month and year from the registration date
    $month = date('F Y', strtotime($row['Creation']));

    // Check if a new month is encountered
    if ($currentMonth != $month) {
        // Add a new row for the month label
        $html .= '<tr><td colspan="7"><strong>' . $month . '</strong></td></tr>';
        $currentMonth = $month;
    }

    // Add data for each record
    $html .= '<tr>';
    $html .= '<td>' . $row['barberID'] . '</td>';
    $html .= '<td>' . $row['Name'] . ' ' . $row['Lname'] .'</td>';
    $html .= '<td>' . $row['Email'] . '</td>';
    $html .= '<td>' . $row['CpNO'] . '</td>';
    $html .= '<td>' . $row['Creation'] . '</td>';



    $html .= '</tr>';
}

$html .= '</tbody>';
$html .= '</table>';

// Output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Close and output PDF document
$pdf->Output('Active_Barber_and_Credential_Report.pdf', 'D');

// Close the database connection
$conn = null;
?>
