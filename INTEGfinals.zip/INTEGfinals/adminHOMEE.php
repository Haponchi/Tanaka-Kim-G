<?php
session_start();

// Check if the logout link is clicked
if (isset($_GET['logout'])) {
    // Destroy all session data
    session_destroy();
    // Redirect the user to the login page or any other desired location
    echo "<script>alert('Logout Successfully.'); window.location.href = 'index.php';</script>";
    exit;
}

require 'adminCONX.php';

$id = $_SESSION['c'];

// Update MFA status if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['mfa_status_on'])) {
        $mfaStatus = 1; // MFA enabled
        $message = "Multi Factor Authentication is ON.";
    } elseif (isset($_POST['mfa_status_off'])) {
        $mfaStatus = 0; // MFA disabled
        $message = "Multi Factor Authentication is OFF.";
    }

    $update_mfa_sql = "UPDATE user SET MFAEnabled = :mfaStatus WHERE UserID = :id";
    $stmt_update_mfa = $conn->prepare($update_mfa_sql);
    $stmt_update_mfa->bindParam(':mfaStatus', $mfaStatus);
    $stmt_update_mfa->bindParam(':id', $id);
    $stmt_update_mfa->execute();
}

// Fetch user information
$sql = "SELECT * FROM user WHERE UserID = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    echo "No user found with the given ID: " . $id;
}

// Fetch count of total users
$sql = "SELECT COUNT(*) AS TotalUsers FROM user WHERE Type ='customer'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$totalUsers = $result['TotalUsers'];

// Fetch count of total barbers
$sql = "SELECT COUNT(*) AS TotalBarbers FROM barbers WHERE Status =  1";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$totalBarbers = $result['TotalBarbers'];

$sql = "SELECT COUNT(*) AS TotalBookingCount FROM booking";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$TotalBookingCount = $result['TotalBookingCount'];

// Fetch count of reserved bookings
$sql = "SELECT COUNT(*) AS ReservedBookingsCount FROM booking WHERE Status = 'reserved'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$reservedBookingsCount = $result['ReservedBookingsCount'];

$currentTimestamp = date("Y-m-d H:i:s"); // Get current timestamp in Y-m-d H:i:s format


// Fetch total earnings
$sql = "SELECT SUM(Amount) AS TotalEarnings FROM payment";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$totalEarnings = $result['TotalEarnings'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <!-- Boxicons CSS -->
    <link flex href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-****************" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
    <!-- ===== Fontawesome CDN Link ===== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <link rel="stylesheet" href="style2.css" />
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <script src="script2.js" defer></script>
    <style>
        body{
            font-family: 'Poppins';
        }
        .switch {
            position: relative;
            display: inline-block;
            width: 100px;
            height: 34px;
        }
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 2px;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 30px;
            left: 25px;
            bottom: 4px;
            background-color: white;
            transition: .5s;
        }
        input:checked + .slider {
            background-color: #2196F3;
        }
        input:checked + .slider:before {
            transform: translateX(26px);
        }
        .slider.round {
            border-radius: 34px;
        }
        .slider.round:before {
            border-radius: 50%;
        }
        .switch {
            padding-left: 20px;
        }
                .blurred-hr {
            height: 2px; /* height of the line */
            background: rgba(0, 0, 0, 0.1); /* color of the line */
            border: none; /* remove default border */
            margin: 20px 0; /* add some space around the line */
            filter: blur(2px); /* apply the blur effect */
        }
    </style>
</head>
<body>
<div style="margin-left: 272px; width: 593px; margin-top: 4px; height: 1    00px;">
    <img src="Images/comb.jpg" width="256%" height="864px">
</div>>
<nav class="sidebar locked">
    <div class="logo_items flex">
        <span class="nav_image">
            <img src="images/logo.jpg" alt="logo_img" />
        </span>
        <span class="logo_name">Brilliante Barbershop</span>
    </div>
    <div class="menu_container">
        <div class="menu_items">
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span style="width: 50px; font-size: 24px;" class="title">Dashboard</span>
                    <span class="line"></span>
                </div>
                <li class="item">
                    <a href="profileadmin.php" class="link flex">
                        <i><img src="Images/profile.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Profile</span>
                    </a>
                    <a href="salesreport.php" class="link flex">
                        <i><img src="Images/diagram.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Sales</span>
                    </a>
                </li>
            </ul>
            <!--   <hr class="blurred-hr">
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title" style="font-size: 20px">Summary</span><span class="title"style = "margin-left: 6px; font-size: 20px;" >Overview</span>

                    <span class="line"></span>
                </div>
            </ul>
              <li  class="item" id="logout">
                    <span style = "margin-left: 15px;">Total Earnings: <?php echo $totalEarnings; ?> </span>
            </li>
            <li style="padding-top: 10px;"   class="item" id="logout">
                    <span style = "margin-left: 15px;">Total User: <?php echo $totalUsers; ?>  </span>
            </li>
            <li style="padding-top: 10px;" class="item" id="logout">
                    <span style = "margin-left: 15px;">Total Barber: <?php echo $totalBarbers; ?>  </span>
            </li>
            <li style="padding-top: 10px;" class="item" id="logout">
                    <span style = "margin-left: 15px;">Total Bookings: <?php echo $TotalBookingCount; ?>  </span>
            </li>
            <li style="padding-top: 10px;" class="item" id="logout">
                    <span style = "margin-left: 15px;">Total Booking Reserved: <?php echo $reservedBookingsCount; ?> </span>
            </li> -->
            <hr class="blurred-hr">
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title">Reports</span>
                    <span class="line"></span>
                </div>
            </ul>
            <ul class="menu_item">
                <li class="item">
                    <a href="auditREPORT.php" class="link flex">
                        <i><img src="Images/auditing.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Audit Trail</span>
                    </a>
                </li>
                <li class="item">
                    <a href="userREGISTERED.php" class="link flex">
                        <i><img src="Images/registered.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Registered User</span>
                    </a>
                </li>
                <li class="item">
                    <a href="registeredbarber.php" class="link flex">
                        <i><img src="Images/barber.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Barber</span>
                    </a>
                </li>
               <!--  <li class="item">
                    <a href="bookingadmin.php" class="link flex">
                        <i><img src="Images/booking.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Booking</span>
                    </a>
                </li> -->
                <li class="item">
                    <a href="transactionadmin.php" class="link flex">
                        <i><img src="Images/folder.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                        <span>Transaction</span>
                    </a>
                </li>
            </ul>
        </div>
         <hr class="blurred-hr">
            <ul class="menu_item">
                <div class="menu_title flex">
                    <span class="title">Settings</span>
                    <span class="line"></span>
                </div>
            </ul>
            <li class="item" id="logout">
                <a href="?logout=true" class="link flex">
                    <i><img src="Images/leave.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                    <span>Logout</span>
                </a>
            </li>
            <li class="item" id="logout">
                <a href="changepassadmin.php" class="link flex">
                    <i><img src="Images/reset.png" alt="Razor" style="width: 24px; height: 24px;"></i>
                    <span>Change Password</span>
                </a>
            </li>
        </div>
        <div class="sidebar_profile flex">
            <span class="nav_image">
                <img src="Images/user.png" alt="user_img" />
            </span>
            <div class="data_text">
                <span class="name"><?php echo $row['Username']; ?></span>
                <span class="email"><?php echo $row['Email']; ?></span>
            </div>
        </div>
    </div>
</nav>
<label>Total Bookings</label>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
