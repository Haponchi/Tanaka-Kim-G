<?php 
require 'customerCONX.php';
session_start();

$id = $_SESSION['c'];

$typeOfService = 'Haircut'; 
$_SESSION['serviceType'] = $typeOfService;

$price = '200'; 
$_SESSION['price'] = $price;

$insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Chosen Haircut Services')";
$stmt = $conn->prepare($insert_sql);
$stmt->execute([$id]);

$sql = "INSERT INTO services (UserID, Type, Price) 
        VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->execute([$id, $typeOfService, $price]);

// Retrieve the service ID of the newly inserted record
$serviceID = $conn->lastInsertId();
$_SESSION['serviceID'] = $serviceID; // Store serviceID in session variable

header("Location: choosebarber.php");
?>
