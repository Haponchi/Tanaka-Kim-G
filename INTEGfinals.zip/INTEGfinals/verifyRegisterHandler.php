<?php
session_start();
require 'customerCONX.php';

// Retrieve verification code and user data from session
$verificationCode = $_SESSION['verificationCode'] ?? null;
$userData = $_SESSION['userData'] ?? null;
$defaultPicture = 'nopic.jpg';

// Check if userData is set in the session
if (!$userData) {
    echo "<script>alert('User data not found in session.'); window.location.href = 'verifyRegister.php';</script>";
    exit();
}

// Retrieve the verification code entered by the user from the form submission
$userVerificationCode = $_POST['code'] ?? null;

// Compare the verification codes
if ($userVerificationCode === $verificationCode) {
    // Handle profile picture upload if provided
    if (isset($_FILES['Picture']) && $_FILES['Picture']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'Images/'; // Directory to store uploaded files
        $uploadFile = $uploadDir . basename($_FILES['Picture']['name']);

        // Move the uploaded file to the desired location
        if (move_uploaded_file($_FILES['Picture']['tmp_name'], $uploadFile)) {
            $picturePath = $uploadFile;
        } else {
            echo "Error uploading file.";
            $picturePath = $defaultPicture; // Use default picture
        }
    } else {
        $picturePath = $defaultPicture; // Use default picture
    }

    // Extract user data from userData session variable
    $username = $userData['username'];
    $firstname = $userData['firstname'];
    $lastname = $userData['lastname'];
    $email = $userData['email'];
    $cpnumber = $userData['cpnumber'];
    $hashed_password = $userData['password']; // Ensure you have hashed password here
    $type = 'customer'; // Set type to 'customer'

    // Insert user data into the database
    $sql = "INSERT INTO user (Username, Fname, Lname, Email, CpNO, Type, Password, Picture) 
            VALUES (:username, :firstname, :lastname, :email, :cpnumber, :type, :password, :picture)";
    $stmt_insert = $conn->prepare($sql);

    try {
        $stmt_insert->execute([
            ':username' => $username,
            ':firstname' => $firstname,
            ':lastname' => $lastname,
            ':email' => $email,
            ':cpnumber' => $cpnumber,
            ':type' => $type, // Use ':type' with the value 'customer'
            ':password' => $hashed_password,
            ':picture' => $picturePath, // Include the picture path
        ]);

        echo "<script>alert('Registration Successful!'); window.location.href = 'index.php';</script>";
        exit();
    } catch (PDOException $e) {
        // Handle potential SQL errors
        echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'verifyRegister.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Code does not match!'); window.location.href = 'verifyRegister.php';</script>";
    exit();
}
?>
