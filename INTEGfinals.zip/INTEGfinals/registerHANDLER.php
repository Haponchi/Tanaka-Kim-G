<?php
session_start();
require 'customerCONX.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/vendor/autoload.php"; // Include Composer's autoload file for PHPMailer

// Get user input
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$cpnumber = $_POST['cpnumber'];
$email = $_POST['email'];
$password = $_POST['password'];
$username = $_POST['username'];
$type = 'customer';

$_SESSION['firstname'] = $firstname;
$_SESSION['lastname'] = $lastname;

$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Check if the email or cpnumber already exists in the database
$checkQuery = "SELECT * FROM user WHERE Email = :email OR CpNO = :cpnumber OR Username = :username";
$stmt_check = $conn->prepare($checkQuery);
$stmt_check->execute(['email' => $email, 'cpnumber' => $cpnumber, 'username' => $username]);

if ($stmt_check->rowCount() > 0) {
    // If email or cpnumber already exists, display an error message
    echo "<script>alert('Email or cellphone number already exists.'); window.location.href = 'index.php';</script>";
    exit();
} else {
    $verificationCode = bin2hex(random_bytes(6)); // Generates a 6-character hexadecimal code

    // Send the verification email
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Set the SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
        $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = "Hi $firstname,<br><br>Your verification code is: <strong>$verificationCode</strong><br><br>Please enter this code on the registration page to activate your account.";

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        exit();
    }

    // Store the verification code and user data in session variables
    $_SESSION['verificationCode'] = $verificationCode;
    $_SESSION['userData'] = [
        'username' => $username,
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'cpnumber' => $cpnumber,
        'password' => $hashed_password,
        'type' => $type
    ];

    // Redirect to verification page
    echo "<script>alert('Verify your email!'); window.location.href = 'verifyRegister.php';</script>";
    exit();
}

// Close connection
$conn = null;
?>
