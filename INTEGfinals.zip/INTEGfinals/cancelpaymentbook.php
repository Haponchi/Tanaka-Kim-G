<<?php 
session_start();
require 'customerCONX.php';
$id = $_SESSION['c'];

 $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Cancel Payment')";
 $stmt_insert = $conn->prepare($insert_sql);
 $stmt_insert->execute([$id]);


 echo "<script>alert('Payment Cancelled.'); window.location.href = 'payment.php';</script>";
 exit()

 ?>