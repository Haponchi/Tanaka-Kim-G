<?php
session_start();
require 'customerCONX.php';
require 'PHPMailer/vendor/autoload.php'; // Assuming you have installed PHPMailer using Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Configuration
$resendLimit = 3;
$cooldownTime = 600; // 10 minutes in seconds

// Function to generate a verification code
function generateVerificationCode($length = 6) {
    return substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Check if user is logged in
if (isset($_SESSION['c'])) {
    $userID = $_SESSION['c'];

    // Fetch or initialize resend attempt data for the user for login attempts
    $stmt = $conn->prepare("SELECT resendAttempts, lastResendTime FROM resend_attempts WHERE userID = :userID AND attempt_type = 'login'");
    $stmt->bindParam(':userID', $userID);
    $stmt->execute();
    $resendData = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$resendData) {
        // Initialize data if not present
        $stmt = $conn->prepare("INSERT INTO resend_attempts (userID, resendAttempts, lastResendTime, attempt_type) VALUES (:userID, 0, 0, 'login')");
        $stmt->bindParam(':userID', $userID);
        $stmt->execute();
        $resendData = ['resendAttempts' => 0, 'lastResendTime' => 0];
    }

    $currentTime = time();
    $timeSinceLastResend = $currentTime - $resendData['lastResendTime'];

    if ($timeSinceLastResend > $cooldownTime) {
        $resendData['resendAttempts'] = 0; // Reset resend attempts after cooldown
    }

    if ($resendData['resendAttempts'] < $resendLimit) {
        // Generate a new verification code
        $newVerificationCode = generateVerificationCode();

        // Update the verification code in the database
        $stmt = $conn->prepare("UPDATE user SET Code = :verificationCode WHERE userID = :userID");
        $stmt->bindParam(':verificationCode', $newVerificationCode);
        $stmt->bindParam(':userID', $userID);
        if ($stmt->execute()) {
            // Fetch the user's email address and first name
            $stmt = $conn->prepare("SELECT email, Fname FROM user WHERE userID = :userID");
            $stmt->bindParam(':userID', $userID);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $email = $user['email'];
                $firstname = $user['Fname'];

                // Send the new verification code to the user's email
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com'; // Set the SMTP server
                    $mail->SMTPAuth = true;
                    $mail->Username = 'senpai.pakbet@gmail.com'; // SMTP username
                    $mail->Password = 'kkky bxmx dcir ytta'; // SMTP password (or app-specific password)
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom('senpai.pakbet@gmail.com', 'Brilliante Barbershop');
                    $mail->addAddress($email);

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Email Verification';
                    $mail->Body    = "Hi $firstname,<br><br>Your verification code is: <strong>$newVerificationCode</strong><br><br>Please enter this code on the login page to activate your account.";

                    $mail->send();

                    // Update resend attempts and time in the database
                    $resendData['resendAttempts']++;
                    $resendData['lastResendTime'] = $currentTime;
                    $stmt = $conn->prepare("UPDATE resend_attempts SET resendAttempts = :resendAttempts, lastResendTime = :lastResendTime WHERE userID = :userID AND attempt_type = 'login'");
                    $stmt->bindParam(':resendAttempts', $resendData['resendAttempts']);
                    $stmt->bindParam(':lastResendTime', $resendData['lastResendTime']);
                    $stmt->bindParam(':userID', $userID);
                    $stmt->execute();

                    echo "<script>alert('Verification code sent.'); window.location.href = 'verify.php';</script>";
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "User not found.";
            }
        } else {
            echo "Failed to update verification code.";
        }
    } elseif ($resendData['resendAttempts'] >= $resendLimit) {
        $cooldownRemaining = $cooldownTime - $timeSinceLastResend;
        $minutes = floor($cooldownRemaining / 60);
        $seconds = $cooldownRemaining % 60;
        echo "<script>alert('You have reached the maximum number of resend attempts. Please wait {$minutes} minutes and {$seconds} seconds before trying again.'); window.location.href = 'verify.php';</script>";
    }
} else {
    echo "User ID is not set.";
}
?>
