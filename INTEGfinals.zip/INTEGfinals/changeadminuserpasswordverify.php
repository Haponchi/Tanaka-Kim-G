<?php 
session_start();
require 'customerCONX.php';

$oldpass = $_POST['oldpass'];
$newpass = $_POST['newpass'];
$confirmpass = $_POST['confirmpass'];

$id = $_SESSION['c'];
$userID = $_SESSION['userID'];

$sql = "SELECT Password FROM user WHERE UserID = :userID";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':userID', $userID);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row) {
    $current_password = $row['Password'];

    // Verify old password
        // Check if new password and confirm password match
        if ($newpass === $confirmpass) {
            // Update the password in the database
            $hashed_new_password = password_hash($newpass, PASSWORD_BCRYPT);
            $sql_update = "UPDATE user SET Password = :newpass WHERE UserID = :userID";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bindParam(':newpass', $hashed_new_password);
            $stmt_update->bindParam(':userID', $userID);
            if ($stmt_update->execute()) {
                $insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:userID, 'Changed Password')";
                $stmt_insert = $conn->prepare($insert_sql);
                $stmt_insert->bindParam(':userID', $userID);
                $stmt_insert->execute();

                // Password updated successfully, redirect to success page or profile page
                echo "<script>alert('Password Changed.'); window.location.href = 'userREGISTERED.php';</script>";
                exit();
            } else {
                // Error occurred while updating password
                echo "<script>alert('An error occurred while updating the password.'); window.location.href = 'userREGISTERED.php';</script>";
                exit();
            }
        } else {
            // New password does not match confirmation password
            echo "<script>alert('New password does not match.'); window.location.href = 'userREGISTERED.php';</script>";
            exit();
        }
    } else {
        // Old password is incorrect
        echo "<script>alert('Old password is incorrect.'); window.location.href = 'userREGISTERED.php';</script>";
        exit();
    }


$conn = null;

$conn = null;
?>
