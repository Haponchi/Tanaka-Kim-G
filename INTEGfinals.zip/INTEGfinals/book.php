<?php
session_start();
require 'customerCONX.php';

$userID = $_SESSION['c'];

// Check if the user already has a reservation with status 'Reserved'
$check_sql = "SELECT b.* FROM booking b JOIN services s ON b.ServiceID = s.ServiceID WHERE s.UserID = ? AND b.Status = 'Reserved'";
$stmt = $conn->prepare($check_sql);
$stmt->execute([$userID]);
$check_result = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($check_result) > 0) {
    // User already has a reservation with status 'Reserved'
    echo "<script>alert(\"You already have a reservation. You cannot book again.\"); window.location.href = 'cancelSERVICES.php';</script>";
    // Rollback the transaction
    $conn->rollBack();
}

// Fetch barber details
$barberID = $_SESSION['barberID'];
$sql = "SELECT * FROM barbers WHERE barberID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$barberID]);
$barberRow = $stmt->fetch(PDO::FETCH_ASSOC);

if ($barberRow) {
    $_SESSION['barberName'] = $barberRow['Name'] . " " . $barberRow['Lname'];
} else {
    // Handle case when no barber is found
}

// Fetch user details
$sql = "SELECT * FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$userID]);
$userRow = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$userRow) {
    echo "No user found with the given ID: " . $userID;
    exit();
}

// Get service details from session
$serviceType = $_SESSION['serviceType'];
$price = $_SESSION['price'];

$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png" type="image/png">
    <title>Booking Registration Form</title>
    <!-- Bootstrap CSS - Lux theme -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-size: 17px;
            height: 100vh;
            color: black;
        }
        .container {
            padding-top: 50px;
        }
        .input-box {
            margin-bottom: 20px;
        }
        .form-row {
            margin-bottom: 20px;
        }
        .settings {
            margin-top: 30px;
        }
        .cancellation-note {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .view-location {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 10px;
        }
        .view-location i {
            margin-left: 5px;
        }

        
        
    </style>
     </head>
        <body>
        <div class="container">
        <header class="header mb-4">
            <h1 class="text-center">Booking Registration Form</h1>
        </header>
        <div class="text-right mb-4">
         
        </div><br>
        <form action="insertBOOKING.php" method="post" class="form">
            <div class="form-row">
                <div class="col-md-6">
                    <div class="input-box">
                        <label for="fullName">Full Name</label>
                        <input type="text" id="fullName" name="fullName" value="<?php echo $userRow['Fname'] . ' ' . $userRow['Lname']; ?>" class="form-control" required disabled>
                    </div>
                    <div class="input-box">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" value="<?php echo $userRow['Email']; ?>" class="form-control" required disabled>
                    </div>
                    <div class="input-box">
                        <label for="phoneNumber">Phone Number</label>
                        <input type="tel" id="phoneNumber" name="phoneNumber" value="<?php echo $userRow['CpNO']; ?>" class="form-control" required disabled>
                    </div>
                </div>
                <div class="col-md-6">
                   <div class="input-box">
                    <label for="changeServiceType">Service Chosen</label>
                    <select id="changeServiceType" class="form-control">
                        <option value="Haircut">Haircut</option>
                        <option value="Shave">Shave</option>
                        <option value="Haircut and Shave">Haircut and Shave</option>
                    </select>
                </div>
                    <div class="input-box">
                        <label for="servicePrice">Service Price</label>
                        <input type="text" id="servicePrice" name="servicePrice" value="<?php echo $price; ?>" class="form-control" required disabled>
                    </div>    
    

                <script>
    document.addEventListener("DOMContentLoaded", function() {
        var changeServiceTypeSelect = document.getElementById('changeServiceType');
        var servicePriceInput = document.getElementById('servicePrice');

        // Set initial values based on the default service type
        var servicePrices = {
            'Haircut': '200',
            'Shave': '100',
            'Haircut and Shave': '300'
        };
        var defaultServiceType = "<?php echo htmlspecialchars($serviceType); ?>";
        changeServiceTypeSelect.value = defaultServiceType;
        servicePriceInput.value = servicePrices[defaultServiceType];

        // Update service type and price when the user changes the dropdown selection
        changeServiceTypeSelect.addEventListener('change', function() {
            var selectedServiceType = changeServiceTypeSelect.value;
            servicePriceInput.value = servicePrices[selectedServiceType];
        });
    });
</script>
                </div>
            </div>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="input-box">
                        <label for="bookingDate">Choose Date</label>
                        <input type="date" id="bookingDate" name="bookingDate" class="form-control"  required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="input-box">
                        <label for="bookingTIME">Choose Time</label>
                        <select id="bookingTIME" name="bookingTIME" class="form-control" required>
                            <option value="">Select Time</option>
                            <!-- Options will be populated by JavaScript -->
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-box">
                        <label for="location">Location</label>
                        <input type="text" id="location" name="location" value="21 Doña Remedios Trinidad Hwy, Baliwag, 1630 Bulacan" class="form-control" disabled>
                        <input type="hidden" id="location_hidden" name="location" value="21 Doña Remedios Trinidad Hwy, Baliwag, 1630 Bulacan">
                    </div>
                    <div class="input-box">
                        <label for="barbername">Barber Chosen</label>
                        <input type="text" id="barbername" name="barbername" value="<?php echo "{$barberRow['Name']}" . " " . "{$barberRow['Lname']}"; ?>" class="form-control" disabled>
                        <input type="hidden" id="barbername_hidden" name="barbername" value="<?php echo "{$barberRow['Name']}" . " " . "{$barberRow['Lname']}"; ?>">
                    </div>
                </div>
            </div>
            <div class="settings text-center">
                <a href="cancelChosenBarber.php" class="btn btn-secondary back">Cancel</a>
                <input type="submit" value="Submit" class="btn btn-primary">
            </div>
        </form>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var bookingDateInput = document.getElementById('bookingDate');
            var bookingTimeSelect = document.getElementById('bookingTIME');

            bookingDateInput.addEventListener('change', function() {
                var bookingDate = bookingDateInput.value;
                var barberID = "<?php echo $barberID; ?>";

                // Send an AJAX request to fetch booked time slots
                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'fetchBookedSlots.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        var bookedSlots = JSON.parse(xhr.responseText);
                        updateBookingTimeOptions(bookedSlots);
                    } else {
                        console.error('Request failed. Status: ' + xhr.status);
                    }
                };
                xhr.send('barberID=' + barberID + '&bookingDate=' + bookingDate);
            });

            function updateBookingTimeOptions(bookedSlots) {
                var timeSlots = ["10am - 11am", "11am - 12pm", "12pm - 1pm", "1pm - 2pm", "3pm - 4pm", "5pm - 6pm", "6pm - 7pm"];
                bookingTimeSelect.innerHTML = ''; // Clear existing options
                timeSlots.forEach(function(timeSlot) {
                    var option = document.createElement('option');
                    option.value = timeSlot;
                    if (bookedSlots.includes(timeSlot)) {
                        option.disabled = true;
                        option.textContent = timeSlot + ' (Booked)';
                    } else {
                        option.textContent = timeSlot;
                    }
                    bookingTimeSelect.appendChild(option);
                });
            }
        });
    </script>
</body>
</html>
