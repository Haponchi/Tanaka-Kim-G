<?php
session_start();
require('adminCONX.php');

// Set default selected date if not provided
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Pagination
$limit = 15; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit;

// UserID search
$searchUserID = isset($_GET['userid']) ? $_GET['userid'] : '';

// Query to retrieve data from the "audit" table with pagination and optional UserID search
$sql = "SELECT a.*, u.Fname, a.*, u.Lname 
        FROM audit a 
        LEFT JOIN user u ON a.UserID = u.UserID 
        WHERE DATE(a.time) = ?";

$sql .= " ORDER BY time DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bindParam(1, $selectedDate);
if ($searchUserID) {
    $stmt->bindParam(2, $searchUserID);
    $stmt->bindParam(3, $limit, PDO::PARAM_INT);
    $stmt->bindParam(4, $offset, PDO::PARAM_INT);
} else {
    $stmt->bindParam(2, $limit, PDO::PARAM_INT);
    $stmt->bindParam(3, $offset, PDO::PARAM_INT);
}
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Trail Report</title>
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <style>
        body {
            font-family: 'Poppins';
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
            max-width: 1300px;
        }
        .form-group, .input-group, .table, .pagination, .mt-4 {
            margin-top: 10px;
        }
        .input-group {
            width: 100%;
        }
        .datepicker {
            z-index: 1151 !important; /* Ensures the datepicker is above other elements */
        }
        th, td {
            text-align: center;
        }
        .input-group-append .btn {
            margin-left: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="input-group-append">
        <h1 class="mb-4">Audit Trail Report</h1>
        <div style="padding-left: 750px ;">
        <a  class="btn btn-primary mt-4" href="gen_auditpdf.php" target="_blank">Download PDF</a>
      </div>
    </div>
    <div class="form-group">
        <h5 for="datepicker">Select Date:</h5>
        <input type="text" id="datepicker" class="form-control" value="<?php echo $selectedDate; ?>">
    </div>
    <form action="" method="get" class="mb-3">
        <input type="hidden" name="date" value="<?php echo $selectedDate; ?>">
        <div class="input-group">
            <input type="text" class="form-control" name="userid" id="searchInput" placeholder="Search by UserID..." aria-label="Search" aria-describedby="button-addon2" value="<?php echo isset($searchUserID) ? htmlspecialchars($searchUserID) : ''; ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit" id="button-addon2">Search</button>
                <button class="btn btn-secondary" type="button" id="filterAllButton">Show All</button>
            </div>
        </div>
    </form>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Action</th>
                <th>Time</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch data
            foreach ($result as $row) {
                echo '<tr>';
                echo '<td>' . $row['UserID'] . '</td>';
                echo '<td>' . $row['Fname']. ' ' . $row['Lname']. '</td>';
                echo '<td>' . $row['action'] . '</td>';
                echo '<td>' . $row['time'] . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="adminHOMEE.php" class="btn btn-secondary">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?date=<?php echo $selectedDate; ?>&userid=<?php echo htmlspecialchars($searchUserID); ?>&page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?date=<?php echo $selectedDate; ?>&userid=<?php echo htmlspecialchars($searchUserID); ?>&page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
</div>

<!-- Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<!-- Initialize Datepicker -->
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd') + '&userid=<?php echo htmlspecialchars($searchUserID); ?>';
        });

        $('#filterAllButton').click(function(){
            window.location.href = '?userid=<?php echo htmlspecialchars($searchUserID); ?>';
        });
    });
</script>

</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
