<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Brilliante Barbershop</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" href="images/logo.png" type="image/png">
  <link href="https://fonts.googleapis.com/css2?family=Old+English+Text+MT&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<body>
  <nav class="navbar">
    <img src="images/logo.png" alt="logo" class="nav-logo">
    <a href="index.php" class="nav-label" style="text-decoration: none; color: black">Brilliante Barbershop</a>
    <div class="nav-links">
      <a href="index.php"><b>Home</b></a>
      <a href="about.html">About Us</a>
      <a href="pagepolicy.html">Policy</a>
      <a href="form2.php"><b>Book Now</b></a>
    </div>
  </nav>
  <main>
    <div class="slideshow-container">
      <div class="mySlides fade">
        <img src="images/pic4.jpg" style="width:100%; height:5%;">
      </div>
      <div class="mySlides fade">
        <img src="images/pic3.jpg" style="width:100%">
      </div>
      <div class="mySlides fade">
        <img src="images/brill.jpg" style="width:100%">
      </div>
    </div>
    <div class="container">
      <h1>Services</h1>
      <br>
      <div class="pic-wrapper">
        <a href="form2.php" class="pic-container">
          <img src="images/haircut.jpg" alt="Haircut">
          <h4><b>Haircut</b><br>P200.00</h4>
        </a>
        <a href="form2.php" class="pic-container">
          <img src="images/shave.jpg" alt="Shave">
          <h4><b>Shave</b><br>P100.00</h4>
        </a>
        <a href="form2.php" class="pic-container">
          <img src="images/cutnshave.jpg" alt="Shave & Cut">
          <h4><b>Shave & Cut</b><br>P300.00</h4>
        </a>
      </div>
    </div>
  </main>
  <footer class="footer">
    <div class="footer-content">
      <img src="images/logo.png" alt="Brilliante Barbershop Logo" class="footer-logo">
      <div class="footer-title">
        <h2>Brilliante Barbershop</h2>
        <p class="footer-description">Get the freshest cut and finest shave in town!<br> We provide exceptional service in a relaxing atmosphere.</p>
      </div>
      <div class="footer-links">
        <h3>Links</h3>
        <a href="index.php">Home  |</a>
        <a href="about.html">About Us  |</a>
        <a href="pagepolicy.html">Policy</a>
        <div class="social-icons">
          <br>
          <a href="https://www.facebook.com/brilliantebarbershop"><img src="images/fblogo.png" alt="Facebook Page"></a>
          <a href="https://www.instagram.com/brilliantebarbershop/"><img src="images/iglogo.png" alt="Instagram Page"></a>
        </div>
       <div class="contact">
          <h2>Contact Us</h2>
          For inquiries and appointments, please contact us at:<br>
          Phone: 0917 560 0119
          <div style="width: 100%; margin-top: 20px;">


            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3856.1899295896865!2d120.8584234742253!3d14.87065438564833!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33965376e7974913%3A0x23516640d28935a1!2sBrilliante%20Barbershop!5e0!3m2!1sen!2sph!4v1730113411412!5m2!1sen!2sph" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
               width="100%"
              height="300"
              style="border:0;"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade">
            </iframe>
         
          </div>
        </div>
      </div>
    </div>
    <br>
    <p class="copyright">&copy; 2024 Brilliante Barbershop. All Rights Reserved.</p>
  </footer>
  <script>
    let slideIndex = 0;
    showSlides();

    function showSlides() {
      let slides = document.getElementsByClassName("mySlides");
      for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
      }
      slideIndex++;
      if (slideIndex > slides.length) {
        slideIndex = 1;
      }    
      slides[slideIndex - 1].style.display = "block";  
      setTimeout(showSlides, 5000); // Change image every 5 seconds
    }
  </script>
</body>
</html>
