<?php 
session_start();

require 'customerCONX.php';

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];
$price = $_SESSION['price'];

$insert_sql = "INSERT INTO audit (UserID, Action) VALUES (?, 'Chosen Paymaya Payment')";
$stmt = $conn->prepare($insert_sql);
$stmt->execute([$id]);

$sql = "SELECT * FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "User details not found.";
    exit();
}

$sql = "SELECT * FROM user WHERE Type = 'admin'";
$stmt = $conn->prepare($sql);
$stmt->execute();
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    echo "Admin details not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Method | Brilliante</title>
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
            padding-top: 5px;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        .gcash-logo {
            width: 100px;
            height: auto;
            margin-left: 10px;
        }
        .btn-custom {
            width: 100%;
            margin: 5px 0;
        }
        .input-box {
            margin-bottom: 1rem;
        }
        .input-box label {
            font-weight: bold;
        }
        .details {
            margin-bottom: 1rem;
        }
        .alert {
            margin-top: 1rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="card-title">PAYMAYA PAYMENT</h3>
                <img src="Images/paymaya.jpg" class="gcash-logo" alt="GCash Logo">
            </div>
            <form action="paymayaverify.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="cost" value="<?php echo $Price; ?>">
               <!--  <div class="form-group">
                    <label for="bookingID">Booking ID</label>
                    <input type="text" id="bookingID" name="bookingID" value="<?php echo $bookingID; ?>" class="form-control" required disabled>
                </div> -->
                <div class="form-group">
                    <label for="cost">Amount</label>
                    <input type="text" id="cost" name="cost" value="<?php echo $price; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="receivername">Receiver Name</label>
                    <input type="text" id="receivername" name="receivername" value="<?php echo $admin['Fname'] . ' ' . $admin['Lname']; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="sendername">Sender Name</label>
                    <input type="text" id="sendername" name="sendername" value="<?php echo $user['Fname'] . ' ' . $user['Lname']; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="receivernumber">Receiver Number</label>
                    <input type="text" id="receivernumber" name="receivernumber" value="<?php echo $admin['CpNO']; ?>" class="form-control" required disabled>
                </div>
                <div class="form-group">
                    <label for="sendernumber">Sender Number</label>
                    <input type="text" id="sendernumber" name="sendernumber" value="<?php echo $user['CpNO']; ?>" class="form-control" required disabled>
                </div>
          <!--       <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="text" id="amount" name="amount" class="form-control" required>
                </div> -->
                <div class="form-group d-flex justify-content-between">
                    <a href="cancelpaymentbook.php" class="btn btn-danger btn-custom"><i class="fas fa-times"></i> Cancel</a>
                    <button type="submit" class="btn btn-success btn-custom"><i class="fas fa-check"></i> Pay and Reserve</button>
                </div>
                <?php 
                if (isset($_SESSION['notequal']) === true) {
                    echo '<div class="alert alert-danger" role="alert">Input an equal amount.</div>';
                    unset($_SESSION['notequal']);
                }
                ?>
            </form>
        </div>
    </div>
</div>
</body>
</html>

<?php 
$conn = null;
?>
