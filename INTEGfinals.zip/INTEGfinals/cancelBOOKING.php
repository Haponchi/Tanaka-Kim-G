<?php 
session_start();

require 'customerCONX.php';

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];
$barbername = $_SESSION['barberName'];


$insert_sql = "INSERT INTO audit (UserID, Action) VALUES ('$id', 'Cancelled Date and Time of Booking')";
$conn->query($insert_sql);


$insert_sql = "INSERT INTO audit (UserID, Action) VALUES ('$id', 'Cancelled Booking')";
$conn->query($insert_sql);



$sql = "DELETE FROM booking WHERE BookingID = '$bookingID'";
$conn->query($sql);



    echo "<script>alert('your booking has been successfully cancelled. We hope to serve you again in the future.'); window.location.href = 'book.php';</script>";

// Close the database connection
$conn->close();
?>
