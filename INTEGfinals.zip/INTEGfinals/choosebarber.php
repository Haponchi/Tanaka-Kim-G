<?php
session_start();
require('customerCONX.php');

$userID = $_SESSION['c']; // Assuming 'c' is the correct session key for user ID
$serviceID = $_SESSION['serviceID'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Barber</title>
    <!-- Bootstrap CSS - Lux theme -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <link rel="icon" href="images/logo.png" type="image/png">

    <style>
        body {
            height: 100vh;
          font-family: 'Poppins';
          background: url("Images/flat.jpg");
          background-position: center;
          background-size: cover;
          font-size: 19px;
        }
        .container {
            padding-top: 30px;
        }
        .available,
        .unavailable,
        .view {
            padding: 10px 50px;
            border-radius: 5px;
            margin-right: 10px;
        }
        .available {
            background-color: green;
            color: white;
        }
        .unavailable {
            background-color: green;
            color: white;        
        }
        .view {
            background-color: green;
            color: white;
        }
        .pagination {
            justify-content: center;
        }
        .note {
            color: red;
            text-align: left;
            margin-bottom: 20px;
        }
        th, td{
            text-align: center;
            align-items: center;
            text-decoration:;
            font-weight: 500;
            color:black;
        }
    </style>
</head>
<body>
<div class="container">
    <h1 class="mt-5 mb-4">Choose a Barber</h1>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <!-- Search bar -->
            <form action="" method="get" class="mb-3">
                <div class="input-group">
                    <input type="text" class="form-control" id="searchInput" placeholder="Search by name..." aria-label="Search" aria-describedby="button-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button" id="button-addon2">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
     <div ><h6>
            Note: If you have an ongoing transaction. You cannot create another booking until it is completed.
        </h6></div>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
        <tr>
            <th>Name</th>
            <th>Availability</th>
            <th>Profile</th>
            <th>Book</th>
        </tr>
        </thead>
        <tbody id="barberTable">
        <?php
        // Pagination
        $limit = 10; // Number of records per page
        $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

        // Calculate offset for pagination
        $offset = ($page - 1) * $limit;

        // Query to retrieve data from the "barbers" table with pagination
        $sql = "SELECT * FROM barbers WHERE Status = 1 LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($result as $row) {
            echo '<tr>';
            echo '<td>';
            echo $row['Name'] . " " . $row['Lname'];
            echo '</td>';
            echo '<td>' . $row['Availability'] . '</td>';
            echo '<td><form action="viewbarberprofcustomer.php" method="post">';
            echo '<input type="hidden" name="barberID" value="' . $row['barberID'] . '">';
            echo '<button type="submit" class="view">View</button>';
            echo '</form></td>';

            // Check if availability is "unavailable"
            if ($row['Availability'] == "Unavailable") {
                // If availability is "unavailable", disable the button
                echo '<td><button type="submit" class="unavailable" disabled>Unavailable</button></td>';
            } else {
                // If availability is "available", enable the button
                echo '<td><form action="chosenBarber.php" method="post">';
                echo '<input type="hidden" name="barberID" value="' . $row['barberID'] . '">';
                echo '<button type="submit" class="available">Yes</button>';
                echo '</form></td>';
            }
            echo '</tr>';
        }
        ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item"  style = "font-weight: 500">
                <a class="page-link" href="cancelSERVICES.php" class="back">Cancel</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>" style = "font-weight: 500">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item" style = "font-weight: 500">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
    <?php
    if (isset($_SESSION['noAvailableSlot']) === true) {
        echo "No Available Slot Choose different time, day, or month.";
        unset($_SESSION['noAvailableSlot']);
    }
    ?>
    <!-- Add buttons for PDF conversion -->
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const barberTable = document.getElementById('barberTable');

        searchInput.addEventListener('input', function() {
            const searchTerm = searchInput.value.toLowerCase();
            const rows = barberTable.getElementsByTagName('tr');

            for (let i = 0; i < rows.length; i++) {
                const nameCell = rows[i].getElementsByTagName('td')[0];
                if (nameCell) {
                    const nameText = nameCell.textContent || nameCell.innerText;
                    if (nameText.toLowerCase().indexOf(searchTerm) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });
    });
</script>

</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
