<?php
require 'adminCONX.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Update the status of all barbers to unavailable (assuming 'Unavailable' is the correct value)
        $sql = "UPDATE barbers SET Availability = 'Unavailable'";
        $stmt = $conn->prepare($sql);

        if ($stmt->execute()) {
            echo "<script>alert('All barbers\' statuses updated to unavailable successfully!'); window.location.href = 'registeredbarber.php';</script>";
        } else {
            throw new Exception("Error updating barbers' statuses: " . implode(", ", $stmt->errorInfo()));
        }
    } catch (Exception $e) {
        echo $e->getMessage();
    }
}
?>
