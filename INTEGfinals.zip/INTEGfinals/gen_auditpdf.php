<?php
// Include TCPDF library
require_once('tcpdf/tcpdf.php');
require('adminCONX.php');

$sql = "SELECT * FROM audit";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Audit Trail Report');
$pdf->SetTitle('Audit Trail Report');
$pdf->SetSubject('Audit Trail Report');
$pdf->SetKeywords('TCPDF, PDF, report');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 10);

// Header
$pdf->writeHTML('<h1 class="text-center mb-4">Audit Trail Report - Brilliante Barbershop</h1>', true, false, true, false, '');
$pdf->writeHTML('<p class="text-center">Report generated on ' . date('Y-m-d') . '</p>', true, false, true, false, '');

// Table
$html = '<table border="1" cellspacing="0" cellpadding="5">';
$html .= '<thead>';
$html .= '<tr><th>Audit ID</th><th>User ID</th><th>Time</th><th>Action</th></tr>';
$html .= '</thead>';
$html .= '<tbody>';

// Loop through the results
foreach ($result as $row) {
    // Add data for each record
    $html .= '<tr>';
    $html .= '<td>' . $row['auditID'] . '</td>';
    $html .= '<td>' . $row['UserID'] . '</td>';
    $html .= '<td>' . $row['time'] . '</td>';
    $html .= '<td>' . $row['action'] . '</td>';
    $html .= '</tr>';
}

$html .= '</tbody>';
$html .= '</table>';

// Output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// Close and output PDF document
$pdf->Output('Audit_Trail_Report.pdf', 'D');

// Close the database connection
$conn = null;
?>
