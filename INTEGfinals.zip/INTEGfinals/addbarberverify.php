<?php
session_start();

require 'adminCONX.php';

// Retrieve form data
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$phonenumber = $_POST['phonenumber'];
$defaultPicture = 'nopic.jpg';


// Check if email or cpno already exist in the database
$checkQuery = "SELECT * FROM barbers WHERE Email = :email OR CpNO = :phonenumber";
$stmt = $conn->prepare($checkQuery);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':phonenumber', $phonenumber);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    echo "<script>alert('Email or phone number already exists.'); window.location.href = 'addbarber.php';</script>";
    exit();
} else {


       if(isset($_FILES['Picture']) && $_FILES['Picture']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'Images/'; // Directory to store uploaded files
            $uploadFile = $uploadDir . basename($_FILES['Picture']['name']);

            // Move the uploaded file to the desired location
            if (move_uploaded_file($_FILES['Picture']['tmp_name'], $uploadFile)) {
                // File upload was successful, store the file path in the database
                $picturePath = $uploadFile;
            } else {
                // File upload failed, handle the error
                echo "Error uploading file.";
                $picturePath = $defaultPicture; // Use default picture
            }
        } else {
            // No file was uploaded or an error occurred during upload
            $picturePath = $defaultPicture; // Use default picture
        }

    // Insert data into barbers table
    $insertSql = "INSERT INTO barbers (Name, Lname, Email, CpNO, Availability ,Status, Picture) VALUES (:firstname, :lastname, :email, :phonenumber, 'Available', 1, :defaultPicture)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bindParam(':firstname', $firstname);
    $stmt->bindParam(':lastname', $lastname);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phonenumber', $phonenumber);
    $stmt->bindParam(':defaultPicture', $picturePath);      

    if ($stmt->execute()) {
        echo "<script>alert('Barber Registered Successfully.'); window.location.href = 'adminHOMEE.php';</script>";
    } else {
        echo "Error: " . $stmt->errorInfo()[2];
    }
}

// Close connection
$conn = null;
?>
