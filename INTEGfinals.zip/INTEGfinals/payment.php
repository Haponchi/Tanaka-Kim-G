<?php 
session_start();
require 'customerCONX.php';

$id = $_SESSION['c'];
$bookingID = $_SESSION['BookingID'];
$barberID = $_SESSION['barberID'];

$barbername = $_SESSION['barberName'];

$price = $_SESSION['price'];


$sql = "SELECT * FROM booking WHERE BookingID = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$bookingID]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $row = $result;

    $sql = "SELECT * FROM user WHERE UserID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        $user = $result;

        $serviceID = $row['ServiceID'];
        $sql = "SELECT * FROM services WHERE ServiceID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$serviceID]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $service = $result;
            // $_SESSION['Price'] = $service['Price'];
        } else {
            echo "Service details not found.";
        }
    } else {
        echo "User details not found.";
    }
} else {
    echo "Booking details not found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png" type="image/png">
    <title>Payment Method | Brilliante</title>
    <!-- Bootstrap CSS - Lux theme -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
            font-size: 17px;
            color: black;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 500px;
        }
        .title {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            font-weight: bold;
        }
        .content {
            margin-top: 1rem;
        }
        .form-group label {
            font-weight: bold;
        }
        .button {
            margin-top: 1.5rem;
            display: flex;
            justify-content: space-between;
        }
        .button .btn {
            width: 32%;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="title">Payment Method</div>
        <div class="content">
            <form method="post">
                <div class="user-details">
                    <input type="hidden" name="cost" value="<?php echo $service['Price']; ?>">
                    <div class="form-group">
                        <label for="bookingID">Booking ID</label>
                        <input type="text" id="bookingID" name="bookingID" value="<?php echo $row['BookingID']; ?>" class="form-control" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="senderName">Sender Name</label>
                        <input type="text" id="senderName" name="senderName" value="<?php echo $user['Fname'] . " " . $user['Lname']; ?>" class="form-control" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="cost">Cost of Service</label>
                        <input type="text" id="cost" name="cost" value="<?php echo $service['Price']; ?>" class="form-control" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="serviceChosen">Service Chosen</label>
                        <input type="text" id="serviceChosen" name="serviceChosen" value="<?php echo $service['Type']; ?>" class="form-control" required disabled>
                    </div>
                </div>
                <div class="details">
                    <span class="font-weight-bold">Choose a Method</span>
                </div>
                <div class="button">
                    <a href="cancelBOOKING.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                    <a href="gcash.php" class="btn btn-success"><i class="fas fa-wallet"></i> G-Cash</a>
                    <a href="paymaya.php" class="btn btn-primary"><i class="fas fa-credit-card"></i> PayMaya</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php 
$conn = null; // Close the PDO connection
?>




