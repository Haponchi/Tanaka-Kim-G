<?php 
session_start();

require 'adminCONX.php';

// Retrieve user ID from session

$userID = $_POST['userID'];

$_SESSION['userID'] = $userID;


$sql = "SELECT * FROM user WHERE UserID = :userID";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':userID', $userID); // Use ':userID' here
$stmt->execute();

if ($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Lux theme CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Add any custom styles here */
        .center-image {
            display: flex;
            justify-content: center;
        }
           .profile-container {
            text-align: center;
        }
        #preview {
            width: 450; /* Adjust the width as needed */
            height: 250px; /* Maintain aspect ratio */
            display: block;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3 profile-container">
                <div class="text-center mb-4">
                    <h2>User Profile</h2>
                </div>
                <div class="text-center">
                    <div class="imgdiv center-image">
                        <img id="preview" src="images/<?php echo $row['Picture']; ?>" alt="Profile Picture">
                    </div>
                    <h4 class="mt-3"><?php echo $row['Fname'] . ' ' . $row['Lname']; ?></h4>
                </div>
                <form action="updateadminuser.php" method="post" enctype="multipart/form-data">
                    <div class="form-group mt-4">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" value="<?php echo $row['Email']; ?>" >
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" id="cp" name="cellphonenumber"  required pattern="09\d{9}" value="<?php echo $row['CpNO']; ?>" >
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="userREGISTERED.php" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>      
</body>
</html>
<?php
} // Closing brace for if ($stmt->rowCount() > 0)
$conn = null;
?>
