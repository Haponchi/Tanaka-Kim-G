
<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Registration Form | Brilliante</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <style>
        .links{
            padding-left: 650px;
           

        }

        .container{
                position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("images/home.jpg") center/cover no-repeat;
            filter: blur(5px); /* Adjust the blur value as needed */
            z-index: -1;
        }
    </style>
</head>
<body>
    <div class="container"></div>
    <header>
        <nav class="navbar">
            <span class="hamburger-btn material-symbols-rounded">menu</span>
            <a href="#" class="logo">
                <img src="images/logo.jpg" alt="logo">
                <h2>Brilliante</h2>
            </a>
            <ul class="links">
                <span class="close-btn material-symbols-rounded">close</span>
                <li><a style="color: black; height: 50px ;: " href="policy.html">Policy</a></li>
                <li><a style="color: black;" href="abouts.html">About us</a></li>
            </ul>
            <button class="login-btn">BOOK NOW</button>
        </nav>
    </header>

    <div class="blur-bg-overlay"></div>
    <div class="form-popup">
        <span class="close-btn material-symbols-rounded"><b>x</b></span>
        <div class="form-box login">
            <div class="form-details">  
            </div>
            <div class="form-content">
                <h2>LOGIN</h2>
                <form action="loginHANDLER.php" method="POST">
                    <div class="input-field">
                        <input type="email" name="email" placeholder="Email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" placeholder="Password" required >
                    </div>
                    <a href="resetform.php" class="forgot-pass-link" id="forgot-pass-link">Forgot password?</a>
                    <button type="submit">Log In</button>
                </form>
                <div class="bottom-link">
                    Don't have an account?
                    <a href="#" id="signup-link">Signup</a>
                </div>
            </div>
        </div>
        <div class="form-box signup">
            <div class="form-details">
            </div>
            <div class="form-content">
                <h2>SIGNUP</h2>
                <form action="registerHANDLER.php" method="POST" enctype="multipart/form-data">
                    <div class="input-field">
                        <input type="text" name="username" placeholder="Username" required pattern="^[a-zA-Z]+$">
                    </div>
                    <div class="input-field">
                        <input type="text" name="firstname" placeholder="First name" required pattern="^[a-zA-Z\s.]+$">
                    </div>
                    <div class="input-field">
                        <input type="text" name="lastname" placeholder="Last name" required pattern="^[a-zA-Z\s.]+$">
                    </div>
                    <div class="input-field">
                        <input type="text" name="cpnumber" placeholder="Cellphone Number" required pattern="09\d{9}" title="follow this format 09XXXXXXXXX">
                    </div>
                    <div class="input-field">
                        <input type="email" class="form-control" id="email" placeholder="Email" name="email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Please enter a valid Gmail address" required>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" placeholder="Password" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$">
                    </div>
                    <button type="submit">Sign Up</button>
                </form>
                <div class="bottom-link">
                    Already have an account? 
                    <a href="#" id="login-link">Login</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`


