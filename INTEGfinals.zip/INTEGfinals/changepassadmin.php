<?php 
session_start();

require 'customerCONX.php';

// Retrieve user ID from session
$id = $_SESSION['c'];

$sql = "SELECT * FROM user WHERE userID = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $id);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Change Password | Brilliante</title>
    <link rel="icon" href="images/logo.png" type="image/png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <link href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
          font-family: 'Poppins';
          background: url("Images/comb.jpg");
          background-position: center;
          background-size: cover;
          padding-top: 140px;
        }
        .container {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }
        .btn-custom {
            width: 100%;
            margin: 5px 0;
        }
        .alert {
            margin-top: 1rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="title">Change Password</h3>
    </div>
    <div class="content">
        <form action="changepassverifyadmin.php" method="post">
            <div class="form-group">
                <label for="name" class="details">Name</label>
                <input type="text" id="name" class="form-control" value="<?php echo $row['Fname'] . " " . $row['Lname']; ?>" required disabled>
            </div>
            <div class="form-group">
                <label for="oldpass" class="details">Old Password</label>
                <input type="password" id="oldpass" name="oldpass" class="form-control" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$">
            </div>
            <div class="form-group">
                <label for="newpass" class="details">New Password</label>
                <input type="password" id="newpass" name="newpass" class="form-control" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$">
            </div>
            <div class="form-group">
                <label for="confirmpass" class="details">Confirmed Password</label>
                <input type="password" id="confirmpass" name="confirmpass" class="form-control" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$">
            </div>
            <div class="d-flex justify-content-between">
                <a href="adminHOMEE.php" class="btn btn-danger btn-custom"><i class="fas fa-times"></i> Cancel</a>
                <button type="submit" class="btn btn-primary btn-custom"><i class="fas fa-check"></i> Submit</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>

<?php 
} else {
    echo "User not found.";
}
$conn = null; // Close the database connection
?>
