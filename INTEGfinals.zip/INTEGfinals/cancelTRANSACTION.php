<?php
session_start();
require 'customerCONX.php';

// User ID from session
$id = $_SESSION['c'];

$bookingID = $_POST['booking_id'];
$_SESSION['BookingID'] = $bookingID;

// Fetch booking details to check if it's within the cancellation period
$query_booking = "SELECT Date FROM booking WHERE BookingID = :booking_id";
$stmt_booking = $conn->prepare($query_booking);
$stmt_booking->bindParam(':booking_id', $bookingID);
$stmt_booking->execute();
$booking = $stmt_booking->fetch(PDO::FETCH_ASSOC);

if ($booking) {
    $bookingDate = strtotime($booking['Date']);
    $current_time = time(); // Current timestamp

    // Check if the booking is within the cancellation period (1 day before)
    if ($bookingDate - $current_time < 86400) {
        echo "<script>
                alert('You cannot cancel a booking within one day before the booking date.');
                window.location.href = 'bookingcustomer.php';
              </script>";
        exit;
    }
}

// Prepare the SQL statement to update the booking status to 'Cancelled'
$sql = "UPDATE booking SET Status = 'Cancelled' WHERE BookingID = :booking_id";

// Prepare the statement to insert action into audit log
$insert_sql = "INSERT INTO audit (UserID, Action) VALUES (:user_id, 'Cancelled Booking')";
$insertStmt = $conn->prepare($insert_sql);
$insertStmt->bindParam(':user_id', $id);

// Prepare the statement to update the booking status
$stmt = $conn->prepare($sql);
$stmt->bindParam(':booking_id', $bookingID);

// Begin transaction
$conn->beginTransaction();

try {
    // Display confirmation dialog using JavaScript
    echo "<script>
            if (confirm('Are you sure you want to cancel this booking?\\nNote: Refund is not accepted.')) {
                window.location.href = 'cancel_booking.php?action=confirm';
            } else {
                window.location.href = 'bookingcustomer.php';
            }
          </script>";

    // Check if the user confirmed the cancellation
    if (isset($_GET['action']) && $_GET['action'] === 'confirm') {
        // Execute the update statement
        $stmt->execute();

        // Execute the insert statement for audit log
        $insertStmt->execute();

        // Commit transaction if user confirms cancellation
        $conn->commit();
    } else {
        // Rollback the transaction if user cancels the confirmation dialog
        $conn->rollback();
    }
} catch (Exception $e) {
    // Rollback the transaction if an error occurred
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}
?>

