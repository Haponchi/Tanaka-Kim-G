use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/vendor/autoload.php"; // Include Composer's autoload file for PHPMailer