<?php
session_start();
require 'customerCONX.php';
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
// Check if the seed phrase session variable exists
if(isset($_SESSION['seedPhrase'])) {
    // Get the seed phrase
    $seedPhrase = $_SESSION['seedPhrase'];
} else {
    $seedPhrase = "Seed phrase not found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Seed Phrase</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            padding-top: 100px;
        }
        .container {
            margin-top: 50px;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            font-weight: 300;
            color: #343a40;
            margin-bottom: 30px;
        }
        .seed-phrase {
            font-size: 1.2em;
            padding: 15px;
            background: #e9ecef;
            border-radius: 5px;
            margin-bottom: 20px;
            word-wrap: break-word;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 5px;
        }
        .note p {
            margin-top: 20px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <h2>Your Seed Phrase</h2>
        <div class="seed-phrase" id="seedPhrase"><?php echo $seedPhrase; ?></div>
        <button id="toggleBtn" class="btn btn-secondary mb-3" onclick="toggleSeedPhrase()">Hide Seed Phrase</button>
        <button class="btn btn-primary mb-3 done-btn" onclick="done()">Done</button>
        <a class="btn btn-success mb-3" href="gen_seedphrase.php" target="_blank">Download PDF</a>
        <div class="note">
            <p><strong>Note:</strong> Please save your seed phrase in a secure place. Do not share it with anyone.</p>
        </div>
    </div>

    <script>
        function toggleSeedPhrase() {
            var seedPhraseElement = document.getElementById("seedPhrase");
            var toggleBtn = document.getElementById("toggleBtn");

            if (seedPhraseElement.style.display === "none") {
                seedPhraseElement.style.display = "block";
                toggleBtn.innerHTML = "Hide Seed Phrase";
            } else {
                seedPhraseElement.style.display = "none";
                toggleBtn.innerHTML = "Show Seed Phrase";
            }
        }

        function done() {
            window.location.href = 'index.php'; // Redirect to the desired page after done
        }
    </script>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
