<?php 
session_start();

require 'adminCONX.php';
$id = $_SESSION['c'];

$PaymentID = $_POST['PaymentID'];
$sql = "UPDATE payment SET Status = 'Paid', DatePaid = CURRENT_TIMESTAMP WHERE PaymentID = '$PaymentID'";
    
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Update Successfully.'); window.location.href = 'paymentadmin.php';</script>";
} else {
    echo "Error updating availability: " . $conn->error;
}

// Close the database connection
$conn->close();

?>
