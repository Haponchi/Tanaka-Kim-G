<?php
session_start();
$id = $_SESSION['c'];

require_once('tcpdf/tcpdf.php');
require('adminCONX.php');

try {
    $sql = "
        SELECT 
            p.PaymentID AS payment_id,
            p.BookingID, 
            b.Date AS booking_date, 
            b.Time AS booking_time, 
            s.Type AS service_type, 
            s.Price, 
            p.Method, 
            p.DatePaid, 
            p.Amount, 
            p.Status,
            bar.Name AS barber_name,
            bar.Picture AS barber_profile_pic
        FROM 
            payment p
        JOIN 
            booking b ON p.BookingID = b.BookingID
        JOIN 
            services s ON b.ServiceID = s.ServiceID
        JOIN 
            barbers bar ON b.barberID = bar.barberID
        ORDER BY 
            p.Created_At DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Initialize TCPDF
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Transaction Record');
    $pdf->SetTitle('Transaction Record');
    $pdf->SetSubject('Transaction Record');
    $pdf->SetKeywords('TCPDF, PDF, report');

    // Remove default header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 10);

    // Header
    $pdf->writeHTML('<h1 class="text-center mb-4">Transaction Report - Brilliante Barbershop</h1>', true, false, true, false, '');
    $pdf->writeHTML('<p class="text-center">Report generated on ' . date('Y-m-d') . '</p>', true, false, true, false, '');

    // Table
    $html = '<table border="1" cellspacing="0" cellpadding="5">';
    $html .= '<thead>';
    $html .= '<tr><th>Payment ID</th><th>Booking ID</th><th>Service Type</th><th>Method</th><th>Date Paid</th><th>Amount</th><th>Status</th></tr>';
    $html .= '</thead>';
    $html .= '<tbody>';

    // Loop through the results
    foreach ($result as $row) {
        // Add data for each record
        $html .= '<tr>';
        $html .= '<td>' . $row['payment_id'] . '</td>';
        $html .= '<td>' . $row['BookingID'] . '</td>';
        $html .= '<td>' . $row['service_type'] . '</td>';
        $html .= '<td>' . $row['Method'] . '</td>';
        $html .= '<td>' . $row['DatePaid'] . '</td>';
        $html .= '<td>' . $row['Amount'] . '</td>';
        $html .= '<td>' . $row['Status'] . '</td>';
        $html .= '</tr>';
    }

    $html .= '</tbody>';
    $html .= '</table>';

    // Output the HTML content
    $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    $pdf->Output('Transaction_Record.pdf', 'D');

} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
}

// Close the database connection
$conn = null;
?>
