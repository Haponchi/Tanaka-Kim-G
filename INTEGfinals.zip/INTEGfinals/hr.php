<!DOCTYPE html>
<html>
<head>
  <title>Ring Topology Simulation</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
    }
    #network {
      width: 400px;
      height: 400px;
      position: relative;
      border-radius: 50%;
      border: 2px solid #333;
      margin: 50px auto;
      margin-top: 200px;
    }
    .device {
      position: absolute;
      width: 100px;
      height: 100px;
    }

    .device img {
      width: 100px;
      height: 100px;
    }

    button {
      position: absolute;
      width: 40px;
      height: 20px;
      font-size: 10px;
      background-color: #f0f0f0;
      border: 1px solid #333;
      border-radius: 5px;
    }

    .on-off {
        background-color: green;
    }

    #universal {
        top: 150px;
        left: 500px;
    }

    #on-off0 {
      top: 10px;
      left: 150px;
    }

    
    #on-off1 {
      top: 10px;
      left: -100px;
    }

    #on-off2 {
      top:  -80px;
      left: 25px;
    }

    #on-off3 {
      top:  130px;
      left: 30px;
    }

    #failure3 {
      top: 170px;
      left: 30px;
    }

    #failure2 {
      top: -40px;
      left: 25px;
    }

    #failure1 {
      top: 50px;
      left: -100px;
    }

    #failure0 {
      top: 50px;
      left: 150px;
    }

    .hidden {
      display: none;
    }

    #data {
      position: absolute;
      width: 20px;
      height: 20px;
      background-color: blue;
      border-radius: 50%;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      animation: moveData 5s linear infinite;
    }

    @keyframes moveData {
        0% { left: 200px; top: -10px; }
        8.33% { left: 310px; top: 30px; }
        16.66% { left: 380px; top: 120px; }
        25% { left: 400px; top: 210px; }
        33.33% { left: 380px; top: 300px; }
        41.66% { left: 300px; top: 370px; }
        50% { left: 200px; top: 400px; }
        58.33% { left: 100px; top: 370px; }
        66.66% { left: 30px; top: 300px; }
        75% { left: 0px; top: 210px; }
        83.33% { left: 20px; top: 120px; }
        91.66% { left: 80px; top: 30px; }
        100% { left: 200px; top: -10px; }
    }
  </style>
</head>
<body>
  <h1>Ring Topology Simulation</h1>
  <div id="network">
    <div class="device" id="device1" style="top: -40px; left: 150px;">
      <img src="Images/pc.png" alt="Device 1">
      <br>
      <button id="on-off2" class="on-off">On</button>
      <button id="failure2">Failure</button>
    </div>
    <div class="device" id="device2" style="top: 80px; left: 330px;">
      <img src="Images/pc.png" alt="Device 2">
      <br>
      <button id="on-off0" class="on-off">On</button>
      <button id="failure0">Failure</button>
    </div>
    <div class="device" id="device3" style="top: 260px; left: 330px;">
      <img src="Images/pc.png" alt="Device 3">
      <br>
      <button id="on-off0" class="on-off">On</button>
      <button id="failure0">Failure</button>
    </div>
    <div class="device" id="device4" style="top: 360px; left: 150px;">
      <img src="Images/pc.png" alt="Device 4">
      <br>
      <button id="on-off3" class="on-off">On</button>
      <button id="failure3">Failure</button>
    </div>
    <div class="device" id="device5" style="top: 260px; left: -20px;">
      <img src="Images/pc.png" alt="Device 5">
      <br>
      <button id="on-off1" class="on-off">On</button>
      <button id="failure1">Failure</button>
    </div>
    <div class="device" id="device6" style="top : 80px; left: -20px;">
        <img src="Images/pc.png" alt="Device 6">
        <br>
        <button id="on-off1" class="on-off">On</button>
        <button id="failure1">Failure</button>
      </div>
      <div id="data"></div>
    </div>
    <button id="universal">Universal On/Off</button>
  
    <script>
        let allDevicesOn = false; // Flag to track if all devices are turned on
    
        document.querySelectorAll('.device button').forEach(button => {
          button.addEventListener('click', function() {
            const onOffButton = this;
            if (this.classList.contains('on-off')) {
              if (onOffButton.textContent === 'On') {
                onOffButton.textContent = 'Off'; 
                onOffButton.style.backgroundColor = 'red'; // Change button color to red for Off
              } else {
                onOffButton.textContent = 'On';
                onOffButton.style.backgroundColor = 'green'; // Change button color to green for On
              }
              checkAllDevicesOn(); // Check if all devices are turned on after each click
            } else if (this.id.startsWith('failure')) {
              const deviceIndex = this.id.replace('failure', '');
              const onOffButton = document.getElementById('on-off' + deviceIndex);
              if (onOffButton.disabled) {
                onOffButton.disabled = false;
                onOffButton.textContent = 'On';
                onOffButton.style.backgroundColor = 'green';
              } else {
                onOffButton.disabled = true;
                onOffButton.initialState = onOffButton.textContent; // Store initial state
                onOffButton.textContent = 'Fix';
                onOffButton.style.backgroundColor = 'gray';
                stopDataAnimation(); // Stop data animation when failure button is clicked
              }
            } else if (this.classList.contains('fix')) {
              const onOffButton = document.getElementById('on-off' + this.id.replace('fix', ''));
              onOffButton.disabled = false;
              onOffButton.textContent = onOffButton.initialState; // Set button back to initial state
              onOffButton.style.backgroundColor = onOffButton.initialState === 'Off' ? 'green' : 'red';
            }
          });
        });
    
        document.getElementById('universal').addEventListener('click', function() {
          const devices = document.querySelectorAll('.device');
          devices.forEach(device => {
            const onOffButton = device.querySelector('.on-off');
            const currentState = onOffButton.textContent === 'On';
            const desiredState = currentState ? 'Off' : 'On';
            if (onOffButton.textContent !== desiredState) {
              onOffButton.textContent = desiredState;
              onOffButton.style.backgroundColor = desiredState === 'On' ? 'green' : 'red'; // Change button color accordingly
            }
          });
          checkAllDevicesOn(); // Check if all devices are turned on after universal button click
        });
    
        function checkAllDevicesOn() {
          const devices = document.querySelectorAll('.device');
          allDevicesOn = true;
          devices.forEach(device => {
            const onOffButton = device.querySelector('.on-off');
            if (onOffButton.textContent !== 'On') {
              allDevicesOn = false;
            }
          });
          if (allDevicesOn) {
            startDataAnimation();
          } else {
            stopDataAnimation();
          }
        }
    
        function startDataAnimation() {
          document.getElementById('data').style.display = 'block';
          document.getElementById('data').style.animationPlayState = 'running';
        }
    
        function stopDataAnimation() {
          document.getElementById('data').style.display = 'none';
          document.getElementById('data').style.animationPlayState = 'paused';
        }
    
      </script>
    
    
    
      
  </body>
  </html>