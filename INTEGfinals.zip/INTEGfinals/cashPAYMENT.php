<?php
session_start();

$id = $_SESSION['c'];

require 'customerCONX.php';

$bookingID = $_SESSION['BookingID'];
$cost = $_POST['cost'];


$insert_sql = "INSERT INTO audit (UserID, Action) VALUES ('$id', 'Chosen Cash Payment')";
$conn->query($insert_sql);


// Assuming the structure of the payment table
$sql = "INSERT INTO payment (BookingID, Method, Amount, Status) VALUES ('$bookingID', 'Cash', '$cost', 'Pending')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Thank you for choosing Brilliante! Your booking has been confirmed. Please note that if you do not arrive at the location within 30 minutes of your scheduled time, your reservation will be cancelled.'); window.location.href = 'customerPAGE.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
