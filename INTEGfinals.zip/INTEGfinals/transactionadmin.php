<?php
session_start();
require('adminCONX.php');

$userID = $_SESSION['c']; // Assuming 'c' is the correct session key for user ID

// Initialize variables
$dateRange = null;
$startDate = null;
$endDate = null;

// Check if the "All" button is clicked
if (isset($_POST['all'])) {
    // Set $dateRange to null to indicate no date filtering
    $dateRange = null;
} else {
    // Check if start and end dates are provided in the form submission
    if (isset($_POST['start_date']) && isset($_POST['end_date'])) {
        $startDate = $_POST['start_date'];
        $endDate = $_POST['end_date'];
        $dateRange = ["$startDate 00:00:00", "$endDate 23:59:59"];
    } else {
        $dateRange = null; // No date range specified
    }
}

// Define the query to retrieve total earnings
$totalEarningsQuery = "
    SELECT SUM(p.Amount) as TotalEarnings
    FROM payment p
    " . ($dateRange ? "WHERE p.Created_At BETWEEN ? AND ?" : "");
$totalEarningsStmt = $conn->prepare($totalEarningsQuery);
if ($dateRange) {
    $totalEarningsStmt->execute($dateRange);
} else {
    $totalEarningsStmt->execute();
}
$totalEarningsResult = $totalEarningsStmt->fetch(PDO::FETCH_ASSOC);
$totalEarnings = $totalEarningsResult['TotalEarnings'] ?? 0;

// Check if the search form is submitted
$searchPaymentID = null;
if (isset($_POST['search_payment_id'])) {
    $searchPaymentID = $_POST['search_payment_id'];
}

// Define the main query to retrieve transaction data
$query = "
    SELECT 
        p.PaymentID, 
        p.BookingID, 
        b.Date, 
        b.Time, 
        b.Status as BookingStatus,
        s.Type as ServiceType, 
        s.Price, 
        p.Method, 
        p.DatePaid, 
        p.Amount as PaymentAmount,
        p.Status,
        bar.Name AS BarberName,
        bar.barberID,
        bar.Picture AS BarberProfilePic,
        u.Fname AS CustomerFirstName,
        u.Lname AS CustomerLastName
    FROM 
        payment p
    JOIN 
        booking b ON p.BookingID = b.BookingID
    JOIN 
        services s ON b.ServiceID = s.ServiceID
    JOIN 
        barbers bar ON b.barberID = bar.barberID
    JOIN 
        user u ON s.UserID = u.UserID
    " . ($dateRange ? "WHERE p.Created_At BETWEEN ? AND ?" : "") . "
    " . ($searchPaymentID ? "WHERE p.PaymentID = ?" : "") . "
    ORDER BY 
        p.Created_At DESC";

// Prepare and execute the query
$stmt = $conn->prepare($query);
if ($dateRange && $searchPaymentID) {
    $stmt->execute(array_merge($dateRange, [$searchPaymentID]));
} elseif ($dateRange) {
    $stmt->execute($dateRange);
} elseif ($searchPaymentID) {
    $stmt->execute([$searchPaymentID]);
} else {
    $stmt->execute();
}
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Pagination
$limit = 4; // Number of records per page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1; // Current page number

// Calculate offset for pagination
$offset = ($page - 1) * $limit;

// Modify the query to include pagination
$pagedQuery = $query . " LIMIT $limit OFFSET $offset";
$pagedStmt = $conn->prepare($pagedQuery);
if ($dateRange && $searchPaymentID) {
    $pagedStmt->execute(array_merge($dateRange, [$searchPaymentID]));
} elseif ($dateRange) {
    $pagedStmt->execute($dateRange);
} elseif ($searchPaymentID) {
    $pagedStmt->execute([$searchPaymentID]);
} else {
    $pagedStmt->execute();
}
$pagedTransactions = $pagedStmt->fetchAll(PDO::FETCH_ASSOC);

// Get total number of records for pagination
$totalRecordsQuery = "
    SELECT COUNT(*) as total
    FROM payment p
    " . ($dateRange ? "WHERE p.Created_At BETWEEN ? AND ?" : "") . "
    " . ($searchPaymentID ? "WHERE p.PaymentID = ?" : "");
$totalRecordsStmt = $conn->prepare($totalRecordsQuery);
if ($dateRange && $searchPaymentID) {
    $totalRecordsStmt->execute(array_merge($dateRange, [$searchPaymentID]));
} elseif ($dateRange) {
    $totalRecordsStmt->execute($dateRange);
} elseif ($searchPaymentID) {
    $totalRecordsStmt->execute([$searchPaymentID]);
} else {
    $totalRecordsStmt->execute();
}
$totalRecordsResult = $totalRecordsStmt->fetch(PDO::FETCH_ASSOC);
$totalRecords = $totalRecordsResult['total'];
$totalPages = ceil($totalRecords / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Report</title>
    <link rel="icon" href="images/logo.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <!-- Bootstrap Lux Theme CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <style>
      body {
        font-family: 'Poppins';
        background-color: #f8f9fa;
    }
    .container {
        margin-top: 15px;
        max-width: 95%;
    }
   /* .table-responsive {
        overflow-x: auto;
        max-width: 1400px;
        margin-bottom: 20px;
    }*/
    .form-inline {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    .form-group {
        display: flex;
        align-items: center;
    }
    .form-group label {
        margin-right: 10px;
    }
    .btn-dark {
        background-color: #343a40;
        color: #fff;
    }
    .btn-container {
        display: flex;
        gap: 10px;
    }
    .profile-pic {
        width: 50px;
        height: 50px;
        border-radius: 50%;
    }
    .top-barber-info {
        display: flex;
        align-items: center;
    }
    .top-barber-info img {
        margin-right: 20px;
    }
    .top-barber-details {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 10px;
    }
    .top-barber-details div {
        margin-right: 20px;
    }
    .card, .table-container {
        width: 100%;
    }
    .card-title {
        padding-left: 30px;
    }
    th, td {
        text-align: center;
        vertical-align: middle;
    }
    .card-body{
        height: 60px;
        width: 300px;
        background-color: white;
    }
    </style>
</head>
<body>

<div class="container">
    <h1>Transaction Record</h1><br>
<div class="input-group-append">
    <div style="width: 298px; height: 110px" class="card mb-4">
        <div style="width: 300px;" class="card-header bg-primary text-white">
            Total Earnings
        </div>
        <div class="card-body">
            <div class="top-barber-info">
                <div class="top-barber-details">
                    <div style="padding-right: 5px;">
                        <h5 class="card-title">Earnings: ₱<?php echo number_format($totalEarnings, 2); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="padding-left: 60px;">
    <form method="post" class="mb-4">
        <div class="form-row">
            <div class="form-group col-md-12">
                <input type="text" id="search_payment_id" name="search_payment_id" class="form-control" value="<?php echo $searchPaymentID ?? ''; ?>" placeholder="Search For Payment ID">
            </div>
            <div class="form-group col-md-12 d-flex align-items-end">
                <button type="submit" class="btn btn-dark w-100">Search</button>
            </div>
        </div>
    </form>
    </div>
    <div style="padding-left: 850px; padding-top: 50px ;">
        <a class="btn btn-primary mt-4" href="gen_allTransactionpdf.php" target="_blank">Download PDF</a>
    </div>
</div>

    <form method="post" class="mb-4">
        <div class="form-row">
            <div class="form-group col-md-5">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo $startDate ?? ''; ?>">
            </div>
            <div class="form-group col-md-5">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo $endDate ?? ''; ?>">
            </div>
            <div class="form-group col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-dark w-50 mr-2">Filter</button>
                <button type="submit" name="all" class="btn btn-dark w-50">Reset</button>
            </div>
        </div>
    </form>
   <div class="table-responsive">
    <table id="barberTable" class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Payment ID</th>
                <th>Name</th>
                <!-- <th>Payment ID</th> -->
                <!-- <th>Booking ID</th> -->
                <th>Barber ID</th>
                <th>Service</th>
                <th>Schedule</th>
                <!-- <th>Payment ID</th> -->
                <th>Method</th>
                <th>Date Paid</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Fetch data
        foreach ($pagedTransactions as $row) {
            echo "<tr>";
            echo "<td>" . (isset($row['PaymentID']) ? $row['PaymentID'] : '') . "</td>";

            echo "<td>" . (isset($row['CustomerFirstName']) ? $row['CustomerFirstName'] : '') . " " . (isset($row['CustomerLastName']) ? $row['CustomerLastName'] : '') . "</td>";
            
            // echo "<td>" . (isset($row['PaymentID']) ? $row['PaymentID'] : '') . "</td>";
            // echo "<td>" . (isset($row['BookingID']) ? $row['BookingID'] : '') . "</td>";
            echo "<td>" . (isset($row['barberID']) ? $row['barberID'] : '') . "</td>";

            echo "<td>" . (isset($row['ServiceType']) ? $row['ServiceType'] : '') . "</td>";
            echo "<td>" . (isset($row['Date']) ? $row['Date'] : '') . " " . (isset($row['Time']) ? $row['Time'] : '') . "</td>";
            // echo "<td>" . (isset($row['PaymentID']) ? $row['PaymentID'] : '') . "</td>";
            echo "<td>" . (isset($row['Method']) ? $row['Method'] : '') . "</td>";
            echo "<td>" . (isset($row['DatePaid']) ? $row['DatePaid'] : '') . "</td>";
            echo "<td>" . (isset($row['PaymentAmount']) ? $row['PaymentAmount'] : '') . "</td>";
            echo "<td>" . (isset($row['BookingStatus']) ? $row['BookingStatus'] : '') . "</td>";
            echo "<td>";
            if ($row['BookingStatus'] == 'Cancelled') {
                echo '<button type="button" class="btn btn-danger" disabled>Mark as Done</button>';
            } else if ($row['BookingStatus'] == 'Done') {
                echo '<button type="button" class="btn btn-primary" disabled>Mark as Done</button>';
            } else {
                echo '<form action="markasdone.php" method="post">';
                echo '<input type="hidden" name="booking_id" value="' . $row['BookingID'] . '">';
                echo '<button type="submit" class="btn btn-primary">Mark as Done</button>';
                echo '</form>';
            }
            echo "</td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>


    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="adminHOMEE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item <?php echo ($page >= $totalPages ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
