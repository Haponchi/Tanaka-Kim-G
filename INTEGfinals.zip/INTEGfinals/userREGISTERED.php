<?php   
session_start();
require('adminCONX.php');

$id = $_SESSION['c'];

// Initialize date variable
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Pagination
$limit = 30; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

// Calculate offset for pagination
$offset = ($page - 1) * $limit;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active User and Credential Report</title>
    <!-- Bootstrap Lux Theme CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/lux/bootstrap.min.css">
    <!-- Bootstrap Datepicker CSS -->
    <link rel="icon" href="images/logo.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins ">
    <style>
        body {
            font-family: 'Poppins';
            background-color: #f8f9fa;
            font-size: 15px;
        }
        .container {
            margin-top: 50px;
            max-width: 1300px;
        }
        .table {
            margin-top: 16px;
        }
        .pagination {
            margin-top: 20px;
        }
        .datepicker {
            z-index: 1151 !important; /* Ensures the datepicker is above other elements */
        }
    </style>
</head>
<body>

<div class="container">
<div class="input-group-append">
    <h1 class="mb-4">Active User</h1>
    <div style="padding-left: 886px">
        <a href="gen_userrecord.php" target="_blank" class="btn btn-primary">Download PDF</a>
    </div>
</div>
    <!-- <p>Report generated on <?php echo date('Y-m-d'); ?></p> -->
    <form action="" method="get" class="mb-3">
        <div class="input-group">
            <input type="text" class="form-control" id="searchInput" placeholder="Search by UserID..." aria-label="Search" aria-describedby="button-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="button" id="button-addon2">Search</button>
            </div>
        </div>
    </form>
    <table id="userTable" class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Number</th>
                <th>Registration Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Query to retrieve data from the "user" table with pagination and date filtering
        $sql = "SELECT * FROM user WHERE Type = 'customer' ORDER BY Creation ASC LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch data
        foreach ($result as $row) {
            echo '<tr>';
            echo '<td>' . $row['UserID'] . '</td>';
            echo '<td>' . $row['Username'] . '</td>';
            echo '<td>' . $row['Email'] . '</td>';
            echo '<td>' . $row['CpNO'] . '</td>';
            echo '<td>' . $row['Creation'] . '</td>';
            echo '<td>';
            echo '<form method="post" action="changeadminuserpassword.php">';
            echo '<input type="hidden" name="userID" value="' . $row['UserID'] . '">';
            echo '<button type="submit" class="btn btn-primary">Change Password</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        ?>
        </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li>
                <a class="page-link" href="adminHOMEE.php">Back</a>
            </li>
            <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
            </li>
        </ul>
    </nav>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap Datepicker JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<!-- Initialize Datepicker -->
<script>
    $(document).ready(function(){
        $('#datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        }).on('changeDate', function(e){
            window.location.href = '?date=' + e.format('yyyy-mm-dd');
        });
    });
</script>

<script>
   document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const userTable = document.getElementById('userTable');

        searchInput.addEventListener('input', function() {
            const searchTerm = searchInput.value.toLowerCase();
            const rows = userTable.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
                const idCell = rows[i].getElementsByTagName('td')[0];
                if (idCell) {
                    const idText = idCell.textContent || idCell.innerText;
                    if (idText.toLowerCase().indexOf(searchTerm) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });
    });
</script>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
